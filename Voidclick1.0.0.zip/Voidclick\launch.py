"""Entry script for the standalone (PyInstaller) build.

Deliberately not __main__.py: that uses a relative import, which works under
`python -m voidclick` but fails when frozen, because the entry script runs as
top-level __main__ rather than as part of the package.
"""

import sys

from voidclick.run import main

if __name__ == "__main__":
    sys.exit(main())
