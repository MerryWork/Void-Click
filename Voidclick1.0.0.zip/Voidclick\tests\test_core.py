"""Core engine tests. Run with:  py tests/test_core.py

Input controllers are stubbed out, so these never move the real mouse or send
real keystrokes.
"""

import json
import os
import sys
import tempfile
import time

sys.path.insert(0, os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "src"))

from voidclick import config, macro
from voidclick.autoclicker import AutoClicker
from voidclick.hotkeys import combo_to_label, combo_to_string, string_to_combo
from voidclick.input_guard import SyntheticInputGuard
from voidclick.macro import MacroEvent, MacroPlayer, load_macro, save_macro

PASSED = []
FAILED = []


def check(name, condition, detail=""):
    (PASSED if condition else FAILED).append(name)
    print(f"  {'PASS' if condition else 'FAIL'}  {name}{'' if condition else f'  -> {detail}'}")


class StubMouse:
    """Records press/release/position calls with timestamps instead of acting."""

    def __init__(self):
        self.events = []
        self.position = (0, 0)

    def press(self, button):
        self.events.append(("press", button, time.monotonic()))

    def release(self, button):
        self.events.append(("release", button, time.monotonic()))

    def scroll(self, dx, dy):
        self.events.append(("scroll", (dx, dy), time.monotonic()))


class StubKeyboard:
    def __init__(self):
        self.events = []

    def press(self, key):
        self.events.append(("press", key))

    def release(self, key):
        self.events.append(("release", key))


def test_autoclicker_respects_click_limit():
    clicker = AutoClicker()
    stub = StubMouse()
    clicker._controller = stub
    clicker.interval_ms = 20
    clicker.duty_cycle = 50
    clicker.click_limit = 8

    started = time.monotonic()
    clicker.start()
    while clicker.running and time.monotonic() - started < 5:
        time.sleep(0.01)
    elapsed = time.monotonic() - started

    presses = [e for e in stub.events if e[0] == "press"]
    releases = [e for e in stub.events if e[0] == "release"]

    check("autoclicker stops at the click limit", len(presses) == 8, f"got {len(presses)}")
    check("every press is paired with a release", len(releases) == len(presses),
          f"{len(presses)} press / {len(releases)} release")
    check("autoclicker clears running state when limit hit", not clicker.running)
    # 8 clicks x 20ms = 160ms; Windows timer granularity is coarse, so allow slack.
    check("timing is in a sane range", 0.10 < elapsed < 1.5, f"elapsed={elapsed:.3f}s")


def test_autoclicker_duty_cycle_controls_hold_time():
    clicker = AutoClicker()
    stub = StubMouse()
    clicker._controller = stub
    clicker.interval_ms = 100
    clicker.duty_cycle = 80   # hold for most of each cycle
    clicker.click_limit = 3

    clicker.start()
    while clicker.running:
        time.sleep(0.01)

    holds = []
    for i in range(0, len(stub.events) - 1, 2):
        if stub.events[i][0] == "press" and stub.events[i + 1][0] == "release":
            holds.append(stub.events[i + 1][2] - stub.events[i][2])

    avg = sum(holds) / len(holds) if holds else 0
    # 80% of 100ms = 80ms held down.
    check("duty cycle sets hold duration", 0.05 < avg < 0.13, f"avg hold={avg:.3f}s")


def test_autoclicker_position_jitter():
    clicker = AutoClicker()
    stub = StubMouse()
    stub.position = (500, 500)
    clicker._controller = stub
    clicker.interval_ms = 10
    clicker.click_limit = 12
    clicker.position_jitter = 6

    clicker.start()
    while clicker.running:
        time.sleep(0.01)

    x, y = stub.position
    check("jitter moves the pointer off its start position", (x, y) != (500, 500),
          f"still at {(x, y)}")
    check("jitter stays inside the requested radius per click",
          abs(x - 500) <= 6 * 12 and abs(y - 500) <= 6 * 12, f"drifted to {(x, y)}")

    # Zero jitter must leave the pointer exactly where it was.
    steady = AutoClicker()
    steady_stub = StubMouse()
    steady_stub.position = (300, 300)
    steady._controller = steady_stub
    steady.interval_ms = 10
    steady.click_limit = 5
    steady.position_jitter = 0
    steady.start()
    while steady.running:
        time.sleep(0.01)
    check("zero jitter never moves the pointer", steady_stub.position == (300, 300),
          str(steady_stub.position))


def test_autoclicker_stop_is_immediate():
    clicker = AutoClicker()
    clicker._controller = StubMouse()
    clicker.interval_ms = 50
    clicker.click_limit = 0  # unlimited

    clicker.start()
    time.sleep(0.15)
    check("unlimited clicker keeps running", clicker.running)
    clicker.stop()
    time.sleep(0.25)
    check("stop() halts the clicker", not clicker.running)


def test_rapid_restart_does_not_strand_the_engines():
    """Regression: toggling quickly used to leave two worker threads racing —
    the older one's cleanup switched the newer run off, so it 'randomly stopped
    working, then started again'."""
    from voidclick.script import ScriptRunner, ScriptStep

    events = [MacroEvent("click", i * 0.02, {"x": 1, "y": 1, "button": "left",
                                              "pressed": True}) for i in range(40)]
    player = MacroPlayer()
    player._mouse, player._keyboard = StubMouse(), StubKeyboard()

    for _ in range(12):
        player.play(events, loop_count=0)   # infinite
        time.sleep(0.015)
        player.stop()
        time.sleep(0.005)

    player.play(events, loop_count=0)
    time.sleep(0.25)
    check("player is still running after rapid restarts", player.playing)

    before = len(player._mouse.events)
    time.sleep(0.25)
    check("player keeps emitting after rapid restarts",
          len(player._mouse.events) > before,
          f"stalled at {before} events")
    player.stop()
    time.sleep(0.2)
    check("player stops cleanly at the end", not player.playing)

    # The clicker takes the same treatment.
    clicker = AutoClicker()
    clicker._controller = StubMouse()
    clicker.interval_ms = 10
    clicker.click_limit = 0
    for _ in range(12):
        clicker.start()
        time.sleep(0.015)
        clicker.stop()
        time.sleep(0.005)

    clicker.start()
    time.sleep(0.2)
    check("clicker is still running after rapid restarts", clicker.running)
    count_before = len(clicker._controller.events)
    time.sleep(0.2)
    check("clicker keeps clicking after rapid restarts",
          len(clicker._controller.events) > count_before,
          f"stalled at {count_before} events")
    clicker.stop()
    time.sleep(0.2)
    check("clicker stops cleanly at the end", not clicker.running)

    # Every press must have a matching release — no stuck mouse button.
    presses = len([e for e in clicker._controller.events if e[0] == "press"])
    releases = len([e for e in clicker._controller.events if e[0] == "release"])
    check("no mouse button left held after rapid restarts", presses == releases,
          f"{presses} press / {releases} release")

    runner = ScriptRunner()
    runner._mouse, runner._keyboard = StubMouse(), StubKeyboard()
    steps = [ScriptStep("click", {"count": 1, "cps": 50, "duty": 50,
                                   "randomization": 0, "button": "left"})]
    for _ in range(10):
        runner.start(steps, loop=True)
        time.sleep(0.015)
        runner.stop()
        time.sleep(0.005)
    runner.start(steps, loop=True)
    time.sleep(0.2)
    check("script runner survives rapid restarts", runner.running)
    runner.stop()
    time.sleep(0.2)
    check("script runner stops cleanly at the end", not runner.running)


def test_clicker_stop_is_responsive_on_slow_intervals():
    """A one-second interval used to mean stop waited out the whole sleep."""
    clicker = AutoClicker()
    clicker._controller = StubMouse()
    clicker.interval_ms = 2000     # 2s between clicks
    clicker.duty_cycle = 1
    clicker.click_limit = 0
    clicker.start()
    time.sleep(0.1)

    asked = time.monotonic()
    clicker.stop()
    while clicker.running and time.monotonic() - asked < 3:
        time.sleep(0.01)
    elapsed = time.monotonic() - asked
    check("stop takes effect without waiting out the interval", elapsed < 0.5,
          f"took {elapsed:.2f}s")


class ExplodingMouse(StubMouse):
    """Fails after N presses, like a transient OS input error."""

    def __init__(self, fail_after=3):
        super().__init__()
        self.fail_after = fail_after

    def press(self, button):
        if len(self.events) >= self.fail_after:
            raise OSError("simulated input failure")
        super().press(button)


def test_engines_recover_from_a_mid_run_error():
    """Regression for 'the autoclicker randomly stops working'. Cleanup used to
    sit after the loop, so any exception left the running flag set and the
    engine refused to start ever again."""
    from voidclick.script import ScriptRunner, ScriptStep

    clicker = AutoClicker()
    clicker._controller = ExplodingMouse(fail_after=3)
    clicker.interval_ms = 10
    clicker.click_limit = 0
    clicker.start()
    deadline = time.monotonic() + 3
    while clicker.running and time.monotonic() < deadline:
        time.sleep(0.01)

    check("clicker clears running after an error", not clicker.running)
    check("clicker records what went wrong", clicker.last_error is not None)

    clicker._controller = StubMouse()          # the fault clears
    clicker.click_limit = 2
    clicker.start()
    while clicker.running:
        time.sleep(0.01)
    check("clicker can be restarted after an error",
          len([e for e in clicker._controller.events if e[0] == "press"]) == 2)

    # Same guarantee for macro playback.
    player = MacroPlayer()
    player._mouse, player._keyboard = ExplodingMouse(fail_after=0), StubKeyboard()
    player.play([MacroEvent("click", 0.0, {"x": 1, "y": 1, "button": "left",
                                            "pressed": True})], loop_count=1)
    deadline = time.monotonic() + 3
    while player.playing and time.monotonic() < deadline:
        time.sleep(0.01)
    check("player clears playing after an error", not player.playing)

    player._mouse = StubMouse()
    player.play([MacroEvent("click", 0.0, {"x": 1, "y": 1, "button": "left",
                                            "pressed": True})], loop_count=1)
    while player.playing:
        time.sleep(0.01)
    check("player can be restarted after an error",
          len(player._mouse.events) == 1, str(player._mouse.events))

    # And for the script runner.
    runner = ScriptRunner()
    runner._mouse, runner._keyboard = StubMouse(), StubKeyboard()
    runner.start([ScriptStep("key", {"key": "not-a-real-key"})], loop=False)
    deadline = time.monotonic() + 3
    while runner.running and time.monotonic() < deadline:
        time.sleep(0.01)
    check("script runner clears running after a bad step", not runner.running)


def test_failing_callback_does_not_break_the_engine():
    """on_count fires on every click and calls into Tk from a worker thread; a
    raising callback must not abort the loop."""
    clicker = AutoClicker(on_count=lambda n: (_ for _ in ()).throw(RuntimeError("boom")))
    clicker._controller = StubMouse()
    clicker.interval_ms = 5
    clicker.click_limit = 4
    clicker.start()
    deadline = time.monotonic() + 3
    while clicker.running and time.monotonic() < deadline:
        time.sleep(0.01)

    presses = len([e for e in clicker._controller.events if e[0] == "press"])
    check("clicks continue despite a failing callback", presses == 4, f"{presses} clicks")
    check("clicker finishes cleanly despite a failing callback", not clicker.running)


def test_failing_hotkey_callback_does_not_kill_the_listener():
    from pynput import keyboard

    from voidclick.hotkeys import HotkeyManager

    time.sleep(0.05)
    mgr = HotkeyManager()
    later = []
    mgr.register("bad", "f6", lambda: (_ for _ in ()).throw(RuntimeError("boom")))
    mgr.register("good", "f7", lambda: later.append("ok"))

    mgr._on_key_press(keyboard.Key.f6)
    mgr._on_key_release(keyboard.Key.f6)
    mgr._on_key_press(keyboard.Key.f7)
    check("a raising hotkey callback doesn't stop later hotkeys", later == ["ok"], str(later))


def test_macro_save_load_round_trip():
    events = [
        MacroEvent("move", 0.0, {"x": 10, "y": 20}),
        MacroEvent("click", 0.5, {"x": 10, "y": 20, "button": "left", "pressed": True}),
        MacroEvent("click", 0.6, {"x": 10, "y": 20, "button": "left", "pressed": False}),
        MacroEvent("key_press", 1.0, {"key": "'a'"}),
        MacroEvent("key_release", 1.1, {"key": "Key.space"}),
        MacroEvent("scroll", 1.5, {"x": 1, "y": 2, "dx": 0, "dy": -1}),
    ]
    path = os.path.join(tempfile.gettempdir(), "amt_test_macro.json")
    try:
        save_macro(path, events)
        loaded = load_macro(path)
        check("macro round-trips through JSON", len(loaded) == len(events),
              f"{len(loaded)} vs {len(events)}")
        same = all(
            a.type == b.type and abs(a.t - b.t) < 1e-9 and a.data == b.data
            for a, b in zip(events, loaded)
        )
        check("round-tripped events are identical", same)
    finally:
        if os.path.exists(path):
            os.remove(path)


def test_macro_key_serialisation():
    for original in ("Key.space", "Key.f7", "'a'", "'5'"):
        key = macro.str_to_key(original)
        check(f"key {original} survives a round trip", macro.key_to_str(key) == original,
              f"got {macro.key_to_str(key)}")


def test_macro_player_executes_in_order():
    player = MacroPlayer()
    mouse_stub, kb_stub = StubMouse(), StubKeyboard()
    player._mouse = mouse_stub
    player._keyboard = kb_stub

    events = [
        MacroEvent("click", 0.0, {"x": 5, "y": 6, "button": "left", "pressed": True}),
        MacroEvent("click", 0.02, {"x": 5, "y": 6, "button": "left", "pressed": False}),
        MacroEvent("key_press", 0.04, {"key": "'a'"}),
        MacroEvent("key_release", 0.05, {"key": "'a'"}),
    ]
    player.play(events, loop_count=1)
    while player.playing:
        time.sleep(0.01)

    check("player emits both mouse events", len(mouse_stub.events) == 2, str(mouse_stub.events))
    check("player emits both key events", len(kb_stub.events) == 2, str(kb_stub.events))
    check("mouse order preserved",
          [e[0] for e in mouse_stub.events] == ["press", "release"])
    check("key order preserved", [e[0] for e in kb_stub.events] == ["press", "release"])


def test_macro_player_loops_and_speed():
    player = MacroPlayer()
    player._mouse = StubMouse()
    player._keyboard = StubKeyboard()
    events = [MacroEvent("click", 0.0, {"x": 1, "y": 1, "button": "left", "pressed": True})]

    player.play(events, loop_count=3)
    while player.playing:
        time.sleep(0.01)
    check("loop_count replays the macro", len(player._mouse.events) == 3,
          f"got {len(player._mouse.events)}")

    # A 0.4s macro at 4x should finish far quicker than at 1x.
    slow = [MacroEvent("click", 0.4, {"x": 1, "y": 1, "button": "left", "pressed": True})]
    player2 = MacroPlayer()
    player2._mouse, player2._keyboard = StubMouse(), StubKeyboard()
    player2.speed = 4.0
    t0 = time.monotonic()
    player2.play(slow, loop_count=1)
    while player2.playing:
        time.sleep(0.005)
    fast_elapsed = time.monotonic() - t0
    check("playback speed shortens duration", fast_elapsed < 0.3, f"took {fast_elapsed:.3f}s")


def test_macro_player_stop_interrupts():
    player = MacroPlayer()
    player._mouse, player._keyboard = StubMouse(), StubKeyboard()
    events = [MacroEvent("click", i * 0.1, {"x": 1, "y": 1, "button": "left", "pressed": True})
              for i in range(50)]
    player.play(events, loop_count=0)  # infinite
    time.sleep(0.15)
    player.stop()
    time.sleep(0.2)
    check("stop() interrupts playback", not player.playing)
    check("stop() cuts playback short", len(player._mouse.events) < 50,
          f"emitted {len(player._mouse.events)}")


def test_hotkey_combo_parsing():
    check("modifiers sort before the main key",
          combo_to_string(frozenset({"f6", "ctrl"})) == "ctrl+f6",
          combo_to_string(frozenset({"f6", "ctrl"})))
    check("combo string parses back",
          string_to_combo("ctrl+alt+h") == frozenset({"ctrl", "alt", "h"}))
    check("mouse combo gets a friendly label",
          combo_to_label("ctrl+mouse_x1") == "Ctrl + Mouse 4",
          combo_to_label("ctrl+mouse_x1"))
    check("plain key label", combo_to_label("f12") == "F12", combo_to_label("f12"))
    check("middle click label",
          combo_to_label("mouse_middle") == "Middle Click", combo_to_label("mouse_middle"))
    check("empty combo is readable", combo_to_label("") == "(none)")


def test_building_the_gui_does_not_rewrite_config():
    """Regression: ttk.Scale fires its command while laying out, and the handler
    used to persist the scale's minimum over the user's real setting."""
    import copy
    import tkinter as tk

    from voidclick.gui_app import MainWindow
    from voidclick.hotkeys import HotkeyManager

    cfg = config.defaults_copy()
    cfg["autoclicker"]["duty_cycle"] = 50.0
    cfg["autoclicker"]["randomization"] = 25.0
    before = copy.deepcopy(cfg)

    saves = []
    try:
        win = MainWindow(HotkeyManager(), cfg, lambda: saves.append(1))
    except tk.TclError as exc:
        print(f"  SKIP no display available ({exc})")
        return
    try:
        win.update_idletasks()
        check("building the GUI leaves config untouched", cfg == before,
              f"duty {before['autoclicker']['duty_cycle']} -> "
              f"{cfg['autoclicker']['duty_cycle']}, "
              f"rand {before['autoclicker']['randomization']} -> "
              f"{cfg['autoclicker']['randomization']}")
        check("building the GUI triggers no config saves", not saves,
              f"{len(saves)} save(s)")
    finally:
        win.destroy()


def test_hotkey_manager_matching():
    """Drive the listener callbacks directly — no real listeners are started."""
    from pynput import keyboard, mouse

    from voidclick.hotkeys import HotkeyManager
    from voidclick.input_guard import GUARD

    time.sleep(0.05)  # let any guard window from earlier tests lapse

    mgr = HotkeyManager()
    fired = []
    mgr.register("single", "f6", lambda: fired.append("single"))
    mgr._on_key_press(keyboard.Key.f6)
    mgr._on_key_release(keyboard.Key.f6)
    check("single key hotkey fires", fired == ["single"], str(fired))

    mgr2 = HotkeyManager()
    hits = []
    mgr2.register("combo", "ctrl+h", lambda: hits.append("combo"))
    mgr2._on_key_press(keyboard.KeyCode.from_char("h"))
    check("main key alone does not fire a combo", hits == [], str(hits))
    mgr2._on_key_release(keyboard.KeyCode.from_char("h"))
    mgr2._on_key_press(keyboard.Key.ctrl_l)
    mgr2._on_key_press(keyboard.KeyCode.from_char("h"))
    check("full combo fires", hits == ["combo"], str(hits))

    mgr3 = HotkeyManager()
    clicks = []
    mgr3.register("mid", "mouse_middle", lambda: clicks.append("mid"))
    mgr3._on_click(0, 0, mouse.Button.middle, True)
    check("mouse button works as a hotkey", clicks == ["mid"], str(clicks))

    mgr4 = HotkeyManager()
    guarded = []
    mgr4.register("g", "f6", lambda: guarded.append("g"))
    GUARD.mark("key")
    mgr4._on_key_press(keyboard.Key.f6)
    check("synthetic input does not trigger hotkeys", guarded == [], str(guarded))

    mgr5 = HotkeyManager()
    injected_hits = []
    mgr5.register("i", "f6", lambda: injected_hits.append("i"))
    time.sleep(0.05)
    mgr5._on_key_press(keyboard.Key.f6, injected=True)
    check("injected events are ignored", injected_hits == [], str(injected_hits))


def test_hotkey_fires_while_other_keys_are_held():
    """Regression: exact-set matching meant holding W (or any unrelated key)
    stopped every hotkey from firing — fatal while gaming."""
    from pynput import keyboard, mouse

    from voidclick.hotkeys import HotkeyManager

    time.sleep(0.05)

    mgr = HotkeyManager()
    log = []
    mgr.register("start", "mouse_right", lambda: log.append("down"),
                 on_release=lambda: log.append("up"))

    mgr._on_key_press(keyboard.KeyCode.from_char("w"))      # holding W
    mgr._on_click(0, 0, mouse.Button.right, True)
    check("hold hotkey fires while another key is held", log == ["down"], str(log))

    mgr._on_click(0, 0, mouse.Button.right, False)
    check("hold hotkey releases while another key is held", log == ["down", "up"], str(log))

    # Still holding W: pressing an unrelated key must not re-fire the hotkey.
    mgr._on_click(0, 0, mouse.Button.right, True)
    log.clear()
    mgr._on_key_press(keyboard.KeyCode.from_char("a"))
    check("an unrelated key does not re-fire a held hotkey", log == [], str(log))

    # A keyboard hotkey works the same way.
    mgr2 = HotkeyManager()
    hits = []
    mgr2.register("go", "f6", lambda: hits.append("hit"))
    mgr2._on_key_press(keyboard.KeyCode.from_char("w"))
    mgr2._on_key_press(keyboard.KeyCode.from_char("d"))
    mgr2._on_key_press(keyboard.Key.f6)
    check("keyboard hotkey fires with movement keys held", hits == ["hit"], str(hits))


def test_hotkey_conflict_detection():
    from voidclick.hotkey_conflicts import MANAGED, find_conflict

    cfg = config.defaults_copy()
    cfg["autoclicker"]["hotkey"] = "f6"
    cfg["macro"]["record_hotkey"] = "f7"
    cfg["macro"]["play_hotkey"] = "f8"
    cfg["script"]["hotkey"] = "f9"

    check("a free key reports no conflict",
          find_conflict(cfg, "macro", "play_hotkey", "f4") is None)
    check("taking the autoclicker's key is a conflict",
          find_conflict(cfg, "macro", "play_hotkey", "f6") == "the autoclicker")
    check("taking macro record's key is a conflict",
          find_conflict(cfg, "script", "hotkey", "f7") == "macro record")
    check("keeping your own key is not a conflict",
          find_conflict(cfg, "macro", "play_hotkey", "f8") is None)

    # Blank bindings must coexist — clearing is how a conflict gets resolved.
    cfg["macro"]["play_hotkey"] = ""
    check("blank bindings never conflict",
          find_conflict(cfg, "script", "hotkey", "") is None)

    # Panic must be in the set too: sharing a key would fire both at once.
    cfg["general"]["panic_hotkey"] = "f12"
    check("taking the panic key is a conflict",
          find_conflict(cfg, "script", "hotkey", "f12") == "the panic stop")
    check("panic cannot take an action's key",
          find_conflict(cfg, "general", "panic_hotkey", "f6") == "the autoclicker")

    managed_keys = {(section, key) for section, key, _ in MANAGED}
    expected = {
        ("autoclicker", "hotkey"), ("macro", "record_hotkey"), ("macro", "play_hotkey"),
        ("script", "hotkey"), ("general", "panic_hotkey"), ("general", "swap_hotkey"),
    }
    check("every bindable hotkey is conflict-managed", managed_keys == expected,
          f"missing {expected - managed_keys}, unexpected {managed_keys - expected}")


def test_conflicting_hotkey_clears_field_and_banners():
    """End-to-end: assigning a taken key must blank the picker, warn, and not
    re-banner while the first is still showing."""
    import tkinter as tk

    from voidclick.gui_app import MainWindow
    from voidclick.hotkeys import HotkeyManager

    cfg = config.defaults_copy()
    cfg["autoclicker"]["hotkey"] = "f6"
    cfg["macro"]["play_hotkey"] = "f8"

    try:
        win = MainWindow(HotkeyManager(), cfg, lambda: None)
    except tk.TclError as exc:
        print(f"  SKIP no display available ({exc})")
        return

    try:
        win.update_idletasks()
        macro_page = win.pages["macro"]

        # Try to steal the autoclicker's key.
        macro_page._on_play_hotkey_change("f6")
        win.update_idletasks()

        check("conflicting hotkey is cleared in config",
              cfg["macro"]["play_hotkey"] == "", repr(cfg["macro"]["play_hotkey"]))
        check("conflicting hotkey is cleared in the picker",
              macro_page.play_picker.combo == "", repr(macro_page.play_picker.combo))
        check("the autoclicker keeps its key", cfg["autoclicker"]["hotkey"] == "f6")
        check("a banner is showing", win._banner.winfo_ismapped())

        # Spamming must not stack a second banner.
        check("a repeat is throttled while the banner is up",
              not win._banner_throttle.allow())

        # A free key is accepted normally.
        macro_page._on_play_hotkey_change("f4")
        check("a non-conflicting key is accepted", cfg["macro"]["play_hotkey"] == "f4")

        # The panic hotkey obeys the same rule from the Settings page.
        win._banner_throttle.reset()
        settings_page = win.pages["settings"]
        settings_page._on_panic_hotkey_change("f4")
        win.update_idletasks()
        check("panic cannot steal an action's key",
              cfg["general"]["panic_hotkey"] == "", repr(cfg["general"]["panic_hotkey"]))
        check("macro play keeps its key", cfg["macro"]["play_hotkey"] == "f4")
    finally:
        win.destroy()


def _click_pair(t, x=100, y=100, button="left", hold=0.01):
    return [
        MacroEvent("click", t, {"x": x, "y": y, "button": button, "pressed": True}),
        MacroEvent("click", t + hold, {"x": x, "y": y, "button": button, "pressed": False}),
    ]


def _key_pair(t, key="'3'", hold=0.02):
    return [
        MacroEvent("key_press", t, {"key": key}),
        MacroEvent("key_release", t + hold, {"key": key}),
    ]


def test_transcribe_key_names():
    from voidclick.transcribe import macro_key_to_script_key

    check("a character key converts", macro_key_to_script_key("'a'") == "a")
    check("a digit converts", macro_key_to_script_key("'3'") == "3")
    check("a named key converts", macro_key_to_script_key("Key.space") == "space")
    check("a function key converts", macro_key_to_script_key("Key.f5") == "f5")


def test_transcribe_steady_burst():
    """A clean 10 cps burst in one spot should come back as one step."""
    from voidclick.transcribe import transcribe

    events = []
    for i in range(12):
        events += _click_pair(i * 0.1, hold=0.05)

    steps, report = transcribe(events)
    check("a steady burst becomes a single step", len(steps) == 1, str(steps))
    check("a long run uses autoclick", steps[0].kind == "autoclick", steps[0].kind)
    check("the rate is recovered", abs(steps[0].params["cps"] - 10.0) < 0.5,
          str(steps[0].params["cps"]))
    check("the duty cycle is recovered", abs(steps[0].params["duty"] - 50.0) < 10,
          str(steps[0].params["duty"]))
    check("a steady burst reports no randomization",
          steps[0].params["randomization"] < 5, str(steps[0].params["randomization"]))
    check("one position means no warnings", report.faithful, str(report.warnings))
    check("one cluster detected", report.click_clusters == 1, str(report.click_clusters))


def test_transcribe_short_burst_uses_count():
    from voidclick.transcribe import transcribe

    events = []
    for i in range(3):
        events += _click_pair(i * 0.1)
    steps, _ = transcribe(events)
    check("a short burst uses a counted click step", steps[0].kind == "click", steps[0].kind)
    check("the count is right", steps[0].params["count"] == 3, str(steps[0].params))


def test_transcribe_the_documented_example():
    """The pattern the Script tab exists for: a burst, then keys, then more clicks."""
    from voidclick.transcribe import transcribe

    events = []
    t = 0.0
    for i in range(10):            # a burst of clicking
        events += _click_pair(t + i * 0.05)
    t = 1.0
    events += _key_pair(t, "'3'")   # press 3
    events += _key_pair(t + 0.4, "'1'")   # wait, then press 1
    t = 2.0
    for i in range(10):            # resume clicking
        events += _click_pair(t + i * 0.05)

    steps, report = transcribe(events)
    kinds = [s.kind for s in steps]
    check("clicking, keys and pauses all appear",
          "autoclick" in kinds and kinds.count("key") == 2 and "wait" in kinds, str(kinds))
    keys = [s.params["key"] for s in steps if s.kind == "key"]
    check("keys keep their order and names", keys == ["3", "1"], str(keys))
    check("no spurious warnings for a single-position macro",
          report.faithful, str(report.warnings))
    check("the report summarises the conversion", "events ->" in report.summary(),
          report.summary())


def test_transcribe_flags_what_cannot_convert():
    from voidclick.transcribe import transcribe

    # Clicks in two different places: position matters, so warn.
    spread = _click_pair(0.0, x=10, y=10) + _click_pair(0.5, x=800, y=600)
    _, report = transcribe(spread)
    check("multiple click positions are flagged",
          any("different places" in w for w in report.warnings), str(report.warnings))
    check("multiple clusters are counted", report.click_clusters == 2)

    # Scroll and movement have no script equivalent.
    noisy = (_click_pair(0.0)
             + [MacroEvent("scroll", 0.2, {"x": 1, "y": 1, "dx": 0, "dy": -1})]
             + [MacroEvent("move", 0.3, {"x": 5, "y": 5})])
    _, report = transcribe(noisy)
    check("scrolling is flagged", any("scroll" in w for w in report.warnings),
          str(report.warnings))
    check("movement is flagged", any("movement" in w for w in report.warnings),
          str(report.warnings))

    # A modifier held across another key can't be sequential.
    chord = [
        MacroEvent("key_press", 0.0, {"key": "Key.ctrl_l"}),
        MacroEvent("key_press", 0.1, {"key": "'c'"}),
        MacroEvent("key_release", 0.2, {"key": "'c'"}),
        MacroEvent("key_release", 0.3, {"key": "Key.ctrl_l"}),
    ]
    _, report = transcribe(chord)
    check("held modifiers are flagged", any("held across" in w for w in report.warnings),
          str(report.warnings))

    steps, report = transcribe([])
    check("an empty recording is handled", steps == [] and not report.faithful)


def test_transcribe_output_is_runnable():
    """Whatever comes out must be valid input for the script engine."""
    from voidclick.script import KINDS, ScriptRunner, parse_key
    from voidclick.transcribe import transcribe

    events = []
    for i in range(10):
        events += _click_pair(i * 0.05)
    events += _key_pair(1.0, "Key.space")

    steps, _ = transcribe(events)
    check("every step kind is one the engine knows",
          all(s.kind in KINDS for s in steps), str([s.kind for s in steps]))
    for step in steps:
        if step.kind == "key":
            parse_key(step.params["key"])   # raises if unusable
    check("key steps parse", True)

    runner = ScriptRunner()
    runner._mouse, runner._keyboard = StubMouse(), StubKeyboard()
    runner.speed = 8.0
    runner.start(steps, loop=False)
    deadline = time.monotonic() + 5
    while runner.running and time.monotonic() < deadline:
        time.sleep(0.01)
    check("the transcribed script actually runs", not runner.running)
    check("it produced clicks", len(runner._mouse.events) > 0,
          str(len(runner._mouse.events)))


def test_hotkey_swap():
    from voidclick.quick_actions import PAIRS, pair_label, split_pair, swap_hotkeys

    cfg = config.defaults_copy()
    cfg["autoclicker"]["hotkey"] = "n"
    cfg["macro"]["play_hotkey"] = "b"
    cfg["script"]["hotkey"] = "k"

    left, right = swap_hotkeys(cfg, "autoclicker|macro")
    check("autoclicker takes the macro key", cfg["autoclicker"]["hotkey"] == "b",
          cfg["autoclicker"]["hotkey"])
    check("macro takes the autoclicker key", cfg["macro"]["play_hotkey"] == "n",
          cfg["macro"]["play_hotkey"])
    check("the untouched action keeps its key", cfg["script"]["hotkey"] == "k")
    check("swap reports both names", (left, right) == ("autoclicker", "macro play"),
          str((left, right)))

    # Swapping again restores the original arrangement.
    swap_hotkeys(cfg, "autoclicker|macro")
    check("swapping twice restores the originals",
          cfg["autoclicker"]["hotkey"] == "n" and cfg["macro"]["play_hotkey"] == "b")

    swap_hotkeys(cfg, "macro|script")
    check("a different pair swaps independently",
          cfg["macro"]["play_hotkey"] == "k" and cfg["script"]["hotkey"] == "b")

    # A blank binding still swaps rather than being skipped.
    cfg["autoclicker"]["hotkey"] = ""
    cfg["script"]["hotkey"] = "j"
    swap_hotkeys(cfg, "autoclicker|script")
    check("a blank hotkey swaps too",
          cfg["autoclicker"]["hotkey"] == "j" and cfg["script"]["hotkey"] == "")

    check("a malformed pair falls back to a valid one",
          split_pair("nonsense") == ("autoclicker", "macro"), str(split_pair("nonsense")))
    check("every pair has a readable label",
          all(" <-> " in pair_label(p) for p in PAIRS))


def test_speed_stepping():
    from voidclick.quick_actions import SPEED_STEPS, step_speed

    check("stepping up from 1x", step_speed(1.0, 1) == 1.25, str(step_speed(1.0, 1)))
    check("stepping down from 1x", step_speed(1.0, -1) == 0.75, str(step_speed(1.0, -1)))
    check("clamped at the top", step_speed(SPEED_STEPS[-1], 1) == SPEED_STEPS[-1])
    check("clamped at the bottom", step_speed(SPEED_STEPS[0], -1) == SPEED_STEPS[0])
    check("an off-ladder speed snaps to a neighbour",
          step_speed(1.9, 1) == 3.0, str(step_speed(1.9, 1)))
    check("a junk speed is treated as 1x", step_speed("nonsense", 1) == 1.25)


def test_macro_and_script_speeds_are_independent():
    """Each page owns its own speed; changing one must not touch the other."""
    import tkinter as tk

    from voidclick.gui_app import MainWindow
    from voidclick.hotkeys import HotkeyManager

    cfg = config.defaults_copy()
    try:
        win = MainWindow(HotkeyManager(), cfg, lambda: None)
    except tk.TclError as exc:
        print(f"  SKIP no display available ({exc})")
        return

    try:
        win.update_idletasks()
        macro_page, script_page = win.pages["macro"], win.pages["script"]

        macro_page.speed_control._step(1)      # macro only
        check("macro speed rose", cfg["macro"]["playback_speed"] == 1.25,
              str(cfg["macro"]["playback_speed"]))
        check("script speed untouched", cfg["script"]["speed"] == 1.0,
              str(cfg["script"]["speed"]))
        check("the macro player got the new speed", macro_page.player.speed == 1.25)

        script_page.speed_control._step(-1)    # script only
        check("script speed fell", cfg["script"]["speed"] == 0.75,
              str(cfg["script"]["speed"]))
        check("macro speed still 1.25x", cfg["macro"]["playback_speed"] == 1.25)
        check("the script runner got the new speed", script_page.runner.speed == 0.75)

        check("speed is no longer a general setting",
              "playback_speed" not in cfg["general"], str(cfg["general"].keys()))
    finally:
        win.destroy()


def test_script_runner_honours_speed():
    from voidclick.script import ScriptRunner, ScriptStep

    def run_at(speed):
        runner = ScriptRunner()
        runner._mouse, runner._keyboard = StubMouse(), StubKeyboard()
        runner.speed = speed
        started = time.monotonic()
        runner.start([ScriptStep("wait", {"seconds": 0.4})], loop=False)
        while runner.running and time.monotonic() - started < 5:
            time.sleep(0.005)
        return time.monotonic() - started

    slow, fast = run_at(1.0), run_at(4.0)
    check("script waits shrink as speed rises", fast < slow / 2,
          f"1x took {slow:.2f}s, 4x took {fast:.2f}s")


def test_banner_throttle():
    from voidclick.hotkey_conflicts import Throttle

    throttle = Throttle(seconds=0.3)
    check("first banner is allowed", throttle.allow())
    check("a repeat during the window is dropped", not throttle.allow())
    check("spamming stays dropped", not throttle.allow() and not throttle.allow())
    time.sleep(0.35)
    check("a banner is allowed again after the window", throttle.allow())
    throttle.reset()
    check("reset lets the next banner through immediately", throttle.allow())


def test_hotkey_specificity():
    """With F6 and Ctrl+F6 both bound, pressing Ctrl+F6 must not fire both."""
    from pynput import keyboard

    from voidclick.hotkeys import HotkeyManager

    time.sleep(0.05)

    mgr = HotkeyManager()
    fired = []
    mgr.register("plain", "f6", lambda: fired.append("plain"))
    mgr.register("combo", "ctrl+f6", lambda: fired.append("combo"))

    mgr._on_key_press(keyboard.Key.ctrl_l)
    mgr._on_key_press(keyboard.Key.f6)
    check("only the most specific hotkey fires", fired == ["combo"], str(fired))

    mgr._on_key_release(keyboard.Key.f6)
    mgr._on_key_release(keyboard.Key.ctrl_l)
    fired.clear()
    mgr._on_key_press(keyboard.Key.f6)
    check("the plain hotkey still fires on its own", fired == ["plain"], str(fired))


def test_hotkey_hold_mode():
    from pynput import keyboard, mouse

    from voidclick.hotkeys import HotkeyManager

    time.sleep(0.05)

    mgr = HotkeyManager()
    log = []
    mgr.register("hold", "f6", lambda: log.append("down"), on_release=lambda: log.append("up"))
    mgr._on_key_press(keyboard.Key.f6)
    check("hold mode fires on press", log == ["down"], str(log))
    mgr._on_key_release(keyboard.Key.f6)
    check("hold mode fires on release", log == ["down", "up"], str(log))

    # Releasing an unrelated key must not end a held hotkey.
    mgr2 = HotkeyManager()
    log2 = []
    mgr2.register("hold", "f6", lambda: log2.append("down"), on_release=lambda: log2.append("up"))
    mgr2._on_key_press(keyboard.Key.f6)
    mgr2._on_key_release(keyboard.Key.f8)
    check("unrelated key release does not end a hold", log2 == ["down"], str(log2))

    # Toggle-style registrations have no release callback and must not break.
    mgr3 = HotkeyManager()
    log3 = []
    mgr3.register("toggle", "mouse_x2", lambda: log3.append("hit"))
    mgr3._on_click(0, 0, mouse.Button.middle, True)
    mgr3._on_click(0, 0, mouse.Button.middle, False)
    check("toggle registration survives release handling", log3 == [], str(log3))

    # A hold bound to a mouse button releases on mouse-up.
    mgr4 = HotkeyManager()
    log4 = []
    mgr4.register("hold", "mouse_middle", lambda: log4.append("down"),
                  on_release=lambda: log4.append("up"))
    mgr4._on_click(0, 0, mouse.Button.middle, True)
    mgr4._on_click(0, 0, mouse.Button.middle, False)
    check("mouse hold releases on mouse up", log4 == ["down", "up"], str(log4))


def test_shifted_key_release_clears_state():
    """Regression: shift+minus reports '_' on press but '-' on release once shift
    is let go. Matching on the token stranded '_' forever, which then appeared in
    every hotkey the user recorded afterwards."""
    from pynput import keyboard

    from voidclick.hotkeys import HotkeyManager

    time.sleep(0.05)
    mgr = HotkeyManager()
    mgr._on_key_press(keyboard.KeyCode.from_vk(189, char="_"))
    mgr._on_key_release(keyboard.KeyCode.from_vk(189, char="-"))
    check("shifted character release clears the held token", not mgr._pressed,
          f"stranded {mgr._pressed}")

    # A later capture must therefore be clean.
    captured = []
    mgr.begin_capture(captured.append)
    mgr._on_click(0, 0, __import__("pynput").mouse.Button.left, False)
    mgr._on_click(0, 0, __import__("pynput").mouse.Button.middle, True)
    check("capture after a shifted key is not polluted", captured == ["mouse_middle"],
          str(captured))


def test_hotkey_capture():
    from pynput import keyboard, mouse

    from voidclick.hotkeys import HotkeyManager

    time.sleep(0.05)

    mgr = HotkeyManager()
    captured = []
    mgr.begin_capture(captured.append)
    mgr._on_click(0, 0, mouse.Button.left, False)   # release of the click that opened capture
    mgr._on_key_press(keyboard.Key.ctrl_l)          # modifier should accumulate, not commit
    check("modifier alone does not finish capture", captured == [], str(captured))
    mgr._on_key_press(keyboard.KeyCode.from_char("j"))
    check("capture records the full combo", captured == ["ctrl+j"], str(captured))

    mgr2 = HotkeyManager()
    rejected = []
    mgr2.begin_capture(rejected.append)
    mgr2._on_click(0, 0, mouse.Button.left, False)  # arms capture
    mgr2._on_click(0, 0, mouse.Button.left, True)   # bare left click
    check("bare left click is refused as a hotkey", rejected == [], str(rejected))
    mgr2._on_key_press(keyboard.Key.ctrl_l)
    mgr2._on_click(0, 0, mouse.Button.left, True)
    check("left click with a modifier is allowed",
          rejected == ["ctrl+mouse_left"], str(rejected))

    mgr3 = HotkeyManager()
    side = []
    mgr3.begin_capture(side.append)
    mgr3._on_click(0, 0, mouse.Button.left, False)
    mgr3._on_click(0, 0, mouse.Button.middle, True)
    check("middle click can be captured", side == ["mouse_middle"], str(side))


def test_script_key_parsing():
    from pynput import keyboard

    from voidclick.script import parse_key

    check("single characters parse", parse_key("3") == keyboard.KeyCode.from_char("3"))
    check("named keys parse", parse_key("space") == keyboard.Key.space)
    check("function keys parse", parse_key("f5") == keyboard.Key.f5)
    check("named keys are case-insensitive", parse_key("Enter") == keyboard.Key.enter)
    for bad in ("", "   ", "nonsense"):
        try:
            parse_key(bad)
            check(f"invalid key {bad!r} is rejected", False, "no error raised")
        except ValueError:
            check(f"invalid key {bad!r} is rejected", True)


def test_script_save_load_round_trip():
    from voidclick.script import ScriptStep, load_script, save_script

    steps = [
        ScriptStep("autoclick", {"cps": 34.0, "seconds": 3.0, "button": "left"}),
        ScriptStep("key", {"key": "3", "hold_ms": 0}),
        ScriptStep("wait", {"seconds": 0.3}),
    ]
    path = os.path.join(tempfile.gettempdir(), "amt_test_script.json")
    try:
        save_script(path, steps)
        loaded = load_script(path)
        check("script round-trips through JSON", len(loaded) == 3, str(len(loaded)))
        check("step kinds and params survive",
              all(a.kind == b.kind and a.params == b.params for a, b in zip(steps, loaded)))
    finally:
        if os.path.exists(path):
            os.remove(path)

    bad = os.path.join(tempfile.gettempdir(), "amt_bad_script.json")
    try:
        with open(bad, "w") as f:
            json.dump([{"kind": "explode", "params": {}}], f)
        try:
            load_script(bad)
            check("unknown step kinds are rejected", False, "no error raised")
        except ValueError:
            check("unknown step kinds are rejected", True)
    finally:
        if os.path.exists(bad):
            os.remove(bad)


def test_script_runs_the_documented_example():
    """The scenario the feature was requested for: autoclick, then interleave keys."""
    from voidclick.script import ScriptRunner, ScriptStep

    runner = ScriptRunner()
    mouse_stub, kb_stub = StubMouse(), StubKeyboard()
    runner._mouse, runner._keyboard = mouse_stub, kb_stub

    steps = [
        ScriptStep("autoclick", {"cps": 34, "seconds": 0.3, "button": "left"}),
        ScriptStep("key", {"key": "3", "hold_ms": 0}),
        ScriptStep("wait", {"seconds": 0.05}),
        ScriptStep("key", {"key": "1", "hold_ms": 0}),
    ]

    started = time.monotonic()
    runner.start(steps, loop=False)
    while runner.running and time.monotonic() - started < 5:
        time.sleep(0.01)

    clicks = len([e for e in mouse_stub.events if e[0] == "press"])
    # 34 cps for 0.3s is ~10 clicks; scheduling slop makes the exact count vary.
    check("autoclick step clicks at roughly the requested rate", 5 <= clicks <= 15,
          f"{clicks} clicks")

    pressed = [str(e[1]) for e in kb_stub.events if e[0] == "press"]
    check("keys fire in script order", pressed == ["'3'", "'1'"], str(pressed))
    check("every key press is released",
          len([e for e in kb_stub.events if e[0] == "release"]) == 2)
    check("runner clears its running flag when finished", not runner.running)


def test_script_click_duty_and_randomization():
    from voidclick.script import ScriptRunner, ScriptStep

    runner = ScriptRunner()
    stub = StubMouse()
    runner._mouse, runner._keyboard = stub, StubKeyboard()

    # 5 cps = 200ms cycle, 80% duty = ~160ms held down.
    runner.start([ScriptStep("click", {"count": 3, "cps": 5, "duty": 80,
                                        "randomization": 0, "button": "left"})], loop=False)
    while runner.running:
        time.sleep(0.01)

    holds = []
    events = stub.events
    for i in range(0, len(events) - 1, 2):
        if events[i][0] == "press" and events[i + 1][0] == "release":
            holds.append(events[i + 1][2] - events[i][2])
    average = sum(holds) / len(holds) if holds else 0
    check("script duty cycle controls hold time", 0.10 < average < 0.24,
          f"avg hold {average:.3f}s")

    # Randomization must actually vary the cycle length.
    spread_runner = ScriptRunner()
    spread_stub = StubMouse()
    spread_runner._mouse, spread_runner._keyboard = spread_stub, StubKeyboard()
    spread_runner.start([ScriptStep("click", {"count": 8, "cps": 25, "duty": 50,
                                               "randomization": 80, "button": "left"})],
                        loop=False)
    while spread_runner.running:
        time.sleep(0.01)
    presses = [e[2] for e in spread_stub.events if e[0] == "press"]
    gaps = [b - a for a, b in zip(presses, presses[1:])]
    check("randomization varies the click interval",
          len(gaps) > 2 and (max(gaps) - min(gaps)) > 0.005,
          f"gap spread {max(gaps) - min(gaps):.4f}s" if gaps else "no gaps")


def test_script_loop_and_stop():
    from voidclick.script import ScriptRunner, ScriptStep

    runner = ScriptRunner()
    runner._mouse, runner._keyboard = StubMouse(), StubKeyboard()
    steps = [ScriptStep("click", {"count": 1, "cps": 50, "button": "left"}),
             ScriptStep("wait", {"seconds": 0.02})]

    runner.start(steps, loop=True)
    time.sleep(0.25)
    check("looping script keeps running", runner.running)
    runner.stop()
    time.sleep(0.2)
    check("stop() halts the script", not runner.running)
    presses = len([e for e in runner._mouse.events if e[0] == "press"])
    check("looping repeated the step", presses > 1, f"{presses} presses")

    # A long wait must not delay stopping.
    runner2 = ScriptRunner()
    runner2._mouse, runner2._keyboard = StubMouse(), StubKeyboard()
    runner2.start([ScriptStep("wait", {"seconds": 30})], loop=False)
    time.sleep(0.1)
    t0 = time.monotonic()
    runner2.stop()
    while runner2.running and time.monotonic() - t0 < 2:
        time.sleep(0.01)
    check("stop interrupts a long wait promptly", time.monotonic() - t0 < 1.0,
          f"took {time.monotonic() - t0:.2f}s")


def test_script_step_descriptions():
    from voidclick.script import ScriptStep

    check("autoclick describes itself",
          "34" in ScriptStep("autoclick", {"cps": 34, "seconds": 3}).describe())
    check("key step describes itself",
          "'3'" in ScriptStep("key", {"key": "3"}).describe())
    check("wait step describes itself",
          "Wait" in ScriptStep("wait", {"seconds": 0.3}).describe())


class FakeCanvas:
    """Records draw calls so gradient output can be checked without a display."""

    def __init__(self, bg="#12141a"):
        self.lines = []
        self._bg = bg

    def create_line(self, x1, y1, x2, y2, fill=None, tags=None, width=None):
        self.lines.append({"x1": x1, "y1": y1, "x2": x2, "y2": y2, "fill": fill})

    def create_polygon(self, *args, **kwargs):
        pass

    def cget(self, _key):
        return self._bg


def test_gradient_antialiases_rounded_edges():
    """Corner arcs stair-step badly without blended end pixels — that was the
    'pixelated' complaint."""
    from voidclick import gradient

    base, backdrop = "#3ddc84", "#12141a"

    aliased = FakeCanvas()
    gradient.glass(aliased, 0, 0, 40, 40, 12, base)
    smooth = FakeCanvas()
    gradient.glass(smooth, 0, 0, 40, 40, 12, base, bg=backdrop)

    check("anti-aliased fill draws more segments than the plain one",
          len(smooth.lines) > len(aliased.lines),
          f"{len(smooth.lines)} vs {len(aliased.lines)}")

    edge_pixels = [line for line in smooth.lines if abs(line["x2"] - line["x1"]) == 1]
    check("edge pixels are drawn for the corner arcs", len(edge_pixels) > 4,
          f"{len(edge_pixels)} edge pixels")

    def rgb(color):
        return gradient._to_rgb(color)

    backdrop_rgb, base_rgb = rgb(backdrop), rgb(base)
    blended = [
        line for line in edge_pixels
        if all(min(backdrop_rgb[i], base_rgb[i]) - 2 <= rgb(line["fill"])[i]
               <= max(backdrop_rgb[i], base_rgb[i]) + 2 for i in range(3))
        and rgb(line["fill"]) != backdrop_rgb
    ]
    check("edge pixels are blended between backdrop and fill", len(blended) > 4,
          f"{len(blended)} blended of {len(edge_pixels)}")

    # A blend must never be drawn outside the shape's bounds.
    check("blended pixels stay within the shape",
          all(-1 <= line["x1"] and line["x2"] <= 41 for line in edge_pixels))


def test_gradient_colour_maths():
    from voidclick import gradient

    check("lerp at 0 returns the first colour", gradient.lerp("#000000", "#ffffff", 0) == "#000000")
    check("lerp at 1 returns the second colour", gradient.lerp("#000000", "#ffffff", 1) == "#ffffff")
    check("lerp midpoint is halfway", gradient.lerp("#000000", "#ffffff", 0.5) == "#808080",
          gradient.lerp("#000000", "#ffffff", 0.5))
    check("lighten moves towards white",
          gradient._to_rgb(gradient.lighten("#404040", 0.5))[0] > 0x40)
    check("darken moves towards black",
          gradient._to_rgb(gradient.darken("#404040", 0.5))[0] < 0x40)
    check("glass top half is lighter than the bottom half",
          gradient._to_rgb(gradient.glass_color_at("#3ddc84", 0.1))[1]
          > gradient._to_rgb(gradient.glass_color_at("#3ddc84", 0.9))[1])


def test_play_hotkey_survives_mouse_playback():
    """Regression: a macro full of mouse moves used to keep the synthetic-input
    guard permanently active, which swallowed the hotkey meant to stop it."""
    from pynput import keyboard

    from voidclick.hotkeys import HotkeyManager
    from voidclick.input_guard import GUARD, MOUSE

    mgr = HotkeyManager()
    fired = []
    mgr.register("stop", "f8", lambda: fired.append("stop"))

    # Simulate playback emitting mouse events far faster than the guard window.
    for _ in range(4):
        GUARD.mark(MOUSE)
        time.sleep(0.01)

    mgr._on_key_press(keyboard.Key.f8)
    check("keyboard hotkey still fires during mouse playback", fired == ["stop"],
          f"{fired} - guard blocked the stop key")

    # The guard must still protect same-kind input from self-triggering.
    mgr2 = HotkeyManager()
    clicks = []
    mgr2.register("mid", "mouse_middle", lambda: clicks.append("hit"))
    GUARD.mark(MOUSE)
    from pynput import mouse as pynput_mouse
    mgr2._on_click(0, 0, pynput_mouse.Button.middle, True)
    check("mouse guard still blocks self-generated clicks", clicks == [], str(clicks))


def test_synthetic_guard_expires():
    from voidclick.input_guard import KEY, MOUSE

    guard = SyntheticInputGuard(window=0.05)
    check("guard starts inactive", not guard.active(MOUSE))
    guard.mark(MOUSE)
    check("guard is active right after mark()", guard.active(MOUSE))
    check("marking one kind leaves the other free", not guard.active(KEY))
    time.sleep(0.12)
    check("guard expires on its own", not guard.active(MOUSE))


def test_config_defaults_and_merge():
    a = config.defaults_copy()
    a["autoclicker"]["interval_ms"] = 999
    b = config.defaults_copy()
    check("defaults_copy returns independent copies", b["autoclicker"]["interval_ms"] != 999)

    # A config file written by an older version is missing whole sections.
    original = config.CONFIG_PATH
    tmp = os.path.join(tempfile.gettempdir(), "amt_test_config.json")
    try:
        with open(tmp, "w") as f:
            json.dump({"autoclicker": {"interval_ms": 42.0}}, f)
        config.CONFIG_PATH = tmp
        cfg = config.load_config()
        check("saved values are loaded", cfg["autoclicker"]["interval_ms"] == 42.0)
        check("missing sections fall back to defaults", "general" in cfg and "macro" in cfg)
        check("missing keys inside a section fall back",
              cfg["autoclicker"]["hotkey"] == config.DEFAULTS["autoclicker"]["hotkey"])
    finally:
        config.CONFIG_PATH = original
        if os.path.exists(tmp):
            os.remove(tmp)


def test_config_import_is_forgiving():
    """Imported settings may come from another version — missing sections must
    fall back to defaults and unknown keys must not leak in."""
    cfg = config.defaults_copy()
    config.apply_data(cfg, {"autoclicker": {"interval_ms": 12.5, "bogus_key": 1}})

    check("imported values are applied", cfg["autoclicker"]["interval_ms"] == 12.5)
    check("unknown keys are dropped", "bogus_key" not in cfg["autoclicker"])
    check("absent sections fall back to defaults",
          cfg["macro"] == config.DEFAULTS["macro"])
    check("absent keys in a present section fall back",
          cfg["autoclicker"]["duty_cycle"] == config.DEFAULTS["autoclicker"]["duty_cycle"])

    for junk in ([1, 2, 3], "nope", {"autoclicker": "not-a-dict"}):
        try:
            config.apply_data(config.defaults_copy(), junk)
            check(f"malformed import {junk!r} is rejected", False, "no error raised")
        except ValueError:
            check(f"malformed import {type(junk).__name__} is rejected", True)


def main():
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for test in tests:
        print(f"\n{test.__name__}")
        try:
            test()
        except Exception as exc:  # a crash is a failure, not a stack trace
            FAILED.append(test.__name__)
            print(f"  ERROR {test.__name__}: {exc!r}")

    print(f"\n{'=' * 60}\n{len(PASSED)} passed, {len(FAILED)} failed")
    if FAILED:
        for name in FAILED:
            print(f"  failed: {name}")
    return 1 if FAILED else 0


if __name__ == "__main__":
    sys.exit(main())
