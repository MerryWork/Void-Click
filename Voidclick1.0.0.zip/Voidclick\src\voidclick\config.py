"""Settings persistence.

Settings live in a per-user data directory rather than beside the code. An
installed package sits in site-packages and a frozen executable unpacks to a
temp folder — both are read-only or discarded, so writing next to the source
would silently lose every setting on a real installation.
"""

import json
import os
import sys
from pathlib import Path

APP_DIR_NAME = "VoidClick"


def data_dir():
    """Per-user config location, following each platform's convention."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming"
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config"
    return Path(base) / APP_DIR_NAME


CONFIG_PATH = str(data_dir() / "config.json")

DEFAULTS = {
    "autoclicker": {
        "interval_ms": 100.0,
        "duty_cycle": 50.0,
        "randomization": 0.0,
        "click_limit": 0,
        "position_jitter": 0,
        "button": "left",
        "hotkey": "f6",
        "hotkey_mode": "toggle",   # toggle | hold
        "rate_unit": "ms",         # ms | cps
    },
    "macro": {
        "record_hotkey": "f7",
        "play_hotkey": "f8",
        "loop_count": 1,
        "continuous_loop": False,
        "play_hotkey_mode": "toggle",
        "playback_speed": 1.0,
    },
    "script": {
        "hotkey": "f9",
        "hotkey_mode": "toggle",
        "loop": True,
        "speed": 1.0,
    },
    "general": {
        "panic_hotkey": "f12",
        "panic_quits_app": False,
        "swap_hotkey": "",
        "swap_pair": "autoclicker|macro",
        "always_on_top": False,
        "record_mouse_moves": True,
    },
}


def defaults_copy():
    return json.loads(json.dumps(DEFAULTS))


def apply_data(cfg, data):
    """Replace cfg's contents with `data`, falling back to defaults per key.

    Used when importing a settings file, which may come from a different version
    and be missing sections or carry keys we no longer use.
    """
    if not isinstance(data, dict):
        raise ValueError("settings file is not a JSON object")
    fresh = defaults_copy()
    for section, values in fresh.items():
        incoming = data.get(section, {})
        if not isinstance(incoming, dict):
            raise ValueError(f"section '{section}' is not a JSON object")
        values.update({k: v for k, v in incoming.items() if k in values})
        cfg[section].clear()
        cfg[section].update(values)


def load_config():
    cfg = defaults_copy()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                data = json.load(f)
            for section, values in cfg.items():
                saved = data.get(section, {})
                # Known keys only, so a setting removed in a later version
                # doesn't linger in the file forever.
                values.update({k: v for k, v in saved.items() if k in values})
        except (json.JSONDecodeError, OSError):
            pass
    return cfg


def save_config(cfg):
    try:
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass  # a read-only or missing profile shouldn't crash the app
