"""Suppresses hotkey matching on input this app synthesized itself.

Without this, an autoclicker clicking the same mouse button bound as its own
toggle would immediately switch itself off. pynput reports an `injected` flag on
Windows/macOS but not on every backend, so this short time window is the
portable backstop.

The guard is tracked **per input kind**. It used to be a single global window,
which meant a macro replaying mouse movement (recorded at ~50Hz, faster than the
window) kept it permanently active and swallowed the keyboard hotkey meant to
stop that very macro.
"""

import threading
import time

WINDOW_SECONDS = 0.035

MOUSE = "mouse"
KEY = "key"


class SyntheticInputGuard:
    def __init__(self, window=WINDOW_SECONDS):
        self.window = window
        self._lock = threading.Lock()
        self._until = {MOUSE: 0.0, KEY: 0.0}

    def mark(self, kind):
        with self._lock:
            self._until[kind] = time.monotonic() + self.window

    def active(self, kind):
        with self._lock:
            return time.monotonic() < self._until.get(kind, 0.0)


GUARD = SyntheticInputGuard()
