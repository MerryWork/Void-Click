"""Dark theme with green/orange accent hues, shared across the whole app."""

from tkinter import ttk

BG = "#12141a"            # window background
BG_PANEL = "#181b22"      # page/content background
BG_SIDEBAR = "#0c0e13"    # nav rail background
BG_SIDEBAR_HOVER = "#1b1f27"
BG_FIELD = "#20242e"      # inputs, sliders trough

FG = "#eceef2"            # primary text
FG_MUTED = "#8b8f99"      # secondary text
BORDER = "#2a2e38"

GREEN = "#3ddc84"         # idle / go / active-nav
GREEN_HOVER = "#2fc271"
ORANGE = "#ff9d45"        # running / stop / emphasized values
ORANGE_HOVER = "#e8862f"
TEXT_ON_ACCENT = "#0d0f14"


def apply(root):
    root.configure(bg=BG)

    style = ttk.Style(root)
    style.theme_use("clam")

    style.configure(".", background=BG_PANEL, foreground=FG,
                     fieldbackground=BG_FIELD, bordercolor=BORDER,
                     lightcolor=BORDER, darkcolor=BORDER, troughcolor=BG_FIELD)

    style.configure("TFrame", background=BG_PANEL)
    style.configure("TLabel", background=BG_PANEL, foreground=FG)
    style.configure("Muted.TLabel", background=BG_PANEL, foreground=FG_MUTED)
    style.configure("Value.TLabel", background=BG_PANEL, foreground=ORANGE)
    style.configure("Section.TLabel", background=BG_PANEL, foreground=GREEN,
                     font=("Segoe UI", 9, "bold"))
    style.configure("Title.TLabel", background=BG_PANEL, foreground=FG,
                     font=("Segoe UI", 14, "bold"))
    style.configure("TSeparator", background=BORDER)

    style.configure("TEntry", fieldbackground=BG_FIELD, foreground=FG, insertcolor=FG)
    style.configure("TCombobox", fieldbackground=BG_FIELD, foreground=FG, background=BG_FIELD,
                     arrowcolor=FG)
    style.map("TCombobox", fieldbackground=[("readonly", BG_FIELD)], foreground=[("readonly", FG)])
    root.option_add("*TCombobox*Listbox.background", BG_FIELD)
    root.option_add("*TCombobox*Listbox.foreground", FG)
    root.option_add("*TCombobox*Listbox.selectBackground", GREEN)
    root.option_add("*TCombobox*Listbox.selectForeground", TEXT_ON_ACCENT)

    # Green handle, dark trough — bordercolor stays neutral or the trough
    # picks up a green outline too.
    style.configure("Horizontal.TScale", troughcolor=BG_FIELD, background=GREEN,
                     bordercolor=BORDER, lightcolor=GREEN, darkcolor=GREEN)
    style.map("Horizontal.TScale", background=[("active", GREEN_HOVER)])

    style.configure("TButton", background=GREEN, foreground=TEXT_ON_ACCENT,
                     borderwidth=0, focuscolor=BG_PANEL, padding=6)
    style.map("TButton", background=[("active", GREEN_HOVER), ("disabled", BORDER)])

    style.configure("Vertical.TScrollbar", background=BG_FIELD, troughcolor=BG_PANEL,
                     bordercolor=BG_PANEL, arrowcolor=FG_MUTED, darkcolor=BG_FIELD,
                     lightcolor=BG_FIELD)
    style.map("Vertical.TScrollbar", background=[("active", BORDER)])

    style.configure("Treeview", background=BG_FIELD, fieldbackground=BG_FIELD,
                     foreground=FG, borderwidth=0, rowheight=24)
    style.map("Treeview", background=[("selected", GREEN)],
              foreground=[("selected", TEXT_ON_ACCENT)])
    style.configure("Treeview.Heading", background=BG_PANEL, foreground=FG_MUTED,
                     borderwidth=0, relief="flat")
    style.map("Treeview.Heading", background=[("active", BG_PANEL)])

    style.configure("TCheckbutton", background=BG_PANEL, foreground=FG, focuscolor=BG_PANEL,
                     indicatorbackground=BG_FIELD, indicatorforeground=TEXT_ON_ACCENT,
                     indicatormargin=4, bordercolor=BORDER)
    style.map("TCheckbutton",
              background=[("active", BG_PANEL)],
              indicatorbackground=[("selected", GREEN), ("!selected", BG_FIELD)],
              indicatorforeground=[("selected", TEXT_ON_ACCENT)])
