import tkinter as tk
from tkinter import ttk

from . import theme
from .autoclicker import AutoClicker
from .gui_widgets import HotkeyPicker, PageHeader
from .hotkey_conflicts import find_conflict
from .rounded_button import RoundedButton
from .rounded_entry import RoundedEntry
from .rounded_select import RoundedSelect

HOTKEY_MODES = ["toggle", "hold"]
RATE_UNITS = ["ms", "cps"]


class AutoClickerPage(ttk.Frame):
    def __init__(self, master, hotkey_manager, cfg, on_config_change, notify=None):
        super().__init__(master, padding=16)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change
        self.notify = notify or (lambda message: None)

        self.clicker = AutoClicker(on_count=self._on_count, on_state_change=self._on_state_change)
        self._apply_cfg_to_clicker()

        self._loading = True
        self._build_ui()
        self._loading = False
        self._register_hotkey()

    def _apply_cfg_to_clicker(self):
        c = self.cfg["autoclicker"]
        self.clicker.interval_ms = c["interval_ms"]
        self.clicker.duty_cycle = c["duty_cycle"]
        self.clicker.randomization = c["randomization"]
        self.clicker.click_limit = c["click_limit"]
        self.clicker.position_jitter = c["position_jitter"]
        self.clicker.button = c["button"]

    # ------------------------------------------------------------------ layout

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}
        c = self.cfg["autoclicker"]

        PageHeader(self, "Autoclicker").grid(
            row=0, column=0, columnspan=3, sticky="ew", pady=(0, 12)
        )
        self.columnconfigure(1, weight=1)

        row = 1
        ttk.Label(self, text="Click rate:").grid(row=row, column=0, sticky="w", **pad)
        self.rate_var = tk.StringVar(value=self._rate_display())
        rate_entry = RoundedEntry(self, self.rate_var, width=8)
        rate_entry.grid(row=row, column=1, sticky="w", **pad)
        rate_entry.bind_commit(self._commit_rate)

        self.unit_var = tk.StringVar(value=c["rate_unit"])
        RoundedSelect(self, self.unit_var, RATE_UNITS, command=self._on_unit_change,
                       width=4).grid(row=row, column=2, sticky="w", **pad)
        row += 1

        self.rate_hint = ttk.Label(self, text=self._rate_hint(), style="Muted.TLabel")
        self.rate_hint.grid(row=row, column=1, columnspan=2, sticky="w", padx=8)
        row += 1

        ttk.Label(self, text="Duty cycle (%):").grid(row=row, column=0, sticky="w", **pad)
        self.duty_var = tk.StringVar(value=f"{c['duty_cycle']:g}")
        duty_entry = RoundedEntry(self, self.duty_var, width=8)
        duty_entry.grid(row=row, column=1, sticky="w", **pad)
        duty_entry.bind_commit(self._commit_duty)
        ttk.Label(self, text="1–100", style="Muted.TLabel").grid(row=row, column=2, sticky="w")
        row += 1

        ttk.Label(self, text="Speed randomization (%):").grid(row=row, column=0, sticky="w", **pad)
        self.rand_var = tk.StringVar(value=f"{c['randomization']:g}")
        rand_entry = RoundedEntry(self, self.rand_var, width=8)
        rand_entry.grid(row=row, column=1, sticky="w", **pad)
        rand_entry.bind_commit(self._commit_rand)
        ttk.Label(self, text="0–100", style="Muted.TLabel").grid(row=row, column=2, sticky="w")
        row += 1

        ttk.Label(self, text="Position jitter (px):").grid(row=row, column=0, sticky="w", **pad)
        self.jitter_var = tk.StringVar(value=f"{c['position_jitter']:g}")
        jitter_entry = RoundedEntry(self, self.jitter_var, width=8)
        jitter_entry.grid(row=row, column=1, sticky="w", **pad)
        jitter_entry.bind_commit(self._commit_jitter)
        ttk.Label(self, text="0 = same spot", style="Muted.TLabel").grid(
            row=row, column=2, sticky="w")
        row += 1

        ttk.Label(self, text="Click limit:").grid(row=row, column=0, sticky="w", **pad)
        self.limit_var = tk.StringVar(value=str(c["click_limit"]))
        limit_entry = RoundedEntry(self, self.limit_var, width=8)
        limit_entry.grid(row=row, column=1, sticky="w", **pad)
        limit_entry.bind_commit(self._commit_limit)
        ttk.Label(self, text="0 = unlimited", style="Muted.TLabel").grid(
            row=row, column=2, sticky="w")
        row += 1

        ttk.Label(self, text="Mouse button:").grid(row=row, column=0, sticky="w", **pad)
        self.button_var = tk.StringVar(value=c["button"])
        RoundedSelect(self, self.button_var, ["left", "right", "middle"],
                       command=self._commit_button).grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Start/Stop hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.hotkey_picker = HotkeyPicker(
            self, self.hotkey_manager, c["hotkey"], self._on_hotkey_change
        )
        self.hotkey_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Hotkey mode:").grid(row=row, column=0, sticky="w", **pad)
        self.mode_var = tk.StringVar(value=c["hotkey_mode"])
        RoundedSelect(self, self.mode_var, HOTKEY_MODES,
                       command=self._on_mode_change).grid(row=row, column=1, sticky="w", **pad)
        self.mode_hint = ttk.Label(self, text=self._mode_hint(), style="Muted.TLabel")
        self.mode_hint.grid(row=row, column=2, sticky="w")
        row += 1

        self.start_btn = RoundedButton(
            self, "Start", command=self._toggle, bg=theme.GREEN, hover_bg=theme.GREEN_HOVER,
            fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.start_btn.grid(row=row, column=0, columnspan=3, sticky="ew", padx=8, pady=(10, 4))
        row += 1

        self.status_var = tk.StringVar(value="Idle — 0 clicks")
        ttk.Label(self, textvariable=self.status_var, style="Value.TLabel").grid(
            row=row, column=0, columnspan=3, **pad
        )

    # ------------------------------------------------------------------ helpers

    def _rate_display(self):
        c = self.cfg["autoclicker"]
        if c["rate_unit"] == "cps":
            return f"{1000.0 / max(c['interval_ms'], 0.001):g}"
        return f"{c['interval_ms']:g}"

    def _rate_hint(self):
        interval = self.cfg["autoclicker"]["interval_ms"]
        cps = 1000.0 / max(interval, 0.001)
        return f"{interval:g} ms between clicks  ·  {cps:.2f} clicks/sec"

    def _mode_hint(self):
        if self.cfg["autoclicker"]["hotkey_mode"] == "hold":
            return "clicks only while held"
        return "press once on, again off"

    def _commit_number(self, var, fallback, low, high):
        """Read a number from an entry, clamping to a range; revert if unusable."""
        try:
            value = float(var.get())
            if not low <= value <= high:
                raise ValueError
        except ValueError:
            value = fallback
        var.set(f"{value:g}")
        return value

    # ------------------------------------------------------------------ commits

    def _commit_rate(self):
        c = self.cfg["autoclicker"]
        if c["rate_unit"] == "cps":
            current_cps = 1000.0 / max(c["interval_ms"], 0.001)
            cps = self._commit_number(self.rate_var, current_cps, 0.01, 1000.0)
            interval = 1000.0 / cps
        else:
            interval = self._commit_number(self.rate_var, c["interval_ms"], 0.1, 600000.0)
        c["interval_ms"] = interval
        self.clicker.interval_ms = interval
        self.rate_hint.config(text=self._rate_hint())
        if not self._loading:
            self.on_config_change()

    def _on_unit_change(self):
        self.cfg["autoclicker"]["rate_unit"] = self.unit_var.get()
        self.rate_var.set(self._rate_display())
        self.rate_hint.config(text=self._rate_hint())
        if not self._loading:
            self.on_config_change()

    def _commit_duty(self):
        value = self._commit_number(self.duty_var, self.clicker.duty_cycle, 1, 100)
        self.clicker.duty_cycle = value
        self.cfg["autoclicker"]["duty_cycle"] = value
        if not self._loading:
            self.on_config_change()

    def _commit_rand(self):
        value = self._commit_number(self.rand_var, self.clicker.randomization, 0, 100)
        self.clicker.randomization = value
        self.cfg["autoclicker"]["randomization"] = value
        if not self._loading:
            self.on_config_change()

    def _commit_jitter(self):
        value = int(self._commit_number(self.jitter_var, self.clicker.position_jitter, 0, 500))
        self.jitter_var.set(str(value))
        self.clicker.position_jitter = value
        self.cfg["autoclicker"]["position_jitter"] = value
        if not self._loading:
            self.on_config_change()

    def _commit_limit(self):
        value = int(self._commit_number(self.limit_var, self.clicker.click_limit, 0, 10_000_000))
        self.limit_var.set(str(value))
        self.clicker.click_limit = value
        self.cfg["autoclicker"]["click_limit"] = value
        if not self._loading:
            self.on_config_change()

    def _commit_button(self):
        value = self.button_var.get()
        self.clicker.button = value
        self.cfg["autoclicker"]["button"] = value
        if not self._loading:
            self.on_config_change()

    def _on_hotkey_change(self, combo_string):
        clash = find_conflict(self.cfg, "autoclicker", "hotkey", combo_string)
        if clash:
            # Leave it unset rather than keeping the old key, so it's obvious
            # something needs choosing.
            combo_string = ""
            self.hotkey_picker.set_combo("")
            self.notify(f"Already used by {clash} — pick another key")
        self.cfg["autoclicker"]["hotkey"] = combo_string
        self.on_config_change()
        self._register_hotkey()

    def _on_mode_change(self):
        self.cfg["autoclicker"]["hotkey_mode"] = self.mode_var.get()
        self.mode_hint.config(text=self._mode_hint())
        self.on_config_change()
        self._register_hotkey()

    def refresh_from_config(self):
        c = self.cfg["autoclicker"]
        self._loading = True
        try:
            self.unit_var.set(c["rate_unit"])
            self.rate_var.set(self._rate_display())
            self.rate_hint.config(text=self._rate_hint())
            self.duty_var.set(f"{c['duty_cycle']:g}")
            self.rand_var.set(f"{c['randomization']:g}")
            self.limit_var.set(str(c["click_limit"]))
            self.jitter_var.set(f"{c['position_jitter']:g}")
            self.button_var.set(c["button"])
            self.mode_var.set(c["hotkey_mode"])
            self.mode_hint.config(text=self._mode_hint())
            self.hotkey_picker.set_combo(c["hotkey"])
        finally:
            self._loading = False
        self._apply_cfg_to_clicker()
        self._register_hotkey()

    # ------------------------------------------------------------------ control

    def _register_hotkey(self):
        combo = self.cfg["autoclicker"]["hotkey"]
        if self.cfg["autoclicker"]["hotkey_mode"] == "hold":
            self.hotkey_manager.register(
                "autoclicker_toggle", combo,
                lambda: self.after(0, self.clicker.start),
                on_release=lambda: self.after(0, self.clicker.stop),
            )
        else:
            self.hotkey_manager.register("autoclicker_toggle", combo, self._toggle_from_hotkey)

    def _toggle_from_hotkey(self):
        self.after(0, self._toggle)

    def _toggle(self):
        self.clicker.toggle()

    def _on_state_change(self, running):
        def update():
            self.start_btn.set_text("Stop" if running else "Start")
            self.start_btn.set_colors(
                theme.ORANGE if running else theme.GREEN,
                theme.ORANGE_HOVER if running else theme.GREEN_HOVER,
            )
        self.after(0, update)

    def _on_count(self, count):
        def update():
            state = "Running" if self.clicker.running else "Idle"
            self.status_var.set(f"{state} — {count} clicks")
        self.after(0, update)
