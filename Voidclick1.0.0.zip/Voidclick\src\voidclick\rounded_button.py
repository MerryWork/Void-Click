"""A rounded-corner gradient button drawn on a Canvas (ttk/tk have neither)."""

import tkinter as tk

from . import gradient


class RoundedButton(tk.Canvas):
    def __init__(self, master, text, command=None, bg="#3ddc84", hover_bg=None,
                 fg="#0d0f14", parent_bg=None, radius=12, font=("Segoe UI", 10),
                 height=36, icon=None, icon_size=20, width=80, sheen=1.0, **kw):
        if parent_bg is None:
            try:
                parent_bg = master.cget("bg")
            except tk.TclError:
                parent_bg = "#181b22"
        # Canvas defaults to 238px wide; these are laid out with sticky="ew", so
        # a small requested width keeps them from inflating the whole window.
        super().__init__(master, width=width, height=height, highlightthickness=0,
                          bg=parent_bg, bd=0, **kw)

        self.command = command
        self.text = text
        self.parent_bg = parent_bg   # what the rounded corners blend into
        self.bg_color = bg
        self.hover_color = hover_bg or bg
        self.fg_color = fg
        self.radius = radius
        self.font = font
        self.icon = icon              # callable(canvas, cx, cy, size, color, bg)
        self.icon_size = icon_size
        self.sheen = sheen
        self._hover = False
        self._enabled = True

        self.bind("<Configure>", lambda e: self._draw())
        self.bind("<Button-1>", self._on_click)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)
        self._draw()

    def _round_rect(self, x1, y1, x2, y2, r, **kwargs):
        points = [
            x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
            x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
        ]
        return self.create_polygon(points, smooth=True, **kwargs)

    def _draw(self):
        self.delete("all")
        w = max(self.winfo_width(), 1)
        h = max(self.winfo_height(), 1)
        r = min(self.radius, h // 2, w // 2)
        base = self.hover_color if (self._hover and self._enabled) else self.bg_color
        gradient.glass(self, 1, 1, w - 1, h - 1, r, base, self.sheen, bg=self.parent_bg)

        if self.icon is not None:
            # Icon stacked above the label; sampling the gradient at the icon's
            # own height lets cut-outs (the gear's hole) blend into the button.
            behind = gradient.glass_color_at(base, 0.36, self.sheen)
            self.icon(self, w / 2, h * 0.36, self.icon_size, self.fg_color, behind)
            self.create_text(w / 2, h * 0.78, text=self.text, fill=self.fg_color, font=self.font)
        else:
            self.create_text(w / 2, h / 2, text=self.text, fill=self.fg_color, font=self.font)

    def _on_enter(self, _event):
        if self._enabled:
            self._hover = True
            self.config(cursor="hand2")
            self._draw()

    def _on_leave(self, _event):
        self._hover = False
        self.config(cursor="")
        self._draw()

    def _on_click(self, _event):
        if self.command and self._enabled:
            self.command()

    def set_colors(self, bg, hover_bg=None, fg=None):
        self.bg_color = bg
        self.hover_color = hover_bg or bg
        if fg:
            self.fg_color = fg
        self._draw()

    def set_text(self, text):
        self.text = text
        self._draw()

    def set_enabled(self, enabled):
        self._enabled = enabled
        self._draw()
