import random
import threading
import time
import traceback

from pynput.mouse import Button, Controller

from .input_guard import GUARD, MOUSE
from .safety import safe_call

BUTTON_MAP = {"left": Button.left, "right": Button.right, "middle": Button.middle}


class AutoClicker:
    """Background click loop with duty cycle, jitter, and click limit."""

    def __init__(self, on_count=None, on_state_change=None):
        self._controller = Controller()
        self._running = threading.Event()
        self._thread = None

        self.on_count = on_count
        self.on_state_change = on_state_change

        self.interval_ms = 100.0
        self.duty_cycle = 50.0      # % of each cycle the button stays pressed
        self.randomization = 0.0    # +/- % jitter applied to the interval
        self.click_limit = 0        # 0 = unlimited
        self.button = "left"
        self.position_jitter = 0    # +/- pixels to scatter each click by
        self.last_error = None
        self._generation = 0

    @property
    def running(self):
        return self._running.is_set()

    def toggle(self):
        self.stop() if self.running else self.start()

    def start(self):
        self._halt_current()
        self.last_error = None
        self._generation += 1
        generation = self._generation
        self._running.set()
        self._thread = threading.Thread(target=self._run, args=(generation,), daemon=True)
        self._thread.start()
        safe_call(self.on_state_change, True)

    def stop(self):
        if not self.running:
            return
        self._running.clear()
        safe_call(self.on_state_change, False)

    def _scatter(self):
        """Nudge the pointer a few pixels so clicks don't all land on one pixel."""
        jitter = int(self.position_jitter)
        x, y = self._controller.position
        GUARD.mark(MOUSE)
        self._controller.position = (x + random.randint(-jitter, jitter),
                                      y + random.randint(-jitter, jitter))

    def _current(self, generation):
        """True while this run is both wanted and still the newest one."""
        return self._running.is_set() and generation == self._generation

    def _halt_current(self):
        """End the previous run and wait for its thread, so two never overlap."""
        self._running.clear()
        thread = self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)

    def _sleep(self, seconds, generation):
        """Sleep in slices so stopping doesn't wait out a whole interval."""
        end = time.monotonic() + max(seconds, 0.0)
        while self._current(generation):
            remaining = end - time.monotonic()
            if remaining <= 0:
                return
            time.sleep(min(remaining, 0.01))

    def _run(self, generation):
        # Cleanup lives in finally: if the loop raises, the running flag must
        # still be cleared or the clicker can never be started again.
        try:
            self._click_loop(generation)
        except Exception:
            self.last_error = traceback.format_exc()
            traceback.print_exc()
        finally:
            # Only tidy up if a newer run hasn't taken over, or a finishing old
            # thread would switch the new one off.
            if generation == self._generation:
                self._running.clear()
                safe_call(self.on_state_change, False)

    def _click_loop(self, generation):
        count = 0
        btn = BUTTON_MAP.get(self.button, Button.left)

        while self._current(generation):
            period = max(self.interval_ms, 1.0) / 1000.0
            if self.randomization > 0:
                jitter = 1.0 + random.uniform(-self.randomization, self.randomization) / 100.0
                period = max(period * jitter, 0.001)

            duty = max(min(self.duty_cycle, 100.0), 0.0)
            down_time = period * duty / 100.0
            up_time = max(period - down_time, 0.0)

            if self.position_jitter > 0:
                self._scatter()

            GUARD.mark(MOUSE)
            self._controller.press(btn)
            try:
                if down_time > 0:
                    self._sleep(down_time, generation)
            finally:
                # Always release: bailing out mid-hold would leave the physical
                # mouse button stuck down.
                GUARD.mark(MOUSE)
                self._controller.release(btn)

            count += 1
            safe_call(self.on_count, count)

            if self.click_limit > 0 and count >= self.click_limit:
                break
            if up_time > 0:
                self._sleep(up_time, generation)
