import json
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import theme
from .config import CONFIG_PATH, apply_data, defaults_copy
from .gui_widgets import HotkeyPicker, PageHeader
from .hotkey_conflicts import find_conflict
from .quick_actions import PAIRS, pair_label
from .rounded_button import RoundedButton
from .rounded_select import RoundedSelect
from .toggle import ToggleSwitch



class SettingsPage(ttk.Frame):
    def __init__(self, master, hotkey_manager, cfg, on_config_change, on_apply, on_reset,
                 notify=None):
        super().__init__(master, padding=16)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change
        self.on_apply = on_apply    # push values into the running engines
        self.on_reset = on_reset    # ask every page to reread config after a reset
        self.notify = notify or (lambda message: None)

        self._build_ui()

    def _section(self, title, row):
        ttk.Label(self, text=title.upper(), style="Section.TLabel").grid(
            row=row, column=0, columnspan=3, sticky="w", padx=8, pady=(16, 2)
        )
        ttk.Separator(self, orient="horizontal").grid(
            row=row + 1, column=0, columnspan=3, sticky="ew", padx=8, pady=(0, 6)
        )
        return row + 2

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}
        g = self.cfg["general"]

        PageHeader(self, "Settings").grid(
            row=0, column=0, columnspan=3, sticky="ew", pady=(0, 4)
        )
        self.columnconfigure(1, weight=1)

        row = self._section("Emergency stop", 1)

        ttk.Label(self, text="Panic hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.panic_picker = HotkeyPicker(
            self, self.hotkey_manager, g["panic_hotkey"], self._on_panic_hotkey_change
        )
        self.panic_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Stops the clicker, playback and recording — from anywhere.",
                   style="Muted.TLabel", wraplength=340, justify="left").grid(
            row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        self.panic_quits_var = tk.BooleanVar(value=g["panic_quits_app"])
        self.panic_quits_toggle = ToggleSwitch(
            self, "Panic also closes the app", self.panic_quits_var, self._on_panic_quits_change
        )
        self.panic_quits_toggle.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        row = self._section("Swap hotkeys", row)

        ttk.Label(self, text="Swap hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.swap_picker = HotkeyPicker(
            self, self.hotkey_manager, g["swap_hotkey"], self._on_swap_hotkey_change)
        self.swap_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Swap between:").grid(row=row, column=0, sticky="w", **pad)
        self.swap_pair_var = tk.StringVar(value=pair_label(g["swap_pair"]))
        RoundedSelect(self, self.swap_pair_var, [pair_label(p) for p in PAIRS],
                       command=self._on_swap_pair_change).grid(
            row=row, column=1, columnspan=2, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Trades the two start hotkeys with each other.",
                   style="Muted.TLabel", wraplength=340, justify="left").grid(
            row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        row = self._section("Window", row)

        self.topmost_var = tk.BooleanVar(value=g["always_on_top"])
        self.topmost_toggle = ToggleSwitch(
            self, "Keep window always on top", self.topmost_var, self._on_topmost_change
        )
        self.topmost_toggle.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        row = self._section("Macro", row)

        self.record_moves_var = tk.BooleanVar(value=g["record_mouse_moves"])
        self.record_moves_toggle = ToggleSwitch(
            self, "Record mouse movement", self.record_moves_var, self._on_record_moves_change
        )
        self.record_moves_toggle.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Playback speed lives on the Macro and Script pages.",
                   style="Muted.TLabel", wraplength=340, justify="left").grid(
            row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        row = self._section("Configuration", row)

        share_frame = ttk.Frame(self)
        share_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        share_frame.columnconfigure((0, 1), weight=1)
        RoundedButton(
            share_frame, "Export settings...", command=self._export,
            bg=theme.BG_FIELD, hover_bg=theme.BORDER, fg=theme.FG,
            parent_bg=theme.BG_PANEL, height=30, font=("Segoe UI", 9),
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        RoundedButton(
            share_frame, "Import settings...", command=self._import,
            bg=theme.BG_FIELD, hover_bg=theme.BORDER, fg=theme.FG,
            parent_bg=theme.BG_PANEL, height=30, font=("Segoe UI", 9),
        ).grid(row=0, column=1, sticky="ew", padx=(4, 0))
        row += 1

        RoundedButton(
            self, "Reset all settings to defaults", command=self._reset_defaults,
            bg=theme.BG_FIELD, hover_bg=theme.ORANGE, fg=theme.FG,
            parent_bg=theme.BG_PANEL, height=32,
        ).grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        row += 1

        ttk.Label(self, text=f"Saved to {CONFIG_PATH}", style="Muted.TLabel",
                   wraplength=340, justify="left").grid(
            row=row, column=0, columnspan=3, sticky="w", **pad
        )


    def _on_panic_hotkey_change(self, combo_string):
        clash = find_conflict(self.cfg, "general", "panic_hotkey", combo_string)
        if clash:
            combo_string = ""
            self.panic_picker.set_combo("")
            self.notify(f"Already used by {clash} — pick another key")
        self.cfg["general"]["panic_hotkey"] = combo_string
        self.on_config_change()
        self.on_apply()

    def _on_panic_quits_change(self):
        self.cfg["general"]["panic_quits_app"] = self.panic_quits_var.get()
        self.on_config_change()

    def _hotkey_or_blank(self, key, combo_string, picker):
        """Blank the binding and warn if another action already owns this key."""
        clash = find_conflict(self.cfg, "general", key, combo_string)
        if not clash:
            return combo_string
        picker.set_combo("")
        self.notify(f"Already used by {clash} — pick another key")
        return ""

    def _on_swap_hotkey_change(self, combo_string):
        self.cfg["general"]["swap_hotkey"] = self._hotkey_or_blank(
            "swap_hotkey", combo_string, self.swap_picker)
        self.on_config_change()
        self.on_apply()

    def _on_swap_pair_change(self):
        label = self.swap_pair_var.get()
        for pair in PAIRS:
            if pair_label(pair) == label:
                self.cfg["general"]["swap_pair"] = pair
                break
        self.on_config_change()

    def _on_topmost_change(self):
        self.cfg["general"]["always_on_top"] = self.topmost_var.get()
        self.on_config_change()
        self.on_apply()

    def _on_record_moves_change(self):
        self.cfg["general"]["record_mouse_moves"] = self.record_moves_var.get()
        self.on_config_change()
        self.on_apply()

    def _export(self):
        path = filedialog.asksaveasfilename(
            defaultextension=".json", initialfile="void-click-settings.json",
            filetypes=[("Settings files", "*.json")])
        if not path:
            return
        try:
            with open(path, "w") as handle:
                json.dump(self.cfg, handle, indent=2)
        except OSError as exc:
            messagebox.showerror("Export settings", f"Could not write the file:\n{exc}")

    def _import(self):
        path = filedialog.askopenfilename(filetypes=[("Settings files", "*.json")])
        if not path:
            return
        try:
            with open(path) as handle:
                data = json.load(handle)
            apply_data(self.cfg, data)
        except (OSError, ValueError) as exc:
            messagebox.showerror("Import settings", f"Could not read those settings:\n{exc}")
            return
        self.on_config_change()
        self.on_reset()

    def _reset_defaults(self):
        if not messagebox.askyesno(
            "Reset settings",
            "Restore every setting — hotkeys included — to its default?",
        ):
            return
        fresh = defaults_copy()
        for section, values in fresh.items():
            self.cfg[section].clear()
            self.cfg[section].update(values)
        self.on_config_change()
        self.on_reset()

    def refresh_from_config(self):
        g = self.cfg["general"]
        self.panic_picker.set_combo(g["panic_hotkey"])
        self.swap_picker.set_combo(g["swap_hotkey"])
        self.swap_pair_var.set(pair_label(g["swap_pair"]))
        self.panic_quits_var.set(g["panic_quits_app"])
        self.topmost_var.set(g["always_on_top"])
        self.record_moves_var.set(g["record_mouse_moves"])
        for toggle in (self.panic_quits_toggle, self.topmost_toggle,
                        self.record_moves_toggle):
            toggle.refresh()
