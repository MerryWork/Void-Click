"""Double-click launcher for running straight from this folder, without installing.

Windows runs .pyw through pythonw.exe, so no console window appears.
"""

import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from voidclick.run import main

if __name__ == "__main__":
    sys.exit(main())
