"""Global hotkey manager for keyboard keys and mouse buttons.

Hotkeys are matched against the set of inputs currently held down, so single
keys ("f6"), modifier combos ("ctrl+alt+h") and mouse buttons ("mouse_x1",
"ctrl+mouse_middle") all work the same way.
"""

from pynput import keyboard, mouse

from .input_guard import GUARD, KEY, MOUSE
from .safety import safe_call

_MODIFIER_NAMES = {
    keyboard.Key.ctrl_l: "ctrl",
    keyboard.Key.ctrl_r: "ctrl",
    keyboard.Key.alt_l: "alt",
    keyboard.Key.alt_r: "alt",
    keyboard.Key.alt_gr: "alt",
    keyboard.Key.shift_l: "shift",
    keyboard.Key.shift_r: "shift",
    keyboard.Key.cmd_l: "cmd",
    keyboard.Key.cmd_r: "cmd",
}
for _name in ("ctrl", "alt", "shift", "cmd"):
    _key = getattr(keyboard.Key, _name, None)
    if _key is not None:
        _MODIFIER_NAMES[_key] = _name

_MOUSE_TOKENS = {
    mouse.Button.left: "mouse_left",
    mouse.Button.middle: "mouse_middle",
    mouse.Button.right: "mouse_right",
}
# Side buttons are named differently per platform, and don't always exist.
for _attr, _token in (("x1", "mouse_x1"), ("x2", "mouse_x2"),
                      ("button8", "mouse_x1"), ("button9", "mouse_x2")):
    _button = getattr(mouse.Button, _attr, None)
    if _button is not None:
        _MOUSE_TOKENS[_button] = _token

_FRIENDLY = {
    "ctrl": "Ctrl", "alt": "Alt", "shift": "Shift", "cmd": "Cmd",
    "mouse_left": "Left Click", "mouse_right": "Right Click",
    "mouse_middle": "Middle Click", "mouse_x1": "Mouse 4", "mouse_x2": "Mouse 5",
    "space": "Space", "esc": "Esc", "enter": "Enter", "tab": "Tab",
}

_MODIFIER_ORDER = {"ctrl": 0, "alt": 1, "shift": 2, "cmd": 3}


def key_to_token(key):
    if key in _MODIFIER_NAMES:
        return _MODIFIER_NAMES[key]
    if isinstance(key, keyboard.KeyCode):
        if key.char is not None:
            return key.char.lower()
        return f"vk{key.vk}"
    return key.name


def button_to_token(button):
    return _MOUSE_TOKENS.get(button, f"mouse_{getattr(button, 'name', 'unknown')}")


def combo_to_string(combo):
    parts = sorted(combo, key=lambda t: (_MODIFIER_ORDER.get(t, 99), t))
    return "+".join(parts)


def string_to_combo(s):
    return frozenset(s.split("+")) if s else frozenset()


def combo_to_label(combo_string):
    """Human-readable form for the UI, e.g. 'ctrl+mouse_x1' -> 'Ctrl + Mouse 4'."""
    if not combo_string:
        return "(none)"
    tokens = sorted(combo_string.split("+"), key=lambda t: (_MODIFIER_ORDER.get(t, 99), t))
    return " + ".join(_FRIENDLY.get(t, t.upper()) for t in tokens)


class HotkeyManager:
    def __init__(self):
        self._pressed = set()
        self._hotkeys = {}  # name -> (frozenset(tokens), on_press, on_release)
        self._held = set()  # hotkeys fired and not yet released (hold mode)
        self._capture_cb = None
        # Token emitted when each physical key went down, keyed by virtual key
        # code. A character key's token depends on shift: pressing shift+minus
        # reports "_" but releasing after shift is let go reports "-", so
        # matching on the token alone strands "_" in _pressed forever and
        # poisons every later hotkey match and capture.
        self._token_by_vk = {}
        self._capture_armed = True
        self._keyboard_listener = keyboard.Listener(
            on_press=self._on_key_press, on_release=self._on_key_release
        )
        self._mouse_listener = mouse.Listener(on_click=self._on_click)

    def start(self):
        self._keyboard_listener.start()
        self._mouse_listener.start()

    def stop(self):
        self._keyboard_listener.stop()
        self._mouse_listener.stop()

    def register(self, name, combo_string, callback, on_release=None):
        """Bind a hotkey. Pass on_release for hold-style behaviour: `callback`
        fires when the combo is pressed, `on_release` when it's let go."""
        self._hotkeys[name] = (string_to_combo(combo_string), callback, on_release)
        self._held.discard(name)

    def unregister(self, name):
        self._hotkeys.pop(name, None)
        self._held.discard(name)

    def begin_capture(self, on_captured):
        """on_captured(combo_string) fires once, on the next input pressed.

        Capture is disarmed until the mouse button that opened it is released,
        so clicking the picker button doesn't immediately assign Left Click.
        """
        self._capture_cb = on_captured
        self._capture_armed = False

    def _press(self, token, injected, kind):
        if self._capture_cb is not None:
            self._capture(token)
            return

        if injected or GUARD.active(kind):
            return

        self._pressed.add(token)
        self._fire_matches(token)

    def _fire_matches(self, token):
        """Fire hotkeys whose keys are all held — not only exact matches.

        Matching the held set exactly meant any unrelated key blocked every
        hotkey: holding W while gaming stopped right-click from triggering
        anything. A hotkey now fires when its keys are a subset of what's held
        and the key just pressed belongs to it, so extra keys are ignored and
        holding a hotkey doesn't re-fire it when something else is pressed.

        Only the most specific match runs, so binding both F6 and Ctrl+F6 still
        does the right thing rather than firing both.
        """
        current = frozenset(self._pressed)
        candidates = [
            (name, combo, callback)
            for name, (combo, callback, _) in self._hotkeys.items()
            if combo and token in combo and combo <= current
        ]
        if not candidates:
            return

        most_specific = max(len(combo) for _, combo, _ in candidates)
        for name, combo, callback in candidates:
            if len(combo) == most_specific:
                self._held.add(name)
                # pynput stops the listener if a callback raises, which would
                # silently kill every hotkey in the app.
                safe_call(callback)

    def _release(self, token):
        self._pressed.discard(token)
        for name in list(self._held):
            entry = self._hotkeys.get(name)
            if not entry:
                self._held.discard(name)
                continue
            combo, _, on_release = entry
            if token in combo:
                self._held.discard(name)
                safe_call(on_release)

    def _capture(self, token):
        if token in _MODIFIER_ORDER:
            self._pressed.add(token)  # accumulate; wait for the real key
            return
        if not self._capture_armed:
            return
        # A bare left click is a footgun as a hotkey; require a modifier with it.
        if token == "mouse_left" and not (self._pressed & set(_MODIFIER_ORDER)):
            return
        cb = self._capture_cb
        self._capture_cb = None
        safe_call(cb, combo_to_string(frozenset(self._pressed | {token})))

    def _on_key_press(self, key, injected=False):
        token = key_to_token(key)
        vk = getattr(key, "vk", None)
        if vk is not None:
            self._token_by_vk[vk] = token
        if self._capture_cb is not None:
            self._capture_armed = True  # keyboard capture needs no click debounce
        self._press(token, injected, KEY)

    def _on_key_release(self, key, injected=False):
        vk = getattr(key, "vk", None)
        token = self._token_by_vk.pop(vk, None) if vk is not None else None
        self._release(token if token is not None else key_to_token(key))

    def _on_click(self, x, y, button, pressed, injected=False):
        token = button_to_token(button)
        if pressed:
            self._press(token, injected, MOUSE)
        else:
            self._release(token)
            self._capture_armed = True
