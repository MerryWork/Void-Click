import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import theme
from .gui_widgets import HotkeyPicker, PageHeader
from .hotkey_conflicts import find_conflict
from .macro import MacroPlayer, MacroRecorder, load_macro, save_macro
from .rounded_button import RoundedButton
from .rounded_entry import RoundedEntry
from .rounded_select import RoundedSelect
from .speed_control import SpeedControl
from .transcribe import transcribe
from .toggle import ToggleSwitch


class MacroPage(ttk.Frame):
    def __init__(self, master, hotkey_manager, cfg, on_config_change, notify=None,
                 send_to_script=None):
        super().__init__(master, padding=16)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change
        self.notify = notify or (lambda message: None)
        self.send_to_script = send_to_script or (lambda steps: None)

        self.recorder = MacroRecorder(
            on_event_count=self._on_event_count,
            ignore_key_tokens=self._current_hotkey_tokens,
        )
        self.player = MacroPlayer(
            on_state_change=self._on_play_state_change,
            on_progress=self._on_progress,
        )
        self.events = []

        self._build_ui()
        self._register_hotkeys()

    def _current_hotkey_tokens(self):
        tokens = set()
        for s in (self.cfg["macro"]["record_hotkey"], self.cfg["macro"]["play_hotkey"]):
            tokens |= set(s.split("+"))
        return tokens

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}
        PageHeader(self, "Macro Recorder").grid(
            row=0, column=0, columnspan=2, sticky="ew", pady=(0, 12)
        )
        self.columnconfigure(1, weight=1)

        row = 1
        ttk.Label(self, text="Record hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.record_picker = HotkeyPicker(
            self, self.hotkey_manager, self.cfg["macro"]["record_hotkey"], self._on_record_hotkey_change
        )
        self.record_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Play hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.play_picker = HotkeyPicker(
            self, self.hotkey_manager, self.cfg["macro"]["play_hotkey"], self._on_play_hotkey_change
        )
        self.play_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Play mode:").grid(row=row, column=0, sticky="w", **pad)
        self.play_mode_var = tk.StringVar(value=self.cfg["macro"]["play_hotkey_mode"])
        RoundedSelect(self, self.play_mode_var, ["toggle", "hold"],
                       command=self._on_play_mode_change).grid(
            row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Loop count:").grid(row=row, column=0, sticky="w", **pad)
        self.loop_var = tk.StringVar(value=str(self.cfg["macro"]["loop_count"]))
        self.loop_entry = RoundedEntry(self, self.loop_var, width=8)
        self.loop_entry.grid(row=row, column=1, sticky="w", **pad)
        self.loop_entry.bind_commit(self._commit_loop)
        row += 1

        ttk.Label(self, text="Playback speed:").grid(row=row, column=0, sticky="w", **pad)
        self.speed_control = SpeedControl(
            self, self.cfg["macro"]["playback_speed"], self._on_speed_change)
        self.speed_control.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        self.continuous_var = tk.BooleanVar(value=self.cfg["macro"]["continuous_loop"])
        self.continuous_toggle = ToggleSwitch(
            self, "Loop continuously (until stopped)", self.continuous_var,
            self._on_continuous_change,
        )
        self.continuous_toggle.grid(row=row, column=0, columnspan=2, sticky="w", **pad)
        row += 1
        self._update_loop_entry_state()

        btn_frm = ttk.Frame(self)
        btn_frm.grid(row=row, column=0, columnspan=2, sticky="ew", **pad)
        btn_frm.columnconfigure((0, 1), weight=1)
        self.record_btn = RoundedButton(
            btn_frm, "Record", command=self._toggle_record, bg=theme.GREEN,
            hover_bg=theme.GREEN_HOVER, fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.record_btn.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.play_btn = RoundedButton(
            btn_frm, "Play", command=self._toggle_play, bg=theme.GREEN,
            hover_bg=theme.GREEN_HOVER, fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.play_btn.grid(row=0, column=1, sticky="ew", padx=(4, 0))
        row += 1

        RoundedButton(
            self, "Convert to Script", command=self._to_script, bg=theme.BG_FIELD,
            hover_bg=theme.GREEN, fg=theme.FG, parent_bg=theme.BG_PANEL, height=30,
            font=("Segoe UI", 9),
        ).grid(row=row, column=0, columnspan=2, sticky="ew", **pad)
        row += 1

        btn_frm2 = ttk.Frame(self)
        btn_frm2.grid(row=row, column=0, columnspan=2, sticky="ew", **pad)
        btn_frm2.columnconfigure((0, 1, 2), weight=1)
        RoundedButton(
            btn_frm2, "Save...", command=self._save, bg=theme.BG_FIELD, hover_bg=theme.BORDER,
            fg=theme.FG, parent_bg=theme.BG_PANEL, height=32,
        ).grid(row=0, column=0, sticky="ew", padx=(0, 4))
        RoundedButton(
            btn_frm2, "Load...", command=self._load, bg=theme.BG_FIELD, hover_bg=theme.BORDER,
            fg=theme.FG, parent_bg=theme.BG_PANEL, height=32,
        ).grid(row=0, column=1, sticky="ew", padx=4)
        RoundedButton(
            btn_frm2, "Clear", command=self._clear, bg=theme.BG_FIELD, hover_bg=theme.BORDER,
            fg=theme.FG, parent_bg=theme.BG_PANEL, height=32,
        ).grid(row=0, column=2, sticky="ew", padx=(4, 0))
        row += 1

        self.status_var = tk.StringVar(value="Idle — 0 events")
        ttk.Label(self, textvariable=self.status_var, style="Value.TLabel").grid(
            row=row, column=0, columnspan=2, **pad
        )

    def refresh_from_config(self):
        m = self.cfg["macro"]
        self.record_picker.set_combo(m["record_hotkey"])
        self.play_picker.set_combo(m["play_hotkey"])
        self.loop_var.set(str(m["loop_count"]))
        self.play_mode_var.set(m["play_hotkey_mode"])
        self.speed_control.set_speed(m["playback_speed"])
        self.player.speed = float(m["playback_speed"])
        self.continuous_var.set(m["continuous_loop"])
        self.continuous_toggle.refresh()
        self._update_loop_entry_state()
        self._register_hotkeys()

    def _commit_loop(self):
        try:
            v = int(self.loop_var.get())
            if v < 0:
                raise ValueError
        except ValueError:
            v = self.cfg["macro"]["loop_count"]
        self.loop_var.set(str(v))
        self.cfg["macro"]["loop_count"] = v
        self.on_config_change()

    def _on_speed_change(self, speed):
        self.cfg["macro"]["playback_speed"] = speed
        self.player.speed = speed
        self.on_config_change()

    def _on_continuous_change(self):
        self.cfg["macro"]["continuous_loop"] = self.continuous_var.get()
        self.on_config_change()
        self._update_loop_entry_state()

    def _update_loop_entry_state(self):
        self.loop_entry.config(state="disabled" if self.continuous_var.get() else "normal")

    def _on_record_hotkey_change(self, combo_string):
        self.cfg["macro"]["record_hotkey"] = self._checked(
            "record_hotkey", combo_string, self.record_picker)
        self.on_config_change()
        self._register_hotkeys()

    def _on_play_hotkey_change(self, combo_string):
        self.cfg["macro"]["play_hotkey"] = self._checked(
            "play_hotkey", combo_string, self.play_picker)
        self.on_config_change()
        self._register_hotkeys()

    def _checked(self, key, combo_string, picker):
        """Blank the binding and warn if another action already owns this key."""
        clash = find_conflict(self.cfg, "macro", key, combo_string)
        if not clash:
            return combo_string
        picker.set_combo("")
        self.notify(f"Already used by {clash} — pick another key")
        return ""

    def _on_play_mode_change(self):
        self.cfg["macro"]["play_hotkey_mode"] = self.play_mode_var.get()
        self.on_config_change()
        self._register_hotkeys()

    def _register_hotkeys(self):
        self.hotkey_manager.register(
            "macro_record", self.cfg["macro"]["record_hotkey"], self._toggle_record_from_hotkey
        )
        play_combo = self.cfg["macro"]["play_hotkey"]
        if self.cfg["macro"]["play_hotkey_mode"] == "hold":
            self.hotkey_manager.register(
                "macro_play", play_combo,
                lambda: self.after(0, self._start_play),
                on_release=lambda: self.after(0, self.player.stop),
            )
        else:
            self.hotkey_manager.register("macro_play", play_combo, self._toggle_play_from_hotkey)

    def _toggle_record_from_hotkey(self):
        self.after(0, self._toggle_record)

    def _toggle_play_from_hotkey(self):
        self.after(0, self._toggle_play)

    def force_stop_recording(self):
        """Used by the panic stop — end a recording without toggling one back on."""
        if self.recorder.recording:
            self._toggle_record()

    def _toggle_record(self):
        if self.recorder.recording:
            self.recorder.stop()
            self.events = self.recorder.events
            self.record_btn.set_text("Record")
            self.record_btn.set_colors(theme.GREEN, theme.GREEN_HOVER)
            self.status_var.set(f"Idle — {len(self.events)} events recorded")
        else:
            if self.player.playing:
                return
            self.recorder.start()
            self.record_btn.set_text("Stop Recording")
            self.record_btn.set_colors(theme.ORANGE, theme.ORANGE_HOVER)
            self.status_var.set("Recording... 0 events")

    def _toggle_play(self):
        if self.player.playing:
            self.player.stop()
        else:
            self._start_play()

    def _start_play(self):
        if self.player.playing or self.recorder.recording or not self.events:
            return
        if self.continuous_var.get():
            loops = 0
        else:
            try:
                loops = max(int(self.loop_var.get()), 1)
            except ValueError:
                loops = 1
        self.player.play(self.events, loop_count=loops)

    def _on_event_count(self, count):
        self.after(0, lambda: self.status_var.set(f"Recording... {count} events"))

    def _on_play_state_change(self, playing):
        def upd():
            self.play_btn.set_text("Stop" if playing else "Play")
            self.play_btn.set_colors(
                theme.ORANGE if playing else theme.GREEN,
                theme.ORANGE_HOVER if playing else theme.GREEN_HOVER,
            )
            if not playing:
                self.status_var.set(f"Idle — {len(self.events)} events")
        self.after(0, upd)

    def _on_progress(self, loop, loop_count):
        def upd():
            if loop_count > 0:
                self.status_var.set(f"Playing loop {loop}/{loop_count}")
            else:
                self.status_var.set(f"Playing loop {loop}")
        self.after(0, upd)

    def _save(self):
        if not self.events:
            messagebox.showinfo("Save Macro", "No events to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("Macro files", "*.json")])
        if path:
            save_macro(path, self.events)

    def _load(self):
        path = filedialog.askopenfilename(filetypes=[("Macro files", "*.json")])
        if path:
            try:
                self.events = load_macro(path)
                self.status_var.set(f"Idle — {len(self.events)} events loaded")
            except (OSError, ValueError, KeyError) as e:
                messagebox.showerror("Load Macro", f"Failed to load macro:\n{e}")

    def _to_script(self):
        """Offer to rebuild the recording as editable, position-free script steps."""
        if not self.events:
            messagebox.showinfo("Convert to Script", "Record or load a macro first.")
            return

        steps, report = transcribe(self.events)
        if not steps:
            messagebox.showerror(
                "Convert to Script",
                "Nothing could be converted.\n\n" + "\n".join(report.warnings))
            return

        message = f"{report.summary()}\n\nThis becomes {len(steps)} step(s)."
        if report.warnings:
            message += "\n\nWon't carry across:\n  - " + "\n  - ".join(report.warnings)
        message += "\n\nReplace whatever is on the Script page?"

        if messagebox.askyesno("Convert to Script", message):
            self.send_to_script(steps)

    def _clear(self):
        self.events = []
        self.status_var.set("Idle — 0 events")
