"""Macro recording and playback: mouse moves/clicks/scroll + keyboard events."""

import json
import threading
import time
import traceback
from dataclasses import asdict, dataclass, field
from typing import List

from pynput import keyboard, mouse

from .hotkeys import button_to_token, key_to_token
from .input_guard import GUARD, KEY, MOUSE
from .safety import safe_call

BUTTON_NAMES = {mouse.Button.left: "left", mouse.Button.right: "right", mouse.Button.middle: "middle"}
BUTTON_FROM_NAME = {v: k for k, v in BUTTON_NAMES.items()}


def key_to_str(key):
    return str(key)


def str_to_key(s):
    if s.startswith("Key."):
        return getattr(keyboard.Key, s.split(".", 1)[1])
    return keyboard.KeyCode.from_char(s.strip("'"))


@dataclass
class MacroEvent:
    type: str  # move | click | scroll | key_press | key_release
    t: float   # seconds since recording start
    data: dict = field(default_factory=dict)


class MacroRecorder:
    def __init__(self, on_event_count=None, ignore_key_tokens=None):
        self.events: List[MacroEvent] = []
        self._recording = False
        self._start_time = 0.0
        self._mouse_listener = None
        self._keyboard_listener = None
        self._last_move_t = 0.0

        self.on_event_count = on_event_count
        self.ignore_key_tokens = ignore_key_tokens or (lambda: set())
        self.record_mouse_moves = True
        self.move_min_interval = 0.02  # throttle move sampling to ~50Hz

    @property
    def recording(self):
        return self._recording

    def start(self):
        if self._recording:
            return
        self.events = []
        self._start_time = time.time()
        self._last_move_t = 0.0
        self._recording = True
        self._mouse_listener = mouse.Listener(
            on_move=self._on_move, on_click=self._on_click, on_scroll=self._on_scroll
        )
        self._keyboard_listener = keyboard.Listener(on_press=self._on_press, on_release=self._on_release)
        self._mouse_listener.start()
        self._keyboard_listener.start()

    def stop(self):
        self._recording = False
        if self._mouse_listener:
            self._mouse_listener.stop()
            self._mouse_listener = None
        if self._keyboard_listener:
            self._keyboard_listener.stop()
            self._keyboard_listener = None

    def _elapsed(self):
        return time.time() - self._start_time

    def _add(self, type_, data):
        self.events.append(MacroEvent(type=type_, t=self._elapsed(), data=data))
        # Runs on the pynput listener thread — a raising callback would stop
        # the listener and silently end the recording.
        safe_call(self.on_event_count, len(self.events))

    def _on_move(self, x, y):
        if not self._recording or not self.record_mouse_moves or GUARD.active(MOUSE):
            return
        now = self._elapsed()
        if now - self._last_move_t < self.move_min_interval:
            return
        self._last_move_t = now
        self._add("move", {"x": x, "y": y})

    def _on_click(self, x, y, button, pressed, injected=False):
        if not self._recording or injected or GUARD.active(MOUSE):
            return
        if button_to_token(button) in self.ignore_key_tokens():
            return
        self._add("click", {"x": x, "y": y, "button": BUTTON_NAMES.get(button, "left"), "pressed": pressed})

    def _on_scroll(self, x, y, dx, dy, injected=False):
        if not self._recording or injected or GUARD.active(MOUSE):
            return
        self._add("scroll", {"x": x, "y": y, "dx": dx, "dy": dy})

    def _on_press(self, key, injected=False):
        if not self._recording or injected or GUARD.active(KEY):
            return
        if key_to_token(key) in self.ignore_key_tokens():
            return
        self._add("key_press", {"key": key_to_str(key)})

    def _on_release(self, key, injected=False):
        if not self._recording or injected or GUARD.active(KEY):
            return
        if key_to_token(key) in self.ignore_key_tokens():
            return
        self._add("key_release", {"key": key_to_str(key)})


def save_macro(path, events):
    with open(path, "w") as f:
        json.dump([asdict(e) for e in events], f, indent=2)


def load_macro(path):
    with open(path) as f:
        raw = json.load(f)
    return [MacroEvent(**e) for e in raw]


class MacroPlayer:
    def __init__(self, on_state_change=None, on_progress=None):
        self._mouse = mouse.Controller()
        self._keyboard = keyboard.Controller()
        self._running = threading.Event()
        self._thread = None
        self.on_state_change = on_state_change
        self.on_progress = on_progress
        self.speed = 1.0
        self.last_error = None
        self._generation = 0

    @property
    def playing(self):
        return self._running.is_set()

    def play(self, events, loop_count=1):
        if not events:
            return
        self._halt_current()
        self.last_error = None
        self._generation += 1
        generation = self._generation
        self._running.set()
        self._thread = threading.Thread(
            target=self._run, args=(events, loop_count, generation), daemon=True)
        self._thread.start()
        safe_call(self.on_state_change, True)

    def stop(self):
        self._running.clear()

    def _current(self, generation):
        """True while this run is both wanted and still the newest one."""
        return self._running.is_set() and generation == self._generation

    def _halt_current(self):
        """End the previous run and wait for its thread, so two never overlap."""
        self._running.clear()
        thread = self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)

    def _run(self, events, loop_count, generation):
        # Cleanup in finally: without it, one raising event left the player
        # stuck 'playing' and it could never be started again.
        try:
            self._play_loop(events, loop_count, generation)
        except Exception:
            self.last_error = traceback.format_exc()
            traceback.print_exc()
        finally:
            # Only tidy up if a newer run hasn't already taken over, or a
            # finishing old thread would switch the new one off.
            if generation == self._generation:
                self._running.clear()
                safe_call(self.on_state_change, False)

    def _play_loop(self, events, loop_count, generation):
        loop = 0
        while self._current(generation) and (loop_count <= 0 or loop < loop_count):
            t0 = time.time()
            for ev in events:
                if not self._current(generation):
                    break
                target = t0 + ev.t / max(self.speed, 0.05)
                while True:
                    remaining = target - time.time()
                    if remaining <= 0 or not self._current(generation):
                        break
                    time.sleep(min(remaining, 0.01))
                if not self._current(generation):
                    break
                self._execute(ev)
            loop += 1
            safe_call(self.on_progress, loop, loop_count)

    def _execute(self, ev):
        GUARD.mark(MOUSE if ev.type in ("move", "click", "scroll") else KEY)
        if ev.type == "move":
            self._mouse.position = (ev.data["x"], ev.data["y"])
        elif ev.type == "click":
            self._mouse.position = (ev.data["x"], ev.data["y"])
            btn = BUTTON_FROM_NAME.get(ev.data["button"], mouse.Button.left)
            if ev.data["pressed"]:
                self._mouse.press(btn)
            else:
                self._mouse.release(btn)
        elif ev.type == "scroll":
            self._mouse.scroll(ev.data["dx"], ev.data["dy"])
        elif ev.type == "key_press":
            self._keyboard.press(str_to_key(ev.data["key"]))
        elif ev.type == "key_release":
            self._keyboard.release(str_to_key(ev.data["key"]))
