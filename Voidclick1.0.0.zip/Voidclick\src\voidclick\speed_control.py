"""A slow-down / speed-up control.

Macro playback and script runs each own their speed, so this is placed on both
pages rather than shared through Settings.
"""

import tkinter as tk
from tkinter import ttk

from . import theme
from .quick_actions import step_speed
from .rounded_button import RoundedButton


class SpeedControl(ttk.Frame):
    def __init__(self, master, initial, on_change):
        super().__init__(master)
        self.speed = float(initial)
        self.on_change = on_change

        RoundedButton(
            self, "-", command=lambda: self._step(-1), bg=theme.BG_FIELD,
            hover_bg=theme.ORANGE, fg=theme.FG, parent_bg=theme.BG_PANEL,
            width=32, height=26, radius=8, font=("Segoe UI", 11, "bold"),
        ).pack(side="left")

        self.label = ttk.Label(self, text=self._text(), style="Value.TLabel", width=6,
                                anchor="center")
        self.label.pack(side="left", padx=6)

        RoundedButton(
            self, "+", command=lambda: self._step(1), bg=theme.BG_FIELD,
            hover_bg=theme.GREEN, fg=theme.FG, parent_bg=theme.BG_PANEL,
            width=32, height=26, radius=8, font=("Segoe UI", 11, "bold"),
        ).pack(side="left")

    def _text(self):
        return f"{self.speed:g}x"

    def _step(self, direction):
        new_speed = step_speed(self.speed, direction)
        if new_speed == self.speed:
            return
        self.speed = new_speed
        self.label.config(text=self._text())
        self.on_change(new_speed)

    def set_speed(self, value):
        """Update the display without firing the change callback."""
        self.speed = float(value)
        self.label.config(text=self._text())
