from .config import load_config, save_config
from .gui_app import MainWindow
from .hotkeys import HotkeyManager


def main():
    cfg = load_config()
    hotkey_manager = HotkeyManager()

    def on_config_change():
        save_config(cfg)

    app = MainWindow(hotkey_manager, cfg, on_config_change)
    hotkey_manager.start()

    def on_close():
        app.shutdown()
        app.destroy()

    app.protocol("WM_DELETE_WINDOW", on_close)
    app.mainloop()
    return 0
