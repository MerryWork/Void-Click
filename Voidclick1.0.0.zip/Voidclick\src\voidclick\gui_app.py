import tkinter as tk
from tkinter import ttk

from . import icons, theme
from .gui_autoclicker import AutoClickerPage
from .gui_macro import MacroPage
from .gui_script import ScriptPage
from .gui_settings import SettingsPage
from .gui_widgets import Banner, ScrollFrame
from .hotkey_conflicts import Throttle
from .quick_actions import swap_hotkeys
from .rounded_button import RoundedButton
from .winstyle import apply_dark_titlebar

APP_NAME = "Void Click"

NAV_ITEMS = [
    ("autoclicker", icons.mouse, "Clicker"),
    ("macro", icons.record, "Macro"),
    ("script", icons.steps, "Script"),
    ("settings", icons.gear, "Settings"),
]


class MainWindow(tk.Tk):
    """Single window: a left icon rail switches between Clicker / Macro / Settings pages."""

    def __init__(self, hotkey_manager, cfg, on_config_change):
        super().__init__()
        self.title(APP_NAME)
        # Comfortably above the tallest page's natural size (Settings, ~561) so
        # spare space goes to the weighted control column instead of clipping.
        self.geometry("580x610")
        self.resizable(False, False)
        theme.apply(self)
        apply_dark_titlebar(self)
        # Held on the instance so Tk doesn't garbage-collect the image.
        self._icon_image = icons.make_window_icon(tk, badge_color=theme.GREEN,
                                                   bolt_color=theme.TEXT_ON_ACCENT)
        self.iconphoto(True, self._icon_image)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change

        self._nav_buttons = {}
        self._build_pages()
        self._build_sidebar()
        self._show_page("autoclicker")
        self.apply_runtime_settings()

    # ------------------------------------------------------------------ layout

    def _build_sidebar(self):
        sidebar = tk.Frame(self, bg=theme.BG_SIDEBAR, width=84)
        sidebar.grid(row=0, column=0, sticky="ns")
        sidebar.grid_propagate(False)
        sidebar.columnconfigure(0, weight=1)

        brand = tk.Canvas(sidebar, height=46, bg=theme.BG_SIDEBAR, highlightthickness=0, bd=0)
        brand.grid(row=0, column=0, sticky="ew", padx=8, pady=(14, 12))
        brand.bind("<Configure>", lambda e, c=brand: self._draw_brand(c))

        for i, (key, icon, label) in enumerate(NAV_ITEMS, start=1):
            btn = RoundedButton(
                sidebar, label, command=lambda k=key: self._show_page(k),
                bg=theme.BG_SIDEBAR, hover_bg=theme.BG_SIDEBAR_HOVER, fg=theme.FG_MUTED,
                parent_bg=theme.BG_SIDEBAR, radius=14, height=64,
                font=("Segoe UI", 9), icon=icon, icon_size=20,
                # Full sheen on a near-black button reads as a stray line.
                sheen=0.4,
            )
            btn.grid(row=i, column=0, sticky="ew", padx=8, pady=4)
            self._nav_buttons[key] = btn

        spacer_row = len(NAV_ITEMS) + 1
        tk.Frame(sidebar, bg=theme.BG_SIDEBAR).grid(row=spacer_row, column=0, sticky="nsew")
        sidebar.rowconfigure(spacer_row, weight=1)

    def _draw_brand(self, canvas):
        canvas.delete("all")
        w = max(canvas.winfo_width(), 1)
        h = max(canvas.winfo_height(), 1)
        icons.logo(canvas, w / 2, h / 2, min(h, 38), theme.GREEN, theme.TEXT_ON_ACCENT)

    def _build_pages(self):
        container = ttk.Frame(self)
        container.grid(row=0, column=1, sticky="nsew")
        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)
        self._container = container

        # Settings is taller than the window, so it lives inside a scroller.
        settings_scroll = ScrollFrame(container)
        settings_page = SettingsPage(
            settings_scroll.interior, self.hotkey_manager, self.cfg, self.on_config_change,
            self.apply_runtime_settings, self._on_settings_reset, self.show_banner)
        settings_page.pack(fill="both", expand=True)

        self.pages = {
            "autoclicker": AutoClickerPage(container, self.hotkey_manager, self.cfg,
                                            self.on_config_change, self.show_banner),
            "macro": MacroPage(container, self.hotkey_manager, self.cfg,
                                self.on_config_change, self.show_banner,
                                self.adopt_script),
            "script": ScriptPage(container, self.hotkey_manager, self.cfg,
                                  self.on_config_change, self.show_banner),
            "settings": settings_page,
        }
        # What actually gets raised: for Settings that's the scroller, not the page.
        self._page_frames = dict(self.pages, settings=settings_scroll)
        for frame in self._page_frames.values():
            frame.grid(row=0, column=0, sticky="nsew")

        # Owned by the window, not the container: switching pages calls
        # tkraise() on a page, which would otherwise stack it over the banner.
        # place(in_=container) still positions it across the content area.
        self._banner = Banner(self)
        self._banner_throttle = Throttle(seconds=1.0)

    def show_banner(self, message):
        """Float a message for one second, ignoring repeats while it's up."""
        if not self._banner_throttle.allow():
            return
        self._banner.show(message)
        # Sits under the page header rather than across it.
        self._banner.place(in_=self._container, relx=0.5, y=60, anchor="n")
        # Canvas rebinds lift/tkraise to its item-raise command, so the widget
        # stacking version has to be called explicitly.
        tk.Misc.lift(self._banner)
        self.after(1000, self._hide_banner)

    def _hide_banner(self):
        self._banner.place_forget()
        self._banner_throttle.reset()

    def _show_page(self, key):
        for name, btn in self._nav_buttons.items():
            active = name == key
            btn.set_colors(
                theme.GREEN if active else theme.BG_SIDEBAR,
                theme.GREEN_HOVER if active else theme.BG_SIDEBAR_HOVER,
                theme.TEXT_ON_ACCENT if active else theme.FG_MUTED,
            )
        self._page_frames[key].tkraise()

    # ------------------------------------------------------------------ settings

    def apply_runtime_settings(self):
        g = self.cfg["general"]
        self.attributes("-topmost", bool(g["always_on_top"]))
        self.pages["macro"].recorder.record_mouse_moves = bool(g["record_mouse_moves"])
        # Macro and script each own their playback speed, set on their own page.
        self.pages["macro"].player.speed = float(self.cfg["macro"]["playback_speed"])
        self.pages["script"].runner.speed = float(self.cfg["script"]["speed"])

        self.hotkey_manager.register(
            "panic", g["panic_hotkey"], lambda: self.after(0, self.panic)
        )
        self.hotkey_manager.register(
            "swap", g["swap_hotkey"], lambda: self.after(0, self.swap_action_hotkeys)
        )

    def adopt_script(self, steps):
        """Take converted steps onto the Script page and show the result."""
        self.pages["script"].load_steps(steps)
        self._show_page("script")
        self.show_banner(f"Converted to {len(steps)} step(s)")

    def swap_action_hotkeys(self):
        """Trade the configured pair's start hotkeys, live."""
        left, right = swap_hotkeys(self.cfg, self.cfg["general"]["swap_pair"])
        self.on_config_change()
        for page in self.pages.values():
            page.refresh_from_config()
        self.apply_runtime_settings()
        self.show_banner(f"Swapped {left} <-> {right}")


    def _on_settings_reset(self):
        for page in self.pages.values():
            page.refresh_from_config()
        self.apply_runtime_settings()

    # ------------------------------------------------------------------ control

    def panic(self):
        """Emergency stop: halt everything immediately, however it was started."""
        self.pages["autoclicker"].clicker.stop()
        self.pages["macro"].player.stop()
        self.pages["macro"].force_stop_recording()
        self.pages["script"].runner.stop()
        if self.cfg["general"]["panic_quits_app"]:
            self.after(150, self._quit_from_panic)

    def _quit_from_panic(self):
        self.hotkey_manager.stop()
        self.on_config_change()
        self.destroy()

    def shutdown(self):
        self.pages["autoclicker"].clicker.stop()
        self.pages["macro"].player.stop()
        self.pages["macro"].recorder.stop()
        self.pages["script"].runner.stop()
        self.hotkey_manager.stop()
        self.on_config_change()
