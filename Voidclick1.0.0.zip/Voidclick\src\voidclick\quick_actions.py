"""Runtime adjustments driven by hotkeys: swapping bindings and stepping speed."""

# Which start hotkey belongs to each swappable action.
SWAPPABLE = {
    "autoclicker": ("autoclicker", "hotkey", "autoclicker"),
    "macro": ("macro", "play_hotkey", "macro play"),
    "script": ("script", "hotkey", "script run"),
}

PAIRS = ["autoclicker|macro", "autoclicker|script", "macro|script"]


def pair_label(pair):
    left, right = split_pair(pair)
    return f"{SWAPPABLE[left][2]} <-> {SWAPPABLE[right][2]}"


def split_pair(pair):
    left, _, right = pair.partition("|")
    if left not in SWAPPABLE or right not in SWAPPABLE:
        left, right = PAIRS[0].split("|")
    return left, right


def swap_hotkeys(cfg, pair):
    """Trade the two actions' start hotkeys. Returns their display names.

    Swapping can't create a conflict: the two keys were already distinct and
    they only change places.
    """
    left, right = split_pair(pair)
    left_section, left_key, left_name = SWAPPABLE[left]
    right_section, right_key, right_name = SWAPPABLE[right]

    cfg[left_section][left_key], cfg[right_section][right_key] = (
        cfg[right_section][right_key],
        cfg[left_section][left_key],
    )
    return left_name, right_name


# Speeds the up/down hotkeys step through.
SPEED_STEPS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0]


def step_speed(current, direction):
    """Next speed up (+1) or down (-1) the ladder, clamped at both ends."""
    try:
        current = float(current)
    except (TypeError, ValueError):
        current = 1.0

    # Land on the nearest rung first, so a hand-typed speed still steps sanely.
    nearest = min(range(len(SPEED_STEPS)), key=lambda i: abs(SPEED_STEPS[i] - current))
    index = min(max(nearest + direction, 0), len(SPEED_STEPS) - 1)
    return SPEED_STEPS[index]
