import tkinter as tk
from tkinter import ttk

from . import gradient, theme
from .hotkeys import combo_to_label


class PageHeader(tk.Canvas):
    """Page title on a soft gradient band with a green-to-orange accent stripe."""

    def __init__(self, master, text, height=46, **kw):
        super().__init__(master, height=height, highlightthickness=0, bd=0,
                          bg=theme.BG_PANEL, **kw)
        self.text = text
        self.bind("<Configure>", lambda e: self._draw())
        self._draw()

    def _draw(self):
        self.delete("all")
        w = max(self.winfo_width(), 1)
        h = max(self.winfo_height(), 1)
        gradient.glass(self, 0, 0, w, h, 10, theme.BG_PANEL, intensity=0.55)
        gradient.rounded(self, 0, h * 0.22, 4, h * 0.78, 2, theme.GREEN, theme.ORANGE)
        self.create_text(16, h / 2, text=self.text, anchor="w", fill=theme.FG,
                          font=("Segoe UI", 14, "bold"))


class ScrollFrame(ttk.Frame):
    """A vertically scrollable container — put content in `.interior`.

    Settings outgrew the window once swap and speed bindings were added, and
    it's the page that keeps growing, so it scrolls instead of forcing the
    whole window taller.
    """

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        self.canvas = tk.Canvas(self, highlightthickness=0, bd=0, bg=theme.BG_PANEL)
        self.scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=self.scrollbar.set)
        self.canvas.grid(row=0, column=0, sticky="nsew")
        self.scrollbar.grid(row=0, column=1, sticky="ns")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.interior = ttk.Frame(self.canvas)
        self._window = self.canvas.create_window(0, 0, window=self.interior, anchor="nw")

        self.interior.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind(
            "<Configure>",
            lambda e: self.canvas.itemconfigure(self._window, width=e.width))
        # Only capture the wheel while the pointer is actually over this page.
        self.canvas.bind("<Enter>", lambda e: self.canvas.bind_all("<MouseWheel>", self._wheel))
        self.canvas.bind("<Leave>", lambda e: self.canvas.unbind_all("<MouseWheel>"))

    def _wheel(self, event):
        self.canvas.yview_scroll(int(-event.delta / 120), "units")


class Banner(tk.Canvas):
    """A transient message strip, floated over the top of the page."""

    def __init__(self, master, height=32, **kw):
        super().__init__(master, height=height, highlightthickness=0, bd=0,
                          bg=theme.BG_PANEL, **kw)
        self._text = ""
        self._height = height

    def show(self, message):
        self._text = message
        self.configure(width=len(message) * 7 + 34)
        self._draw()

    def _draw(self):
        self.delete("all")
        w = max(self.winfo_reqwidth(), int(self["width"]))
        h = self._height
        gradient.glass(self, 0, 0, w, h, h // 2, theme.ORANGE, bg=theme.BG_PANEL)
        self.create_text(w / 2, h / 2, text=self._text, fill=theme.TEXT_ON_ACCENT,
                          font=("Segoe UI", 9, "bold"))


class HotkeyPicker(tk.Frame):
    """A button showing the current hotkey; click it, then press the new key or mouse button."""

    def __init__(self, master, hotkey_manager, initial_combo, on_change, **kw):
        super().__init__(master, bg=theme.BG_PANEL, **kw)
        self.hotkey_manager = hotkey_manager
        self.on_change = on_change
        self.combo = initial_combo

        self.label_var = tk.StringVar(value=combo_to_label(initial_combo))
        self.btn = tk.Button(
            self, textvariable=self.label_var, width=16, command=self._start_capture,
            bg=theme.BG_FIELD, fg=theme.FG, activebackground=theme.GREEN_HOVER,
            activeforeground=theme.TEXT_ON_ACCENT, disabledforeground=theme.TEXT_ON_ACCENT,
            relief="flat", bd=0, highlightthickness=1, highlightbackground=theme.BORDER,
            padx=6, pady=4, cursor="hand2",
        )
        self.btn.pack(side="left")

    def set_combo(self, combo_string):
        self.combo = combo_string
        self.label_var.set(combo_to_label(combo_string))

    def _start_capture(self):
        self.label_var.set("Press keys...")
        self.btn.config(state="disabled", bg=theme.ORANGE)
        self.hotkey_manager.begin_capture(self._captured)

    def _captured(self, combo_string):
        # Runs on the pynput listener thread; hop back to the Tk main thread.
        self.after(0, self._apply_capture, combo_string)

    def _apply_capture(self, combo_string):
        self.set_combo(combo_string)
        self.btn.config(state="normal", bg=theme.BG_FIELD)
        self.on_change(combo_string)
