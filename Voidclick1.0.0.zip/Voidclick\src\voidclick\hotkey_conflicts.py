"""Keeps the action hotkeys distinct from one another.

Two actions sharing a key is never what someone means: with subset matching both
would fire at once, so one of them is silently unusable.
"""

import time

# (config section, config key, name shown to the user)
MANAGED = [
    ("autoclicker", "hotkey", "the autoclicker"),
    ("macro", "record_hotkey", "macro record"),
    ("macro", "play_hotkey", "macro play"),
    ("script", "hotkey", "the script runner"),
    ("general", "panic_hotkey", "the panic stop"),
    ("general", "swap_hotkey", "the hotkey swap"),
]


def find_conflict(cfg, section, key, combo):
    """Name of another managed hotkey already using `combo`, or None.

    Empty bindings never conflict — clearing one is how a conflict is resolved,
    so two blank hotkeys must be allowed to coexist.
    """
    if not combo:
        return None
    for other_section, other_key, label in MANAGED:
        if (other_section, other_key) == (section, key):
            continue
        if cfg[other_section][other_key] == combo:
            return label
    return None


class Throttle:
    """Lets an event through at most once per window.

    Spamming a conflicting key would otherwise stack a banner per attempt; while
    one is still showing, further requests are dropped rather than queued.
    """

    def __init__(self, seconds=1.0):
        self.seconds = seconds
        self._until = 0.0

    def allow(self):
        now = time.monotonic()
        if now < self._until:
            return False
        self._until = now + self.seconds
        return True

    def reset(self):
        self._until = 0.0
