"""Gradient fills for Canvas widgets.

Tk has no gradient primitive, so gradients are painted one scanline at a time
with an interpolated colour. For rounded shapes each scanline is inset to follow
the corner arc, keeping the rounded silhouette intact.
"""

import math


def _to_rgb(color):
    color = color.lstrip("#")
    return int(color[0:2], 16), int(color[2:4], 16), int(color[4:6], 16)


def _to_hex(rgb):
    return "#%02x%02x%02x" % tuple(max(0, min(255, int(round(c)))) for c in rgb)


def lerp(color_a, color_b, t):
    a, b = _to_rgb(color_a), _to_rgb(color_b)
    return _to_hex(tuple(a[i] + (b[i] - a[i]) * t for i in range(3)))


def lighten(color, amount=0.12):
    return lerp(color, "#ffffff", amount)


def darken(color, amount=0.12):
    return lerp(color, "#000000", amount)


def _corner_inset(y, top, bottom, radius):
    """How far this scanline pulls in to follow the rounded corners."""
    if radius <= 0:
        return 0.0
    if y < top + radius:
        dy = (top + radius) - y
    elif y > bottom - radius:
        dy = y - (bottom - radius)
    else:
        return 0.0
    dy = min(dy, radius)
    return radius - math.sqrt(max(radius * radius - dy * dy, 0.0))


def _fill(canvas, x1, y1, x2, y2, radius, color_at, bg=None, tags=()):
    """Paint scanlines between y1 and y2; color_at(t) gives the colour at 0..1.

    Each scanline stops on a whole pixel, which turns the corner arcs into
    visible stair-steps. Tk canvas has no anti-aliasing, so when `bg` is given
    the partially covered pixel at each end is drawn blended towards it — that
    is the anti-aliasing, done by hand.
    """
    height = max(y2 - y1, 1)
    for y in range(int(y1), int(math.ceil(y2))):
        inset = _corner_inset(y + 0.5, y1, y2, radius)
        left, right = x1 + inset, x2 - inset
        if right - left < 1:
            continue
        color = color_at((y - y1) / height)

        if bg is None:
            canvas.create_line(left, y, right, y, fill=color, tags=tags)
            continue

        inner_left, inner_right = int(math.ceil(left)), int(math.floor(right))
        if inner_right > inner_left:
            canvas.create_line(inner_left, y, inner_right, y, fill=color, tags=tags)

        left_coverage = inner_left - left
        if left_coverage > 0.02:
            canvas.create_line(inner_left - 1, y, inner_left, y,
                                fill=lerp(bg, color, min(left_coverage, 1.0)), tags=tags)

        right_coverage = right - inner_right
        if right_coverage > 0.02:
            canvas.create_line(inner_right, y, inner_right + 1, y,
                                fill=lerp(bg, color, min(right_coverage, 1.0)), tags=tags)


def rounded(canvas, x1, y1, x2, y2, radius, color_top, color_bottom, bg=None, tags=()):
    """Rounded rectangle with a straight linear gradient."""
    _fill(canvas, x1, y1, x2, y2, radius,
          lambda t: lerp(color_top, color_bottom, t), bg, tags)


# Glass profile: a bright specular band across the top half that falls away
# quickly, then a flatter, darker lower half. The step at the midpoint is what
# separates a glassy surface from a waxy top-to-bottom ramp.
_SPLIT = 0.5


def glass_color_at(base, t, intensity=1.0):
    if t < _SPLIT:
        local = t / _SPLIT
        return lerp(lighten(base, 0.30 * intensity),
                    lighten(base, 0.05 * intensity), local)
    local = (t - _SPLIT) / (1.0 - _SPLIT)
    return lerp(darken(base, 0.05 * intensity),
                darken(base, 0.18 * intensity), local)


def glass(canvas, x1, y1, x2, y2, radius, base, intensity=1.0, bg=None, tags=()):
    """Rounded rectangle with a glass-like sheen and a specular top edge."""
    _fill(canvas, x1, y1, x2, y2, radius,
          lambda t: glass_color_at(base, t, intensity), bg, tags)

    # Crisp highlight along the very top edge sells the glass reading.
    inset = _corner_inset(y1 + 1.5, y1, y2, radius)
    if (x2 - inset) - (x1 + inset) > 2:
        canvas.create_line(x1 + inset + 1, y1 + 1, x2 - inset - 1, y1 + 1,
                            fill=lighten(base, 0.48 * intensity), tags=tags)
