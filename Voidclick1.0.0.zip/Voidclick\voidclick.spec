# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller build spec — produces a standalone Void Click executable.

    pip install pyinstaller
    pyinstaller voidclick.spec

Output lands in dist/. The result needs no Python on the target machine.
"""

import sys

# pynput picks its backend at runtime via importlib, which PyInstaller's static
# analysis cannot see, so the platform backend has to be named explicitly.
if sys.platform == "win32":
    backends = ["pynput.keyboard._win32", "pynput.mouse._win32"]
elif sys.platform == "darwin":
    backends = ["pynput.keyboard._darwin", "pynput.mouse._darwin"]
else:
    backends = ["pynput.keyboard._xorg", "pynput.mouse._xorg"]

a = Analysis(
    ["launch.py"],
    pathex=["src"],
    binaries=[],
    datas=[],
    hiddenimports=backends,
    hookspath=[],
    runtime_hooks=[],
    excludes=["pytest", "numpy", "PIL"],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="VoidClick",
    debug=False,
    strip=False,
    upx=True,
    console=False,      # no console window behind the GUI
    disable_windowed_traceback=False,
)

# macOS: wrap the binary so it behaves like a normal .app bundle.
if sys.platform == "darwin":
    app = BUNDLE(
        exe,
        name="Void Click.app",
        bundle_identifier="com.voidclick.app",
        info_plist={
            "NSHighResolutionCapable": True,
            # Explains the Accessibility / Input Monitoring prompts on first run.
            "NSAppleEventsUsageDescription":
                "Void Click sends keyboard and mouse input on your behalf.",
        },
    )
