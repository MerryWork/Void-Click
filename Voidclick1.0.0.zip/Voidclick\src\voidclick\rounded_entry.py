"""A text field with rounded corners.

ttk.Entry can't round its corners, which left the inputs looking sharp against
the rounded buttons and toggles. This draws the field on a canvas and drops a
borderless tk.Entry into the flat middle of it, so the entry's own rectangular
background never reaches the rounded edge.
"""

import tkinter as tk

from . import gradient, theme


class RoundedEntry(tk.Frame):
    def __init__(self, master, textvariable, width=10, parent_bg=theme.BG_PANEL,
                 height=28, radius=8):
        super().__init__(master, bg=parent_bg)
        self.parent_bg = parent_bg
        self.radius = radius
        self.height = height
        self._focused = False

        # The entry must be a child of the canvas, not of this frame: page
        # switching calls tkraise(), and an embedded window belonging to a
        # sibling gets left behind in the stacking order and renders blank.
        self.canvas = tk.Canvas(self, height=height, highlightthickness=0,
                                 bd=0, bg=parent_bg)
        self.canvas.pack()

        self.entry = tk.Entry(
            self.canvas, textvariable=textvariable, width=width, bd=0, relief="flat",
            highlightthickness=0, bg=theme.BG_FIELD, fg=theme.FG,
            insertbackground=theme.FG, disabledbackground=theme.BG_FIELD,
            disabledforeground=theme.FG_MUTED, readonlybackground=theme.BG_FIELD,
            font=("Segoe UI", 9),
        )
        self.entry.update_idletasks()
        self.canvas.config(width=self.entry.winfo_reqwidth() + 2 * radius + 8)
        self.canvas.create_window(radius + 4, height // 2, window=self.entry, anchor="w")

        self.entry.bind("<FocusIn>", self._on_focus_in)
        self.entry.bind("<FocusOut>", self._on_focus_out)
        self.canvas.bind("<Configure>", lambda e: self._draw())
        self.canvas.bind("<Button-1>", lambda e: self.entry.focus_set())
        self._draw()

    def _on_focus_in(self, _event):
        self._focused = True
        self._draw()

    def _on_focus_out(self, _event):
        self._focused = False
        self._draw()

    def _draw(self):
        self.canvas.delete("field")
        w = max(self.canvas.winfo_width(), int(self.canvas["width"]))
        h = max(self.canvas.winfo_height(), self.height)
        r = min(self.radius, h // 2)

        gradient.rounded(self.canvas, 0, 0, w, h, r, theme.BG_FIELD, theme.BG_FIELD,
                          bg=self.parent_bg, tags="field")
        if self._focused:
            gradient.rounded(self.canvas, 0, h - 2, w, h, 0, theme.GREEN, theme.GREEN,
                              bg=theme.BG_FIELD, tags="field")
        self.canvas.tag_lower("field")

    def bind_commit(self, callback):
        """Commit on Return and when focus leaves, the pattern every page uses."""
        self.entry.bind("<Return>", lambda ev: callback())
        self.entry.bind("<FocusOut>", lambda ev: (self._on_focus_out(ev), callback()))

    def config(self, **kwargs):
        if "state" in kwargs:
            self.entry.config(state=kwargs.pop("state"))
            self._draw()
        if kwargs:
            super().config(**kwargs)

    configure = config
