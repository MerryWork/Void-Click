"""A dropdown with rounded corners.

ttk.Combobox can't be rounded and ignores most colour styling, which left square
grey dropdowns sitting between the rounded fields and buttons. This draws the
closed state on a canvas and uses a plain tk.Menu for the open list.
"""

import tkinter as tk

from . import gradient, theme


class RoundedSelect(tk.Frame):
    def __init__(self, master, variable, values, command=None, width=9,
                 parent_bg=theme.BG_PANEL, height=28, radius=8):
        super().__init__(master, bg=parent_bg)
        self.variable = variable
        self.values = list(values)
        self.command = command
        self.parent_bg = parent_bg
        self.radius = radius
        self.height = height
        self._hover = False

        char_px = 7
        longest = max((len(str(v)) for v in self.values), default=width)
        total_width = max(longest, width) * char_px + 2 * radius + 22

        self.canvas = tk.Canvas(self, width=total_width, height=height,
                                 highlightthickness=0, bd=0, bg=parent_bg,
                                 cursor="hand2")
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self._open)
        self.canvas.bind("<Enter>", self._on_enter)
        self.canvas.bind("<Leave>", self._on_leave)

        self.menu = tk.Menu(
            self, tearoff=0, bg=theme.BG_FIELD, fg=theme.FG,
            activebackground=theme.GREEN, activeforeground=theme.TEXT_ON_ACCENT,
            bd=0, activeborderwidth=0, font=("Segoe UI", 9),
        )
        for value in self.values:
            self.menu.add_command(label=str(value),
                                   command=lambda v=value: self._choose(v))

        # refresh_from_config assigns the variable directly, so redraw on write.
        self._trace = variable.trace_add("write", lambda *_: self._draw())
        self._draw()

    def _on_enter(self, _event):
        self._hover = True
        self._draw()

    def _on_leave(self, _event):
        self._hover = False
        self._draw()

    def _choose(self, value):
        self.variable.set(value)
        self._draw()
        if self.command:
            self.command()

    def _open(self, _event):
        x = self.canvas.winfo_rootx()
        y = self.canvas.winfo_rooty() + self.height
        try:
            self.menu.tk_popup(x, y)
        finally:
            self.menu.grab_release()

    def _draw(self):
        c = self.canvas
        c.delete("all")
        w = max(c.winfo_width(), int(c["width"]))
        h = max(c.winfo_height(), self.height)
        r = min(self.radius, h // 2)

        base = theme.BORDER if self._hover else theme.BG_FIELD
        gradient.rounded(c, 0, 0, w, h, r, base, base, bg=self.parent_bg)
        c.create_text(r + 6, h / 2, text=str(self.variable.get()), anchor="w",
                       fill=theme.FG, font=("Segoe UI", 9))

        # Chevron
        cx, cy, size = w - r - 6, h / 2, 3.5
        c.create_polygon(cx - size, cy - size / 2, cx + size, cy - size / 2, cx, cy + size,
                          fill=theme.FG_MUTED, outline=theme.FG_MUTED)
