import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import theme
from .gui_widgets import HotkeyPicker, PageHeader
from .hotkey_conflicts import find_conflict
from .rounded_button import RoundedButton
from .rounded_entry import RoundedEntry
from .rounded_select import RoundedSelect
from .script import ScriptRunner, ScriptStep, load_script, save_script
from .speed_control import SpeedControl
from .toggle import ToggleSwitch

# Editable parameters per step kind: (key, label, default).
FIELDS = {
    "autoclick": [("cps", "Clicks/sec", 34.0), ("seconds", "For (seconds)", 3.0),
                   ("duty", "Duty cycle %", 50.0), ("randomization", "Random %", 0.0),
                   ("button", "Button", "left")],
    "click": [("count", "Times", 1), ("cps", "Clicks/sec", 10.0),
               ("duty", "Duty cycle %", 50.0), ("randomization", "Random %", 0.0),
               ("button", "Button", "left")],
    "key": [("key", "Key", "3"), ("hold_ms", "Hold (ms)", 0)],
    "wait": [("seconds", "Seconds", 0.3)],
}

ADD_BUTTONS = [("autoclick", "+ Autoclick"), ("key", "+ Key"),
               ("wait", "+ Wait"), ("click", "+ Clicks")]


def default_step(kind):
    return ScriptStep(kind, {key: default for key, _, default in FIELDS[kind]})


class ScriptPage(ttk.Frame):
    """Builds and runs position-independent step sequences."""

    def __init__(self, master, hotkey_manager, cfg, on_config_change, notify=None):
        super().__init__(master, padding=16)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change
        self.notify = notify or (lambda message: None)

        self.steps = []
        self._field_vars = {}
        self.runner = ScriptRunner(on_state_change=self._on_state_change, on_step=self._on_step)

        self._loading = True
        self._build_ui()
        self._loading = False
        self._register_hotkey()

    # ------------------------------------------------------------------ layout

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}
        s = self.cfg["script"]

        PageHeader(self, "Script").grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 8))
        self.columnconfigure(1, weight=1)

        row = 1
        ttk.Label(self, text="Runs top to bottom, no mouse positions involved.",
                   style="Muted.TLabel").grid(row=row, column=0, columnspan=3, sticky="w", padx=8)
        row += 1

        add_frame = ttk.Frame(self)
        add_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        for i, (kind, label) in enumerate(ADD_BUTTONS):
            add_frame.columnconfigure(i, weight=1)
            RoundedButton(
                add_frame, label, command=lambda k=kind: self._add_step(k),
                bg=theme.BG_FIELD, hover_bg=theme.GREEN_HOVER, fg=theme.FG,
                parent_bg=theme.BG_PANEL, height=28, font=("Segoe UI", 9),
            ).grid(row=0, column=i, sticky="ew", padx=2)
        row += 1

        self.tree = ttk.Treeview(self, columns=("step",), show="tree", height=6, selectmode="browse")
        self.tree.column("#0", width=34, stretch=False)
        self.tree.column("step", width=340, anchor="w")
        self.tree.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        self.tree.bind("<<TreeviewSelect>>", lambda ev: self._show_editor())
        row += 1

        order_frame = ttk.Frame(self)
        order_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        for i, (label, command) in enumerate((("Up", lambda: self._move(-1)),
                                               ("Down", lambda: self._move(1)),
                                               ("Duplicate", self._duplicate),
                                               ("Remove", self._remove))):
            order_frame.columnconfigure(i, weight=1)
            RoundedButton(
                order_frame, label, command=command, bg=theme.BG_FIELD,
                hover_bg=theme.ORANGE if label == "Remove" else theme.BORDER,
                fg=theme.FG, parent_bg=theme.BG_PANEL, height=28, font=("Segoe UI", 9),
            ).grid(row=0, column=i, sticky="ew", padx=2)
        row += 1

        self.editor = ttk.Frame(self)
        self.editor.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        row += 1

        ttk.Label(self, text="Run hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.hotkey_picker = HotkeyPicker(self, self.hotkey_manager, s["hotkey"],
                                           self._on_hotkey_change)
        self.hotkey_picker.grid(row=row, column=1, sticky="w", **pad)
        self.mode_var = tk.StringVar(value=s["hotkey_mode"])
        RoundedSelect(self, self.mode_var, ["toggle", "hold"],
                       command=self._on_mode_change).grid(row=row, column=2, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Run speed:").grid(row=row, column=0, sticky="w", **pad)
        self.speed_control = SpeedControl(self, s["speed"], self._on_speed_change)
        self.speed_control.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        self.loop_var = tk.BooleanVar(value=s["loop"])
        self.loop_toggle = ToggleSwitch(self, "Repeat until stopped", self.loop_var,
                                         self._on_loop_change)
        self.loop_toggle.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        self.run_btn = RoundedButton(
            self, "Run", command=self._toggle_run, bg=theme.GREEN, hover_bg=theme.GREEN_HOVER,
            fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.run_btn.grid(row=row, column=0, columnspan=3, sticky="ew", padx=8, pady=(8, 4))
        row += 1

        file_frame = ttk.Frame(self)
        file_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        for i, (label, command) in enumerate((("Save...", self._save), ("Load...", self._load),
                                               ("Clear", self._clear))):
            file_frame.columnconfigure(i, weight=1)
            RoundedButton(
                file_frame, label, command=command, bg=theme.BG_FIELD, hover_bg=theme.BORDER,
                fg=theme.FG, parent_bg=theme.BG_PANEL, height=28, font=("Segoe UI", 9),
            ).grid(row=0, column=i, sticky="ew", padx=2)
        row += 1

        self.status_var = tk.StringVar(value="Idle — 0 steps")
        ttk.Label(self, textvariable=self.status_var, style="Value.TLabel").grid(
            row=row, column=0, columnspan=3, **pad)

    # ------------------------------------------------------------------ step list

    def _selected_index(self):
        selection = self.tree.selection()
        return int(selection[0]) if selection else None

    def _refresh_tree(self, select=None):
        self.tree.delete(*self.tree.get_children())
        for i, step in enumerate(self.steps):
            self.tree.insert("", "end", iid=str(i), text=str(i + 1), values=(step.describe(),))
        if select is not None and 0 <= select < len(self.steps):
            self.tree.selection_set(str(select))
            self.tree.see(str(select))
        self._update_status()

    def _update_status(self):
        if not self.runner.running:
            self.status_var.set(f"Idle — {len(self.steps)} steps")

    def _add_step(self, kind):
        self.steps.append(default_step(kind))
        self._refresh_tree(select=len(self.steps) - 1)

    def _remove(self):
        index = self._selected_index()
        if index is None:
            return
        del self.steps[index]
        self._refresh_tree(select=min(index, len(self.steps) - 1))
        self._show_editor()

    def _duplicate(self):
        index = self._selected_index()
        if index is None:
            return
        original = self.steps[index]
        self.steps.insert(index + 1, ScriptStep(original.kind, dict(original.params)))
        self._refresh_tree(select=index + 1)

    def _move(self, delta):
        index = self._selected_index()
        if index is None:
            return
        target = index + delta
        if not 0 <= target < len(self.steps):
            return
        self.steps[index], self.steps[target] = self.steps[target], self.steps[index]
        self._refresh_tree(select=target)

    # ------------------------------------------------------------------ editor

    def _show_editor(self):
        for child in self.editor.winfo_children():
            child.destroy()
        self._field_vars = {}

        index = self._selected_index()
        if index is None:
            return
        step = self.steps[index]

        ttk.Label(self.editor, text=f"Step {index + 1}: {step.kind}",
                   style="Section.TLabel").grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 4))

        for i, (key, label, default) in enumerate(FIELDS[step.kind]):
            column = (i % 2) * 2
            grid_row = 1 + i // 2
            ttk.Label(self.editor, text=f"{label}:").grid(
                row=grid_row, column=column, sticky="w", padx=(0, 6), pady=2)
            var = tk.StringVar(value=str(step.params.get(key, default)))
            self._field_vars[key] = var
            if key == "button":
                widget = RoundedSelect(self.editor, var, ["left", "right", "middle"],
                                        command=self._commit_editor)
            else:
                widget = RoundedEntry(self.editor, var, width=8)
                widget.bind_commit(self._commit_editor)
            widget.grid(row=grid_row, column=column + 1, sticky="w", padx=(0, 14), pady=2)

    def _commit_editor(self):
        index = self._selected_index()
        if index is None:
            return
        step = self.steps[index]
        for key, _, default in FIELDS[step.kind]:
            raw = self._field_vars[key].get()
            if key in ("key", "button"):
                step.params[key] = raw
                continue
            try:
                value = float(raw)
                if key == "count":
                    value = max(int(value), 1)
                elif key == "duty":
                    value = min(max(value, 1.0), 100.0)
                elif key == "randomization":
                    value = min(max(value, 0.0), 100.0)
                elif value < 0:
                    raise ValueError
            except ValueError:
                value = step.params.get(key, default)
                self._field_vars[key].set(str(value))
            step.params[key] = value
        self._refresh_tree(select=index)

    # ------------------------------------------------------------------ running

    def _toggle_run(self):
        if self.runner.running:
            self.runner.stop()
        else:
            self._start_run()

    def _start_run(self):
        if self.runner.running or not self.steps:
            return
        try:
            self._validate()
        except ValueError as exc:
            messagebox.showerror("Script", str(exc))
            return
        self.runner.start(self.steps, loop=self.loop_var.get())

    def _validate(self):
        from .script import parse_key

        for i, step in enumerate(self.steps, start=1):
            if step.kind == "key":
                try:
                    parse_key(step.params.get("key", ""))
                except ValueError as exc:
                    raise ValueError(f"Step {i}: {exc}") from exc

    def _on_state_change(self, running):
        def update():
            self.run_btn.set_text("Stop" if running else "Run")
            self.run_btn.set_colors(
                theme.ORANGE if running else theme.GREEN,
                theme.ORANGE_HOVER if running else theme.GREEN_HOVER,
            )
            if not running:
                self._update_status()
        self.after(0, update)

    def _on_step(self, index, loop_number):
        self.after(0, lambda: self.status_var.set(
            f"Running step {index + 1}/{len(self.steps)} · pass {loop_number}"))

    # ------------------------------------------------------------------ config

    def _on_hotkey_change(self, combo_string):
        clash = find_conflict(self.cfg, "script", "hotkey", combo_string)
        if clash:
            combo_string = ""
            self.hotkey_picker.set_combo("")
            self.notify(f"Already used by {clash} — pick another key")
        self.cfg["script"]["hotkey"] = combo_string
        self.on_config_change()
        self._register_hotkey()

    def _on_mode_change(self):
        self.cfg["script"]["hotkey_mode"] = self.mode_var.get()
        self.on_config_change()
        self._register_hotkey()

    def _on_speed_change(self, speed):
        self.cfg["script"]["speed"] = speed
        self.runner.speed = speed
        self.on_config_change()

    def _on_loop_change(self):
        self.cfg["script"]["loop"] = self.loop_var.get()
        if not self._loading:
            self.on_config_change()

    def _register_hotkey(self):
        combo = self.cfg["script"]["hotkey"]
        if self.cfg["script"]["hotkey_mode"] == "hold":
            self.hotkey_manager.register(
                "script_run", combo,
                lambda: self.after(0, self._start_run),
                on_release=lambda: self.after(0, self.runner.stop),
            )
        else:
            self.hotkey_manager.register(
                "script_run", combo, lambda: self.after(0, self._toggle_run))

    def refresh_from_config(self):
        s = self.cfg["script"]
        self._loading = True
        try:
            self.hotkey_picker.set_combo(s["hotkey"])
            self.mode_var.set(s["hotkey_mode"])
            self.loop_var.set(s["loop"])
            self.loop_toggle.refresh()
            self.speed_control.set_speed(s["speed"])
            self.runner.speed = float(s["speed"])
        finally:
            self._loading = False
        self._register_hotkey()

    # ------------------------------------------------------------------ files

    def _save(self):
        if not self.steps:
            messagebox.showinfo("Save Script", "No steps to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                             filetypes=[("Script files", "*.json")])
        if path:
            save_script(path, self.steps)

    def _load(self):
        path = filedialog.askopenfilename(filetypes=[("Script files", "*.json")])
        if not path:
            return
        try:
            self.steps = load_script(path)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror("Load Script", f"Failed to load script:\n{exc}")
            return
        self._refresh_tree(select=0 if self.steps else None)
        self._show_editor()

    def load_steps(self, steps):
        """Replace the script wholesale — used when converting a macro."""
        self.steps = list(steps)
        self._refresh_tree(select=0 if self.steps else None)
        self._show_editor()

    def _clear(self):
        self.steps = []
        self._refresh_tree()
        self._show_editor()
