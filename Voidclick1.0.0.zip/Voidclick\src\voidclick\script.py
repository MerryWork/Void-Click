"""Step-based macro scripts.

Recorded macros replay absolute mouse coordinates, which makes them brittle —
move a window and they break. A script is instead an ordered list of logical
steps (autoclick for a while, press a key, wait, ...) with no positions in it at
all, so it can be written and edited by hand and runs wherever the pointer is.
"""

import json
import random
import threading
import time
import traceback
from dataclasses import asdict, dataclass, field

from pynput import keyboard, mouse

from .input_guard import GUARD, KEY, MOUSE
from .safety import safe_call

BUTTONS = {"left": mouse.Button.left, "right": mouse.Button.right, "middle": mouse.Button.middle}

KINDS = ("autoclick", "click", "key", "wait")


def parse_key(text):
    """Accept what a user would actually type: '3', 'a', 'space', 'f5', 'enter'."""
    text = (text or "").strip()
    if not text:
        raise ValueError("no key given")
    if len(text) == 1:
        return keyboard.KeyCode.from_char(text)
    special = getattr(keyboard.Key, text.lower(), None)
    if special is None:
        raise ValueError(f"unknown key: {text}")
    return special


@dataclass
class ScriptStep:
    kind: str
    params: dict = field(default_factory=dict)

    def describe(self):
        p = self.params
        extra = ""
        if self.kind in ("autoclick", "click"):
            if float(p.get("duty", 50)) != 50:
                extra += f", {p['duty']:g}% duty"
            if float(p.get("randomization", 0)) > 0:
                extra += f", ±{p['randomization']:g}%"
        if self.kind == "autoclick":
            return (f"Autoclick {p.get('cps', 10):g} cps for {p.get('seconds', 1):g}s "
                    f"({p.get('button', 'left')}{extra})")
        if self.kind == "click":
            return (f"Click {p.get('count', 1)}x at {p.get('cps', 10):g} cps "
                    f"({p.get('button', 'left')}{extra})")
        if self.kind == "key":
            hold = p.get("hold_ms", 0)
            held = f" held {hold:g}ms" if hold else ""
            return f"Press '{p.get('key', '')}'{held}"
        if self.kind == "wait":
            return f"Wait {p.get('seconds', 1):g}s"
        return self.kind


def save_script(path, steps):
    with open(path, "w") as f:
        json.dump([asdict(s) for s in steps], f, indent=2)


def load_script(path):
    with open(path) as f:
        raw = json.load(f)
    steps = [ScriptStep(**item) for item in raw]
    for step in steps:
        if step.kind not in KINDS:
            raise ValueError(f"unknown step kind: {step.kind}")
    return steps


class ScriptRunner:
    def __init__(self, on_state_change=None, on_step=None):
        self._mouse = mouse.Controller()
        self._keyboard = keyboard.Controller()
        self._running = threading.Event()
        self._thread = None
        self.on_state_change = on_state_change
        self.on_step = on_step   # on_step(index, loop_number)
        self.last_error = None
        self.speed = 1.0         # scales every wait and click interval
        self._generation = 0

    @property
    def running(self):
        return self._running.is_set()

    def start(self, steps, loop=True):
        if not steps:
            return
        self._halt_current()
        self.last_error = None
        self._generation += 1
        generation = self._generation
        self._running.set()
        self._thread = threading.Thread(
            target=self._run, args=(list(steps), loop, generation), daemon=True)
        self._thread.start()
        safe_call(self.on_state_change, True)

    def _current(self, generation):
        """True while this run is both wanted and still the newest one."""
        return self._running.is_set() and generation == self._generation

    def _halt_current(self):
        """End the previous run and wait for its thread, so two never overlap."""
        self._running.clear()
        thread = self._thread
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=1.0)

    def stop(self):
        self._running.clear()

    def toggle(self, steps, loop=True):
        self.stop() if self.running else self.start(steps, loop)

    def _run(self, steps, loop, generation):
        # Cleanup in finally: a bad step (an unparseable key, a controller
        # error) must not leave the runner stuck 'running' forever.
        try:
            self._step_loop(steps, loop, generation)
        except Exception:
            self.last_error = traceback.format_exc()
            traceback.print_exc()
        finally:
            # Only tidy up if a newer run hasn't taken over, or a finishing old
            # thread would switch the new one off.
            if generation == self._generation:
                self._running.clear()
                safe_call(self.on_state_change, False)

    def _step_loop(self, steps, loop, generation):
        loop_number = 0
        while self._current(generation):
            loop_number += 1
            for index, step in enumerate(steps):
                if not self._current(generation):
                    break
                safe_call(self.on_step, index, loop_number)
                self._execute(step)
            if not loop:
                break

    def _sleep(self, seconds):
        """Sleep in slices so stopping stays responsive during long waits.

        Every delay in a script routes through here, so dividing by speed once
        scales waits, click intervals and hold times together.
        """
        end = time.monotonic() + max(seconds, 0.0) / max(self.speed, 0.05)
        while self._running.is_set():
            remaining = end - time.monotonic()
            if remaining <= 0:
                return
            time.sleep(min(remaining, 0.02))

    def _click_cycle(self, button, params):
        """One press/release plus its idle time, honouring duty cycle and jitter.

        Mirrors the Clicker page: duty cycle is the share of each cycle the
        button stays down, randomization scatters the cycle length so the
        rhythm isn't perfectly uniform.
        """
        period = 1.0 / max(float(params.get("cps", 10)), 0.01)
        spread = float(params.get("randomization", 0))
        if spread > 0:
            period = max(period * (1 + random.uniform(-spread, spread) / 100.0), 0.001)

        duty = max(min(float(params.get("duty", 50)), 100.0), 0.0)
        down = period * duty / 100.0

        GUARD.mark(MOUSE)
        self._mouse.press(button)
        try:
            if down > 0:
                self._sleep(down)
        finally:
            # Always release, or bailing mid-hold leaves the button stuck down.
            GUARD.mark(MOUSE)
            self._mouse.release(button)
        self._sleep(max(period - down, 0.0))

    def _execute(self, step):
        params = step.params

        if step.kind == "wait":
            self._sleep(float(params.get("seconds", 0)))

        elif step.kind == "key":
            key = parse_key(params.get("key", ""))
            GUARD.mark(KEY)
            self._keyboard.press(key)
            hold = float(params.get("hold_ms", 0)) / 1000.0
            if hold > 0:
                self._sleep(hold)
            GUARD.mark(KEY)
            self._keyboard.release(key)

        elif step.kind == "click":
            button = BUTTONS.get(params.get("button", "left"), mouse.Button.left)
            for _ in range(int(params.get("count", 1))):
                if not self._running.is_set():
                    return
                self._click_cycle(button, params)

        elif step.kind == "autoclick":
            button = BUTTONS.get(params.get("button", "left"), mouse.Button.left)
            # The run duration speeds up too, so the whole script scales.
            end = time.monotonic() + float(params.get("seconds", 0)) / max(self.speed, 0.05)
            while self._running.is_set() and time.monotonic() < end:
                self._click_cycle(button, params)
