"""Keeping worker threads alive when something unexpected goes wrong."""

import traceback


def safe_call(callback, *args):
    """Invoke a GUI callback from a worker thread without letting it kill it.

    These callbacks hop onto the Tk main thread, and Tk is not thread-safe: a
    destroyed widget or a threading hiccup raises. `on_count` fires on every
    single click, so an escaping exception would abort the click loop and — as
    the cleanup used to sit after the loop rather than in a finally — leave the
    engine permanently stuck 'running' and unable to restart.
    """
    if callback is None:
        return
    try:
        callback(*args)
    except Exception:
        traceback.print_exc()
