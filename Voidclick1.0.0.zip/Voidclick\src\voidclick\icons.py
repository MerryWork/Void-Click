"""Vector icons drawn straight onto a Canvas.

Emoji glyphs render inconsistently across Tk builds (often as boxes or flat
monochrome), so the tab icons are drawn as shapes instead — crisp at any size
and tintable with the theme colors.
"""

import math


def _round_rect_points(x1, y1, x2, y2, r):
    return [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
        x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]


def mouse(canvas, cx, cy, size, color, bg=None):
    """Mouse silhouette — the Clicker tab."""
    w, h = size * 0.60, size
    canvas.create_polygon(
        _round_rect_points(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, w / 2),
        smooth=True, fill="", outline=color, width=2,
    )
    canvas.create_line(cx, cy - h * 0.30, cx, cy - h * 0.08, fill=color, width=2)


def record(canvas, cx, cy, size, color, bg=None):
    """Record button — the Macro tab."""
    r = size * 0.46
    canvas.create_oval(cx - r, cy - r, cx + r, cy + r, outline=color, width=2)
    dot = size * 0.19
    canvas.create_oval(cx - dot, cy - dot, cx + dot, cy + dot, fill=color, outline=color)


def gear(canvas, cx, cy, size, color, bg="#0c0e13"):
    """Cogwheel — the Settings tab. `bg` fills the center hole."""
    r_out, r_in = size * 0.52, size * 0.37
    points = []
    steps = 32  # 8 teeth x 4 points
    for i in range(steps):
        angle = 2 * math.pi * i / steps
        r = r_out if (i % 4) in (1, 2) else r_in
        points.extend([cx + r * math.cos(angle), cy + r * math.sin(angle)])
    canvas.create_polygon(points, fill=color, outline=color)
    hole = size * 0.16
    canvas.create_oval(cx - hole, cy - hole, cx + hole, cy + hole, fill=bg, outline=bg)


def steps(canvas, cx, cy, size, color, bg=None):
    """Stacked rows with leading dots — the Script tab."""
    rows = 3
    gap = size * 0.34
    dot = size * 0.07
    top = cy - gap
    for i in range(rows):
        y = top + i * gap
        x0 = cx - size * 0.46
        canvas.create_oval(x0 - dot, y - dot, x0 + dot, y + dot, fill=color, outline=color)
        length = size * (0.76 if i != 1 else 0.52)
        canvas.create_line(x0 + size * 0.18, y, x0 + length, y, fill=color, width=2)


_BOLT = [(0.60, 0.00), (0.25, 0.52), (0.47, 0.52), (0.38, 1.00), (0.75, 0.44), (0.52, 0.44)]


def bolt(canvas, cx, cy, size, color):
    points = []
    for fx, fy in _BOLT:
        points.extend([cx + (fx - 0.5) * size, cy + (fy - 0.5) * size])
    canvas.create_polygon(points, fill=color, outline=color)


def logo(canvas, cx, cy, size, badge_color, bolt_color, badge_color_end=None):
    """App mark: a rounded gradient badge with a lightning bolt."""
    from . import gradient

    half = size / 2
    backdrop = canvas.cget("bg")
    if badge_color_end:
        gradient.rounded(canvas, cx - half, cy - half, cx + half, cy + half,
                          size * 0.28, gradient.lighten(badge_color, 0.18), badge_color_end,
                          bg=backdrop)
    else:
        gradient.glass(canvas, cx - half, cy - half, cx + half, cy + half,
                        size * 0.28, badge_color, bg=backdrop)
    bolt(canvas, cx, cy, size * 0.66, bolt_color)


def _in_rounded_square(px, py, size, r):
    x = min(max(px, r), size - r)
    y = min(max(py, r), size - r)
    dx, dy = px - x, py - y
    return dx * dx + dy * dy <= r * r


def _in_polygon(x, y, points):
    inside = False
    j = len(points) - 1
    for i, (xi, yi) in enumerate(points):
        xj, yj = points[j]
        if (yi > y) != (yj > y) and x < (xj - xi) * (y - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


def make_window_icon(tk_module, size=40, badge_color="#3ddc84", bolt_color="#0d0f14"):
    """Build the taskbar/title-bar icon pixel by pixel.

    Tk can only load images from files or base64 data, and there's no Pillow
    dependency here, so the logo is rasterised by hand instead of shipping a
    binary .ico alongside the source.
    """
    image = tk_module.PhotoImage(width=size, height=size)
    radius = size * 0.28
    scaled_bolt = [((fx - 0.5) * 0.66 + 0.5, (fy - 0.5) * 0.66 + 0.5) for fx, fy in _BOLT]

    rows, clear = [], []
    for y in range(size):
        row = []
        for x in range(size):
            if not _in_rounded_square(x + 0.5, y + 0.5, size, radius):
                clear.append((x, y))
                row.append(badge_color)
            elif _in_polygon((x + 0.5) / size, (y + 0.5) / size, scaled_bolt):
                row.append(bolt_color)
            else:
                row.append(badge_color)
        rows.append("{" + " ".join(row) + "}")

    image.put(" ".join(rows))
    for x, y in clear:
        image.transparency_set(x, y, True)
    return image
