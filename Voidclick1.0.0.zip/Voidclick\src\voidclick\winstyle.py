"""Best-effort native-chrome theming so the OS title bar matches the app's dark body."""

import sys


def apply_dark_titlebar(root):
    """On Windows 10 2004+/11, ask DWM to draw a dark title bar. No-op elsewhere."""
    if sys.platform != "win32":
        return
    try:
        import ctypes

        root.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        value = ctypes.c_int(1)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (current, then pre-20H1 fallback)
            result = ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(value), ctypes.sizeof(value)
            )
            if result == 0:
                break
    except Exception:
        pass  # cosmetic only — never block startup over this
