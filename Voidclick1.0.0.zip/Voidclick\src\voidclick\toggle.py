"""A pill toggle switch drawn on a Canvas.

ttk's checkbutton indicator renders as a dated boxed X under the clam theme and
ignores most color styling, so the on/off controls are drawn by hand instead.
"""

import tkinter as tk

from . import gradient, theme


class ToggleSwitch(tk.Frame):
    def __init__(self, master, text, variable, command=None, parent_bg=theme.BG_PANEL,
                 track_w=40, track_h=20):
        super().__init__(master, bg=parent_bg)
        self.var = variable
        self.command = command
        self.parent_bg = parent_bg
        self.track_w = track_w
        self.track_h = track_h

        self.canvas = tk.Canvas(self, width=track_w, height=track_h, bg=parent_bg,
                                 highlightthickness=0, bd=0, cursor="hand2")
        self.canvas.pack(side="left")
        self.label = tk.Label(self, text=text, bg=parent_bg, fg=theme.FG,
                               font=("Segoe UI", 9), cursor="hand2")
        self.label.pack(side="left", padx=(8, 0))

        for widget in (self.canvas, self.label):
            widget.bind("<Button-1>", self._on_click)

        self._draw()

    def _on_click(self, _event=None):
        self.var.set(not self.var.get())
        self._draw()
        if self.command:
            self.command()

    def refresh(self):
        self._draw()

    def _draw(self):
        c = self.canvas
        c.delete("all")
        on = bool(self.var.get())
        w, h = self.track_w, self.track_h
        r = h / 2

        track = theme.GREEN if on else theme.BG_FIELD
        gradient.glass(c, 0, 0, w, h, r, track, bg=self.parent_bg)

        knob_r = r - 3
        cx = (w - r) if on else r
        knob = theme.TEXT_ON_ACCENT if on else theme.FG_MUTED
        c.create_oval(cx - knob_r, r - knob_r, cx + knob_r, r + knob_r, fill=knob, outline=knob)
