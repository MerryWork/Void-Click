"""Turn a recorded macro into an editable script.

A macro is a timestamped event stream with absolute coordinates; a script is a
list of logical steps with no positions at all. The conversion is therefore
lossy, and only faithful when every click lands in roughly the same place. What
can't survive is reported rather than hidden.
"""

import math
import statistics
from dataclasses import dataclass, field

from .script import ScriptStep

# Clicks within this many pixels count as "the same spot".
POSITION_TOLERANCE = 8
# A gap this long always breaks a run, however slow the surrounding rhythm.
MIN_GAP_SECONDS = 0.25
# Gaps shorter than this aren't worth a wait step of their own.
MIN_WAIT_SECONDS = 0.05
# At or above this many clicks, a run is better described by duration than count.
AUTOCLICK_THRESHOLD = 8
# stdev/mean of a uniform +/-r% spread is r/(100*sqrt(3)); invert to recover r.
UNIFORM_SPREAD_FACTOR = 100.0 * math.sqrt(3)


@dataclass
class Report:
    warnings: list = field(default_factory=list)
    source_events: int = 0
    source_seconds: float = 0.0
    script_seconds: float = 0.0
    click_clusters: int = 0

    @property
    def faithful(self):
        """Whether replaying the script should land close to the recording."""
        return not self.warnings

    def summary(self):
        drift = self.script_seconds - self.source_seconds
        return (f"{self.source_events} events -> script of {self.script_seconds:.1f}s "
                f"(recording was {self.source_seconds:.1f}s, {drift:+.1f}s)")


def macro_key_to_script_key(stored):
    """Macros store repr(key) — "'a'" or "Key.space"; scripts want 'a'/'space'."""
    stored = (stored or "").strip()
    if stored.startswith("Key."):
        return stored[4:]
    return stored.strip("'")


def _pair_events(events):
    """Collapse press/release pairs into atoms carrying a hold duration."""
    atoms, warnings = [], []
    open_clicks, open_keys = {}, {}
    scrolls = 0
    moves = 0

    for event in events:
        if event.type == "move":
            moves += 1
        elif event.type == "scroll":
            scrolls += 1
        elif event.type == "click":
            button = event.data.get("button", "left")
            if event.data.get("pressed"):
                open_clicks[button] = event
            else:
                press = open_clicks.pop(button, None)
                if press is not None:
                    atoms.append({
                        "kind": "click", "t": press.t, "hold": max(event.t - press.t, 0.0),
                        "button": button,
                        "x": press.data.get("x", 0), "y": press.data.get("y", 0),
                    })
        elif event.type == "key_press":
            open_keys[event.data.get("key")] = event
        elif event.type == "key_release":
            stored = event.data.get("key")
            press = open_keys.pop(stored, None)
            if press is not None:
                atoms.append({
                    "kind": "key", "t": press.t, "hold": max(event.t - press.t, 0.0),
                    "key": macro_key_to_script_key(stored),
                })

    if open_clicks or open_keys:
        warnings.append(
            f"{len(open_clicks) + len(open_keys)} press(es) never released — dropped")
    if scrolls:
        warnings.append(f"{scrolls} scroll event(s) dropped: scripts have no scroll step")
    if moves:
        warnings.append(
            f"{moves} mouse movement(s) dropped: scripts run wherever the pointer is")

    atoms.sort(key=lambda atom: atom["t"])
    return atoms, warnings


def _cluster_positions(click_atoms):
    """Greedy grouping of click coordinates, so we can tell if position matters."""
    clusters = []
    for atom in click_atoms:
        for centre in clusters:
            if (abs(centre[0] - atom["x"]) <= POSITION_TOLERANCE
                    and abs(centre[1] - atom["y"]) <= POSITION_TOLERANCE):
                break
        else:
            clusters.append((atom["x"], atom["y"]))
    return clusters


def _overlapping_holds(atoms):
    """Keys held across other input can't be expressed as sequential steps."""
    key_atoms = [a for a in atoms if a["kind"] == "key"]
    for atom in key_atoms:
        end = atom["t"] + atom["hold"]
        for other in atoms:
            if other is atom:
                continue
            if atom["t"] < other["t"] < end:
                return True
    return False


def _gap_threshold(click_atoms):
    """How long a pause has to be before it splits one burst into two."""
    starts = [atom["t"] for atom in click_atoms]
    intervals = [b - a for a, b in zip(starts, starts[1:])]
    if not intervals:
        return MIN_GAP_SECONDS
    return max(3 * statistics.median(intervals), MIN_GAP_SECONDS)


def _run_to_step(run):
    """Describe one burst of same-button clicks as a single step."""
    button = run[0]["button"]
    holds = [atom["hold"] for atom in run]
    starts = [atom["t"] for atom in run]
    intervals = [b - a for a, b in zip(starts, starts[1:])]

    if intervals:
        period = statistics.median(intervals)
        mean = statistics.fmean(intervals)
        spread = statistics.pstdev(intervals) if len(intervals) > 1 else 0.0
        randomization = 0.0
        if mean > 0 and spread > 0:
            randomization = min(UNIFORM_SPREAD_FACTOR * spread / mean, 100.0)
    else:
        period = max(statistics.fmean(holds) * 2, 0.02)
        randomization = 0.0

    period = max(period, 0.001)
    cps = round(1.0 / period, 2)
    duty = min(max(statistics.median(holds) / period * 100.0, 1.0), 100.0)

    params = {
        "cps": cps,
        "duty": round(duty, 1),
        "randomization": round(randomization, 1),
        "button": button,
    }

    if len(run) >= AUTOCLICK_THRESHOLD:
        params["seconds"] = round(starts[-1] - starts[0] + period, 2)
        return ScriptStep("autoclick", params)

    params["count"] = len(run)
    return ScriptStep("click", params)


def _step_seconds(step):
    p = step.params
    if step.kind == "autoclick":
        return float(p.get("seconds", 0))
    if step.kind == "click":
        return float(p.get("count", 1)) / max(float(p.get("cps", 10)), 0.01)
    if step.kind == "key":
        return float(p.get("hold_ms", 0)) / 1000.0
    return float(p.get("seconds", 0))


def transcribe(events):
    """Convert recorded macro events into script steps.

    Returns (steps, report). The report lists everything that couldn't be
    carried across, so the caller can warn before replacing anything.
    """
    report = Report(source_events=len(events))
    if not events:
        report.warnings.append("the recording is empty")
        return [], report

    report.source_seconds = max(event.t for event in events)
    atoms, warnings = _pair_events(events)
    report.warnings.extend(warnings)

    if not atoms:
        report.warnings.append("nothing convertible found — only movement or scrolling")
        return [], report

    click_atoms = [atom for atom in atoms if atom["kind"] == "click"]
    clusters = _cluster_positions(click_atoms)
    report.click_clusters = len(clusters)
    if len(clusters) > 1:
        report.warnings.append(
            f"clicks land in {len(clusters)} different places — a script has no "
            f"positions, so every click will happen wherever the pointer is")

    if _overlapping_holds(atoms):
        report.warnings.append(
            "a key was held across other input — script key steps are sequential, "
            "so held modifiers (Ctrl+C and the like) can't be reproduced")

    threshold = _gap_threshold(click_atoms)
    steps = []
    run = []
    previous_end = atoms[0]["t"]   # no leading wait; the script starts immediately

    def flush():
        nonlocal run
        if run:
            steps.append(_run_to_step(run))
            run = []

    for atom in atoms:
        gap = atom["t"] - previous_end
        breaks_run = bool(run) and (
            atom["kind"] != "click"
            or atom["button"] != run[0]["button"]
            or atom["t"] - run[-1]["t"] > threshold
        )
        if breaks_run:
            flush()
        if not run and gap > MIN_WAIT_SECONDS:
            steps.append(ScriptStep("wait", {"seconds": round(gap, 2)}))

        if atom["kind"] == "click":
            run.append(atom)
        else:
            steps.append(ScriptStep("key", {
                "key": atom["key"],
                "hold_ms": round(atom["hold"] * 1000),
            }))
        previous_end = atom["t"] + atom["hold"]

    flush()

    report.script_seconds = sum(_step_seconds(step) for step in steps)
    return steps, report
