"""Named slots: several scripts and several macros, each on its own hotkey.

One script and one macro was the original shape, and every hotkey lived at a
fixed place in the config -- cfg["script"]["hotkey"] and so on. Slots turn both
of those into lists, so a binding is now addressed by position as well as name.

Everything that needs to know about hotkeys goes through `bindings()`, which
flattens the fixed ones and the per-slot ones into a single list. Conflict
checking, the settings page and the swap action all read from it, so adding a
slot can't quietly leave one of them behind.

Slots carry their own content. A script keeps its steps here; a macro's events
are kept in their own file (see `macro_store`) because a minute of recorded
mouse movement is thousands of entries and config.json is meant to stay
readable.
"""

import uuid

from .hotkeys import combo_to_label

# Enough for a row of hotkeys without the list becoming unmanageable.
MAX_SLOTS = 8

SCRIPT_SLOT = {
    "id": "",
    "name": "Script 1",
    "hotkey": "",
    "hotkey_mode": "toggle",   # toggle | hold
    "loop": True,
    "speed": 1.0,
    "steps": [],
}

MACRO_SLOT = {
    "id": "",
    "name": "Macro 1",
    "play_hotkey": "",
    "play_hotkey_mode": "toggle",
    "loop_count": 1,
    "continuous_loop": False,
    "playback_speed": 1.0,
}

# The hotkeys that don't belong to a slot. (section, key, label).
FIXED_BINDINGS = [
    ("autoclicker", "hotkey", "the autoclicker"),
    ("general", "record_hotkey", "macro record"),
    ("general", "panic_hotkey", "the panic stop"),
    ("general", "swap_hotkey", "the hotkey swap"),
]


def _fresh(template, index, **overrides):
    slot = dict(template)
    slot["id"] = uuid.uuid4().hex[:12]
    slot["name"] = f"{template['name'].rsplit(' ', 1)[0]} {index + 1}"
    slot.update(overrides)
    # Mutable defaults must not be shared between slots.
    if "steps" in slot:
        slot["steps"] = list(slot["steps"])
    return slot


def new_script_slot(index, **overrides):
    return _fresh(SCRIPT_SLOT, index, **overrides)


def new_macro_slot(index, **overrides):
    return _fresh(MACRO_SLOT, index, **overrides)


def _clean(slot, template, index):
    """Force one slot to the template's shape, keeping any values it does have."""
    fixed = _fresh(template, index)
    if not isinstance(slot, dict):
        return fixed
    for key, value in slot.items():
        if key in fixed:
            fixed[key] = value
    if not str(fixed.get("id") or "").strip():
        fixed["id"] = uuid.uuid4().hex[:12]
    if not str(fixed.get("name") or "").strip():
        fixed["name"] = f"{template['name'].rsplit(' ', 1)[0]} {index + 1}"
    return fixed


def normalize(cfg):
    """Make the slot lists sane: present, non-empty, well-shaped, unique ids.

    Called after loading and after importing, so a hand-edited or older config
    can't leave the pages indexing into something that isn't there.
    """
    for key, template, factory in (("scripts", SCRIPT_SLOT, new_script_slot),
                                    ("macros", MACRO_SLOT, new_macro_slot)):
        raw = cfg.get(key)
        if not isinstance(raw, list) or not raw:
            cfg[key] = [factory(0)]
            continue

        cleaned, seen = [], set()
        for index, slot in enumerate(raw[:MAX_SLOTS]):
            fixed = _clean(slot, template, index)
            while fixed["id"] in seen:
                fixed["id"] = uuid.uuid4().hex[:12]
            seen.add(fixed["id"])
            cleaned.append(fixed)
        cfg[key] = cleaned
    return cfg


# ------------------------------------------------------------------ addressing

def script_address(index):
    return f"scripts/{index}/hotkey"


def macro_address(index):
    return f"macros/{index}/play_hotkey"


def fixed_address(section, key):
    return f"{section}/{key}"


def bindings(cfg):
    """Every managed hotkey as (address, combo, label), fixed ones first."""
    found = []
    for section, key, label in FIXED_BINDINGS:
        found.append((fixed_address(section, key), cfg.get(section, {}).get(key, ""), label))
    for index, slot in enumerate(cfg.get("scripts", [])):
        found.append((script_address(index), slot.get("hotkey", ""),
                      f"script “{slot.get('name', '')}”"))
    for index, slot in enumerate(cfg.get("macros", [])):
        found.append((macro_address(index), slot.get("play_hotkey", ""),
                      f"macro “{slot.get('name', '')}”"))
    return found


def slot_label(name, combo):
    """What the collapsed dropdown shows: the name plus the key that runs it."""
    key = combo_to_label(combo) if combo else "unbound"
    return f"{name}  ·  {key}"


def unique_name(existing, wanted, ignore_index=None):
    """Keep slot names distinct, since the dropdown is how they're told apart."""
    wanted = (wanted or "").strip() or "Untitled"
    taken = {slot.get("name", "") for i, slot in enumerate(existing)
             if i != ignore_index}
    if wanted not in taken:
        return wanted
    n = 2
    while f"{wanted} {n}" in taken:
        n += 1
    return f"{wanted} {n}"
