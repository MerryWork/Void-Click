"""Turn a recorded macro into an editable script.

A macro is a timestamped event stream with absolute coordinates; a script is a
list of logical steps with no positions at all, so the conversion loses
something no matter how it's done. The job is to lose as little as possible and
be honest about the rest.

The events are read through `ahk`, which names each one the way AutoHotkey would.
That is what settles the argument about where the line falls. AHK writes a chord
as Send "^c" and a wheel tick as Send "{WheelDown}" -- neither mentions a mouse
position, so both convert cleanly and used to be thrown away for no reason. It
writes a click as Click "532 410 Left", which does mention one, and that is the
part a script genuinely cannot hold. When that comes up the report says so and
points at the .ahk export, which keeps everything.
"""

import statistics
from dataclasses import dataclass, field

from . import ahk
from .ahk import macro_key_to_script_key   # re-exported: callers import it here
from .script import ScriptStep

# Clicks within this many pixels count as "the same spot".
POSITION_TOLERANCE = 8
# A gap this long always breaks a run, however slow the surrounding rhythm.
MIN_GAP_SECONDS = 0.25
# Gaps shorter than this aren't worth a wait step of their own.
MIN_WAIT_SECONDS = 0.05
# At or above this many clicks, a run is better described by duration than count.
AUTOCLICK_THRESHOLD = 8
# A pause this many times the surrounding rhythm ends the run.
RUN_GAP_FACTOR = 3
# Fewer intervals than this and a spread figure is measurement noise, not a
# setting anyone chose, so it gets reported as zero rather than invented.
MIN_SAMPLES_FOR_SPREAD = 6
# stdev/mean of a uniform +/-r% spread is r/(100*sqrt(3)); invert to recover r.
UNIFORM_SPREAD_FACTOR = 100.0 * 3 ** 0.5
# Above this, the run wasn't a steady rhythm at all and the number means nothing.
SPREAD_SATURATION = 95.0


@dataclass
class Report:
    warnings: list = field(default_factory=list)
    source_events: int = 0
    source_seconds: float = 0.0
    script_seconds: float = 0.0
    click_clusters: int = 0
    statements: int = 0
    # Set when something was dropped that an .ahk export would have kept.
    needs_ahk: bool = False

    @property
    def faithful(self):
        """Whether replaying the script should land close to the recording."""
        return not self.warnings

    def summary(self):
        drift = self.script_seconds - self.source_seconds
        return (f"{self.source_events} events -> script of {self.script_seconds:.1f}s "
                f"(recording was {self.source_seconds:.1f}s, {drift:+.1f}s)")


# ---------------------------------------------------------------------- atoms

def _pair(statements):
    """Collapse down/up statement pairs into atoms that carry a duration.

    Atoms keep an explicit `end` rather than deriving it from t + hold, because a
    chord ends when its modifier comes back up, which is later than the key it
    was qualifying.
    """
    atoms, warnings = [], []
    open_clicks, open_keys = {}, {}

    for statement in statements:
        args = statement.args
        if statement.op == "click":
            button = args["button"]
            if args["state"] == "down":
                open_clicks[button] = statement
            else:
                press = open_clicks.pop(button, None)
                if press is not None:
                    atoms.append({
                        "kind": "click", "t": press.t, "end": statement.t,
                        "hold": max(statement.t - press.t, 0.0), "button": button,
                        "x": press.args["x"], "y": press.args["y"],
                    })
        elif statement.op == "key":
            name = args["name"]
            if args["state"] == "down":
                open_keys[name] = statement
            else:
                press = open_keys.pop(name, None)
                if press is not None:
                    atoms.append({
                        "kind": "key", "t": press.t, "end": statement.t,
                        "hold": max(statement.t - press.t, 0.0), "key": name,
                    })
        elif statement.op == "scroll":
            atoms.append({
                "kind": "scroll", "t": statement.t, "end": statement.t, "hold": 0.0,
                "direction": args["direction"], "count": args["count"],
            })

    if open_clicks or open_keys:
        warnings.append(
            f"{len(open_clicks) + len(open_keys)} press(es) never released — dropped")

    atoms.sort(key=lambda atom: atom["t"])
    return atoms, warnings


def _merge_scrolls(atoms):
    """One flick of a wheel arrives as several events; make it one step."""
    merged = []
    for atom in atoms:
        previous = merged[-1] if merged else None
        if (atom["kind"] == "scroll" and previous is not None
                and previous["kind"] == "scroll"
                and previous["direction"] == atom["direction"]
                and atom["t"] - previous["end"] <= MIN_WAIT_SECONDS):
            previous["count"] += atom["count"]
            previous["end"] = atom["t"]
            continue
        merged.append(atom)
    return merged


def _fold_chords(atoms):
    """Rewrite 'modifier held around a key' as a single combo atom.

    This is the fix AutoHotkey's notation points at: Ctrl+C is one instruction,
    not a held key that the old sequential conversion had to give up on.
    """
    warnings = []
    modifiers = [a for a in atoms if a["kind"] == "key" and ahk.is_modifier(a["key"])]
    consumed, folded = set(), []

    for atom in atoms:
        if atom["kind"] != "key" or ahk.is_modifier(atom["key"]):
            continue
        wrapping = [m for m in modifiers if m["t"] <= atom["t"] < m["end"]]
        if not wrapping:
            continue
        atom["kind"] = "combo"
        atom["mods"] = sorted({ahk.canon_modifier(m["key"]) for m in wrapping},
                              key=ahk.MOD_ORDER.index)
        atom["t"] = min([atom["t"]] + [m["t"] for m in wrapping])
        atom["end"] = max([atom["end"]] + [m["end"] for m in wrapping])
        consumed.update(id(m) for m in wrapping)

    # A modifier that wrapped nothing is just a key the user pressed.
    for atom in atoms:
        if id(atom) not in consumed:
            folded.append(atom)

    # What's left that overlaps is a plain key held across other input, which a
    # sequential step list still can't express.
    for atom in folded:
        if atom["kind"] != "key":
            continue
        if any(other is not atom and atom["t"] < other["t"] < atom["end"]
               for other in folded):
            warnings.append(
                f"'{atom['key']}' was held down across other input — script steps "
                f"run one after another, so it becomes a plain press")
            break

    for atom in folded:
        if atom["kind"] != "combo":
            continue
        if any(other["kind"] == "click" and atom["t"] < other["t"] < atom["end"]
               for other in folded):
            warnings.append(
                "a modifier was held across a click (shift-click and the like) — "
                "click steps carry no modifiers")
            break

    return folded, warnings


# ------------------------------------------------------------------- clusters

def _cluster_positions(click_atoms):
    """Greedy grouping of click coordinates, so we can tell if position matters."""
    clusters = []
    for atom in click_atoms:
        for centre in clusters:
            if (abs(centre[0] - atom["x"]) <= POSITION_TOLERANCE
                    and abs(centre[1] - atom["y"]) <= POSITION_TOLERANCE):
                break
        else:
            clusters.append((atom["x"], atom["y"]))
    return clusters


# ----------------------------------------------------------------------- runs

def _seed_threshold(click_atoms):
    """A starting guess at how long a pause has to be to split one burst in two."""
    starts = [atom["t"] for atom in click_atoms]
    intervals = [b - a for a, b in zip(starts, starts[1:])]
    if not intervals:
        return MIN_GAP_SECONDS
    return max(RUN_GAP_FACTOR * statistics.median(intervals), MIN_GAP_SECONDS)


def _run_threshold(run, seed):
    """Refine the split point against the run in hand.

    One threshold for the whole recording was the old behaviour, and it judged a
    deliberate double-click and a thirty-second burst by the same number. Once a
    run has a few intervals of its own it knows its own rhythm better than the
    recording average does.
    """
    if len(run) < 3:
        return seed
    starts = [atom["t"] for atom in run]
    intervals = [b - a for a, b in zip(starts, starts[1:])]
    return max(RUN_GAP_FACTOR * statistics.median(intervals), MIN_GAP_SECONDS)


def _recover_spread(intervals):
    """Recover a randomization percentage, or 0 when there's nothing to recover.

    Only the app's own autoclicker produces the uniform scatter this inverts. A
    handful of hand-made clicks would yield a large number that describes the
    unsteadiness of a human hand, not a setting, so it takes a real sample first.
    """
    if len(intervals) < MIN_SAMPLES_FOR_SPREAD:
        return 0.0, False
    mean = statistics.fmean(intervals)
    spread = statistics.pstdev(intervals)
    if mean <= 0 or spread <= 0:
        return 0.0, False
    value = UNIFORM_SPREAD_FACTOR * spread / mean
    if value >= SPREAD_SATURATION:
        return 100.0, True
    return round(value, 1), False


def _run_to_step(run):
    """Describe one burst of same-button clicks as a single step."""
    button = run[0]["button"]
    holds = [atom["hold"] for atom in run]
    starts = [atom["t"] for atom in run]
    intervals = [b - a for a, b in zip(starts, starts[1:])]

    saturated = False
    if intervals:
        period = statistics.median(intervals)
        randomization, saturated = _recover_spread(intervals)
    else:
        period = max(statistics.fmean(holds) * 2, 0.02)
        randomization = 0.0

    period = max(period, 0.001)
    cps = round(1.0 / period, 2)
    duty = min(max(statistics.median(holds) / period * 100.0, 1.0), 100.0)

    params = {
        "cps": cps,
        "duty": round(duty, 1),
        "randomization": randomization,
        "button": button,
    }

    if len(run) >= AUTOCLICK_THRESHOLD:
        params["seconds"] = round(starts[-1] - starts[0] + period, 2)
        step = ScriptStep("autoclick", params)
    else:
        params["count"] = len(run)
        step = ScriptStep("click", params)
    return step, saturated


# ---------------------------------------------------------------------- steps

def _step_seconds(step):
    p = step.params
    if step.kind == "autoclick":
        return float(p.get("seconds", 0))
    if step.kind == "click":
        return float(p.get("count", 1)) / max(float(p.get("cps", 10)), 0.01)
    if step.kind in ("key", "combo"):
        return float(p.get("hold_ms", 0)) / 1000.0
    if step.kind == "scroll":
        return float(p.get("count", 1)) * 0.01
    return float(p.get("seconds", 0))


def _atom_to_step(atom):
    if atom["kind"] == "key":
        return ScriptStep("key", {
            "key": atom["key"], "hold_ms": round(atom["hold"] * 1000)})
    if atom["kind"] == "combo":
        return ScriptStep("combo", {
            "key": atom["key"], "mods": "+".join(atom["mods"]),
            "hold_ms": round(atom["hold"] * 1000)})
    return ScriptStep("scroll", {
        "direction": atom["direction"], "count": atom["count"]})


def transcribe(events):
    """Convert recorded macro events into script steps.

    Returns (steps, report). The report lists everything that couldn't be carried
    across, so the caller can warn before replacing anything, and sets
    `needs_ahk` when the .ahk export would have kept what a script can't.
    """
    report = Report(source_events=len(events))
    if not events:
        report.warnings.append("the recording is empty")
        return [], report

    report.source_seconds = max(event.t for event in events)

    statements = ahk.build(events, include_moves=True)
    report.statements = len(statements)
    moves = sum(1 for s in statements if s.op == "move")
    if moves:
        report.needs_ahk = True
        report.warnings.append(
            f"{moves} mouse movement(s) dropped: scripts run wherever the pointer is")

    atoms, warnings = _pair(statements)
    report.warnings.extend(warnings)
    if not atoms:
        report.warnings.append("nothing convertible found — only movement")
        return [], report

    atoms = _merge_scrolls(atoms)
    atoms, chord_warnings = _fold_chords(atoms)
    report.warnings.extend(chord_warnings)

    click_atoms = [atom for atom in atoms if atom["kind"] == "click"]
    clusters = _cluster_positions(click_atoms)
    report.click_clusters = len(clusters)
    if len(clusters) > 1:
        report.needs_ahk = True
        report.warnings.append(
            f"clicks land in {len(clusters)} different places — a script has no "
            f"positions, so every click will happen wherever the pointer is")

    seed = _seed_threshold(click_atoms)
    steps = []
    run = []
    irregular = False
    previous_end = atoms[0]["t"]   # no leading wait; the script starts immediately

    def flush():
        nonlocal run, irregular
        if run:
            step, saturated = _run_to_step(run)
            steps.append(step)
            irregular = irregular or saturated
            run = []

    for atom in atoms:
        gap = atom["t"] - previous_end
        breaks_run = bool(run) and (
            atom["kind"] != "click"
            or atom["button"] != run[0]["button"]
            or atom["t"] - run[-1]["t"] > _run_threshold(run, seed)
        )
        if breaks_run:
            flush()
        if not run and gap > MIN_WAIT_SECONDS:
            steps.append(ScriptStep("wait", {"seconds": round(gap, 2)}))

        if atom["kind"] == "click":
            run.append(atom)
        else:
            steps.append(_atom_to_step(atom))
        previous_end = atom["end"]

    flush()

    if irregular:
        report.warnings.append(
            "a burst was too irregular to describe as one rate — its timing is "
            "approximate")

    report.script_seconds = sum(_step_seconds(step) for step in steps)
    return steps, report
