"""Where each macro slot's recording is kept.

Recordings don't go in config.json. A minute of mouse movement is a few thousand
events, and several slots of that would turn a file someone might want to read
or hand-edit into a wall of coordinates. Each slot gets its own file instead,
named by the slot's id.
"""

import json
import os

from . import config
from .macro import MacroEvent


def path_for(slot_id):
    return os.path.join(config.MACRO_DIR, f"{slot_id}.json")


def load(slot_id):
    """The slot's events, or an empty list if it has never been recorded into."""
    try:
        with open(path_for(slot_id), "r") as f:
            raw = json.load(f)
        return [MacroEvent(**item) for item in raw]
    except (OSError, json.JSONDecodeError, TypeError, ValueError):
        return []


def save(slot_id, events):
    """Write a slot's events. An empty recording removes the file instead."""
    if not events:
        delete(slot_id)
        return
    try:
        os.makedirs(config.MACRO_DIR, exist_ok=True)
        with open(path_for(slot_id), "w") as f:
            json.dump([{"type": e.type, "t": e.t, "data": e.data} for e in events], f)
    except OSError:
        pass


def delete(slot_id):
    try:
        os.remove(path_for(slot_id))
    except OSError:
        pass


def prune(keep_ids):
    """Drop recordings whose slot is gone, so deleting a slot frees its file."""
    keep = {f"{slot_id}.json" for slot_id in keep_ids}
    try:
        names = os.listdir(config.MACRO_DIR)
    except OSError:
        return
    for name in names:
        if name.endswith(".json") and name not in keep:
            try:
                os.remove(os.path.join(config.MACRO_DIR, name))
            except OSError:
                pass
