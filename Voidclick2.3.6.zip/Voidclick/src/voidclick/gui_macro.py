import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import macro_store
from . import slots as slot_model
from . import theme
from .gui_widgets import HotkeyPicker, PageHeader
from .hotkey_conflicts import find_conflict, macro_address
from .macro import MacroPlayer, MacroRecorder, load_macro, save_macro
from .rounded_button import RoundedButton
from .rounded_entry import RoundedEntry
from .rounded_select import RoundedSelect
from .slot_bar import SlotBar
from .speed_control import SpeedControl
from .transcribe import transcribe
from .toggle import ToggleSwitch


class MacroPage(ttk.Frame):
    """Records and replays macros.

    Several recordings live here at once, each a slot with its own play hotkey
    and its own player, so more than one can run at a time. Recording is a
    single global action: it records into whichever slot is open.
    """

    def __init__(self, master, hotkey_manager, cfg, on_config_change, notify=None,
                 send_to_script=None):
        super().__init__(master, padding=16)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change
        self.notify = notify or (lambda message: None)
        self.send_to_script = send_to_script or (lambda steps: None)

        self.index = 0
        self.players = {}       # slot id -> MacroPlayer
        self._events = {}       # slot id -> [MacroEvent], loaded on demand
        self._registered = set()
        self._recording_into = None

        self.recorder = MacroRecorder(
            on_event_count=self._on_event_count,
            ignore_key_tokens=self._current_hotkey_tokens,
        )

        self._loading = True
        self._build_ui()
        self._loading = False
        self._select_slot(0)

    # ------------------------------------------------------------------ slots

    @property
    def slots(self):
        return self.cfg["macros"]

    @property
    def slot(self):
        self.index = max(0, min(self.index, len(self.slots) - 1))
        return self.slots[self.index]

    @property
    def events(self):
        return self._events_for(self.slot["id"])

    def _events_for(self, slot_id):
        """Recordings load from their own file the first time they're needed."""
        if slot_id not in self._events:
            self._events[slot_id] = macro_store.load(slot_id)
        return self._events[slot_id]

    def _player_for(self, slot_id):
        if slot_id not in self.players:
            self.players[slot_id] = MacroPlayer(
                on_state_change=lambda playing, i=slot_id: self._on_play_state_change(i, playing),
                on_progress=lambda loop, count, i=slot_id: self._on_progress(i, loop, count),
            )
        return self.players[slot_id]

    @property
    def player(self):
        return self._player_for(self.slot["id"])

    def _slot_labels(self):
        labels = []
        for slot in self.slots:
            label = slot_model.slot_label(slot["name"], slot["play_hotkey"])
            player = self.players.get(slot["id"])
            if player is not None and player.playing:
                label += "  ●"
            labels.append(label)
        return labels

    def _refresh_slot_bar(self):
        self.slot_bar.refresh(
            self._slot_labels(), self.index, self.slot["name"],
            can_add=len(self.slots) < slot_model.MAX_SLOTS,
            can_delete=len(self.slots) > 1,
        )

    def _select_slot(self, index):
        if self.recorder.recording:
            self.notify("stop recording before switching")
            self._refresh_slot_bar()
            return
        self.index = max(0, min(index, len(self.slots) - 1))
        self._loading = True
        try:
            slot = self.slot
            self.play_picker.set_combo(slot["play_hotkey"])
            self.play_mode_var.set(slot["play_hotkey_mode"])
            self.loop_var.set(str(slot["loop_count"]))
            self.continuous_var.set(slot["continuous_loop"])
            self.continuous_toggle.refresh()
            self.speed_control.set_speed(slot["playback_speed"])
            self.player.speed = float(slot["playback_speed"])
        finally:
            self._loading = False
        self._update_loop_entry_state()
        self._refresh_slot_bar()
        self._sync_play_button()

    def _add_slot(self):
        if len(self.slots) >= slot_model.MAX_SLOTS:
            self.notify(f"{slot_model.MAX_SLOTS} macros is the limit")
            return
        new = slot_model.new_macro_slot(len(self.slots))
        new["name"] = slot_model.unique_name(self.slots, new["name"])
        self.slots.append(new)
        self._events[new["id"]] = []
        self.on_config_change()
        self._select_slot(len(self.slots) - 1)
        self._register_hotkeys()

    def _delete_slot(self):
        if len(self.slots) <= 1:
            self.notify("the last macro can't be deleted")
            return
        doomed = self.slot
        count = len(self._events_for(doomed["id"]))
        if count and not messagebox.askyesno(
                "Delete macro", f"Delete “{doomed['name']}” and its "
                f"{count} recorded event(s)?"):
            return
        self._player_for(doomed["id"]).stop()
        self.hotkey_manager.unregister(f"macro_play_{doomed['id']}")
        self._registered.discard(doomed["id"])
        self.players.pop(doomed["id"], None)
        self._events.pop(doomed["id"], None)
        macro_store.delete(doomed["id"])
        self.slots.remove(doomed)
        self.on_config_change()
        self._select_slot(min(self.index, len(self.slots) - 1))
        self._register_hotkeys()

    def _rename_slot(self, name):
        self.slot["name"] = slot_model.unique_name(self.slots, name, ignore_index=self.index)
        self.on_config_change()
        self._refresh_slot_bar()

    def _current_hotkey_tokens(self):
        """Keys that must not land in a recording, or playback would retrigger."""
        tokens = set()
        combos = [self.cfg["general"]["record_hotkey"]]
        combos += [slot["play_hotkey"] for slot in self.slots]
        for combo in combos:
            if combo:
                tokens |= set(combo.split("+"))
        return tokens

    # ------------------------------------------------------------------ layout

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}
        PageHeader(self, "Macro Recorder").grid(
            row=0, column=0, columnspan=3, sticky="ew", pady=(0, 10))
        self.columnconfigure(1, weight=1)

        row = 1
        ttk.Label(self, text="Macro:").grid(row=row, column=0, sticky="w", **pad)
        self.slot_bar = SlotBar(self, on_select=self._select_slot, on_add=self._add_slot,
                                 on_delete=self._delete_slot, on_rename=self._rename_slot)
        self.slot_bar.grid(row=row, column=1, columnspan=2, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Play hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.play_picker = HotkeyPicker(
            self, self.hotkey_manager, self.slots[0]["play_hotkey"],
            self._on_play_hotkey_change)
        self.play_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Play mode:").grid(row=row, column=0, sticky="w", **pad)
        self.play_mode_var = tk.StringVar(value=self.slots[0]["play_hotkey_mode"])
        RoundedSelect(self, self.play_mode_var, ["toggle", "hold"],
                       command=self._on_play_mode_change).grid(
            row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Record hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.record_picker = HotkeyPicker(
            self, self.hotkey_manager, self.cfg["general"]["record_hotkey"],
            self._on_record_hotkey_change)
        self.record_picker.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Loop count:").grid(row=row, column=0, sticky="w", **pad)
        self.loop_var = tk.StringVar(value=str(self.slots[0]["loop_count"]))
        self.loop_entry = RoundedEntry(self, self.loop_var, width=8)
        self.loop_entry.grid(row=row, column=1, sticky="w", **pad)
        self.loop_entry.bind_commit(self._commit_loop)
        row += 1

        ttk.Label(self, text="Playback speed:").grid(row=row, column=0, sticky="w", **pad)
        self.speed_control = SpeedControl(
            self, self.slots[0]["playback_speed"], self._on_speed_change)
        self.speed_control.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        self.continuous_var = tk.BooleanVar(value=self.slots[0]["continuous_loop"])
        self.continuous_toggle = ToggleSwitch(
            self, "Loop continuously (until stopped)", self.continuous_var,
            self._on_continuous_change,
        )
        self.continuous_toggle.grid(row=row, column=0, columnspan=2, sticky="w", **pad)
        row += 1
        self._update_loop_entry_state()

        btn_frm = ttk.Frame(self)
        btn_frm.grid(row=row, column=0, columnspan=2, sticky="ew", **pad)
        btn_frm.columnconfigure((0, 1), weight=1)
        self.record_btn = RoundedButton(
            btn_frm, "Record", command=self._toggle_record, bg=theme.GREEN,
            hover_bg=theme.GREEN_HOVER, fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.record_btn.grid(row=0, column=0, sticky="ew", padx=(0, 4))
        self.play_btn = RoundedButton(
            btn_frm, "Play", command=self._toggle_play, bg=theme.GREEN,
            hover_bg=theme.GREEN_HOVER, fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.play_btn.grid(row=0, column=1, sticky="ew", padx=(4, 0))
        row += 1

        RoundedButton(
            self, "Convert to Script", command=self._to_script, bg=theme.BG_FIELD,
            hover_bg=theme.GREEN, fg=theme.FG, parent_bg=theme.BG_PANEL, height=30,
            font=("Segoe UI", 9),
        ).grid(row=row, column=0, columnspan=2, sticky="ew", **pad)
        row += 1

        btn_frm2 = ttk.Frame(self)
        btn_frm2.grid(row=row, column=0, columnspan=2, sticky="ew", **pad)
        btn_frm2.columnconfigure((0, 1, 2), weight=1)
        for i, (label, command) in enumerate((("Save...", self._save), ("Load...", self._load),
                                               ("Clear", self._clear))):
            RoundedButton(
                btn_frm2, label, command=command, bg=theme.BG_FIELD, hover_bg=theme.BORDER,
                fg=theme.FG, parent_bg=theme.BG_PANEL, height=30, font=("Segoe UI", 9),
            ).grid(row=0, column=i, sticky="ew", padx=(0 if i == 0 else 4, 0))
        row += 1

        self.status_var = tk.StringVar(value="Idle — 0 events")
        ttk.Label(self, textvariable=self.status_var, style="Value.TLabel").grid(
            row=row, column=0, columnspan=2, **pad)

    # ------------------------------------------------------------------ config

    def refresh_from_config(self):
        self._events = {}
        self.record_picker.set_combo(self.cfg["general"]["record_hotkey"])
        self._select_slot(self.index)
        self._register_hotkeys()

    def _commit_loop(self):
        try:
            v = int(self.loop_var.get())
            if v < 0:
                raise ValueError
        except ValueError:
            v = self.slot["loop_count"]
        self.loop_var.set(str(v))
        self.slot["loop_count"] = v
        self.on_config_change()

    def _on_speed_change(self, speed):
        self.slot["playback_speed"] = speed
        self.player.speed = speed
        self.on_config_change()

    def _on_continuous_change(self):
        self.slot["continuous_loop"] = self.continuous_var.get()
        if not self._loading:
            self.on_config_change()
        self._update_loop_entry_state()

    def _update_loop_entry_state(self):
        self.loop_entry.config(state="disabled" if self.continuous_var.get() else "normal")

    def _on_record_hotkey_change(self, combo_string):
        from .hotkey_conflicts import fixed_address

        clash = find_conflict(self.cfg, fixed_address("general", "record_hotkey"),
                              combo_string)
        if clash:
            combo_string = ""
            self.record_picker.set_combo("")
            self.notify(f"Already used by {clash} — pick another key")
        self.cfg["general"]["record_hotkey"] = combo_string
        self.on_config_change()
        self._register_hotkeys()

    def _on_play_hotkey_change(self, combo_string):
        clash = find_conflict(self.cfg, macro_address(self.index), combo_string)
        if clash:
            combo_string = ""
            self.play_picker.set_combo("")
            self.notify(f"Already used by {clash} — pick another key")
        self.slot["play_hotkey"] = combo_string
        self.on_config_change()
        self._refresh_slot_bar()
        self._register_hotkeys()

    def _on_play_mode_change(self):
        self.slot["play_hotkey_mode"] = self.play_mode_var.get()
        self.on_config_change()
        self._register_hotkeys()

    def _register_hotkeys(self):
        self.hotkey_manager.register(
            "macro_record", self.cfg["general"]["record_hotkey"],
            lambda: self.after(0, self._toggle_record))

        live = set()
        for index, slot in enumerate(self.slots):
            name = f"macro_play_{slot['id']}"
            live.add(slot["id"])
            if slot["play_hotkey_mode"] == "hold":
                self.hotkey_manager.register(
                    name, slot["play_hotkey"],
                    lambda i=index: self.after(0, self._start_play, i),
                    on_release=lambda i=index: self.after(0, self._stop_slot, i),
                )
            else:
                self.hotkey_manager.register(
                    name, slot["play_hotkey"],
                    lambda i=index: self.after(0, self._toggle_play, i))
        for stale in self._registered - live:
            self.hotkey_manager.unregister(f"macro_play_{stale}")
        self._registered = live

    # ------------------------------------------------------------------ record

    def force_stop_recording(self):
        """Used by the panic stop — end a recording without toggling one back on."""
        if self.recorder.recording:
            self._toggle_record()

    def _toggle_record(self):
        if self.recorder.recording:
            self.recorder.stop()
            slot_id = self._recording_into or self.slot["id"]
            self._events[slot_id] = self.recorder.events
            macro_store.save(slot_id, self.recorder.events)
            self._recording_into = None
            self.record_btn.set_text("Record")
            self.record_btn.set_colors(theme.GREEN, theme.GREEN_HOVER)
            self.status_var.set(f"Idle — {len(self.recorder.events)} events recorded")
            self._refresh_slot_bar()
        else:
            if self.player.playing:
                return
            self._recording_into = self.slot["id"]
            self.recorder.start()
            self.record_btn.set_text("Stop Recording")
            self.record_btn.set_colors(theme.ORANGE, theme.ORANGE_HOVER)
            self.status_var.set(f"Recording into “{self.slot['name']}”... 0 events")

    # ------------------------------------------------------------------ play

    def _toggle_play(self, index=None):
        target = index if index is not None else self.index
        if not 0 <= target < len(self.slots):
            return
        player = self._player_for(self.slots[target]["id"])
        if player.playing:
            player.stop()
        else:
            self._start_play(target)

    def _start_play(self, index=None):
        target_index = index if index is not None else self.index
        if not 0 <= target_index < len(self.slots):
            return
        slot = self.slots[target_index]
        player = self._player_for(slot["id"])
        events = self._events_for(slot["id"])
        if player.playing or self.recorder.recording or not events:
            return
        if slot["continuous_loop"]:
            loops = 0
        else:
            loops = max(int(slot["loop_count"] or 1), 1)
        player.speed = float(slot["playback_speed"])
        player.play(events, loop_count=loops)

    def _stop_slot(self, index):
        if 0 <= index < len(self.slots):
            self._player_for(self.slots[index]["id"]).stop()

    def stop_all(self):
        for player in self.players.values():
            player.stop()

    def any_playing(self):
        return any(player.playing for player in self.players.values())

    def _sync_play_button(self):
        playing = self.player.playing
        self.play_btn.set_text("Stop" if playing else "Play")
        self.play_btn.set_colors(
            theme.ORANGE if playing else theme.GREEN,
            theme.ORANGE_HOVER if playing else theme.GREEN_HOVER,
        )
        if not playing and not self.recorder.recording:
            running = sum(1 for p in self.players.values() if p.playing)
            extra = f" · {running} playing" if running else ""
            self.status_var.set(f"Idle — {len(self.events)} events{extra}")

    def _on_event_count(self, count):
        self.after(0, lambda: self.status_var.set(f"Recording... {count} events"))

    def _on_play_state_change(self, slot_id, playing):
        def update():
            self._refresh_slot_bar()
            if self.slot["id"] == slot_id:
                self._sync_play_button()
            elif not self.player.playing and not self.recorder.recording:
                self._sync_play_button()
        self.after(0, update)

    def _on_progress(self, slot_id, loop, loop_count):
        if self.slot["id"] != slot_id:
            return

        def upd():
            if loop_count > 0:
                self.status_var.set(f"Playing loop {loop}/{loop_count}")
            else:
                self.status_var.set(f"Playing loop {loop}")
        self.after(0, upd)

    # ------------------------------------------------------------------ files

    def _save(self):
        if not self.events:
            messagebox.showinfo("Save Macro", "No events to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                             filetypes=[("Macro files", "*.json")])
        if path:
            save_macro(path, self.events)

    def _load(self):
        path = filedialog.askopenfilename(filetypes=[("Macro files", "*.json")])
        if not path:
            return
        try:
            loaded = load_macro(path)
        except (OSError, ValueError, KeyError) as e:
            messagebox.showerror("Load Macro", f"Failed to load macro:\n{e}")
            return
        self._events[self.slot["id"]] = loaded
        macro_store.save(self.slot["id"], loaded)
        self.status_var.set(f"Idle — {len(loaded)} events loaded")

    def _to_script(self):
        """Offer to rebuild the recording as editable, position-free script steps."""
        if not self.events:
            messagebox.showinfo("Convert to Script", "Record or load a macro first.")
            return

        steps, report = transcribe(self.events)
        if not steps:
            messagebox.showerror(
                "Convert to Script",
                "Nothing could be converted.\n\n" + "\n".join(report.warnings))
            return

        message = f"{report.summary()}\n\nThis becomes {len(steps)} step(s)."
        if report.warnings:
            message += "\n\nWon't carry across:\n  - " + "\n  - ".join(report.warnings)
        message += "\n\nReplace whatever is on the Script page?"

        if messagebox.askyesno("Convert to Script", message):
            self.send_to_script(steps)

    def _clear(self):
        self._events[self.slot["id"]] = []
        macro_store.delete(self.slot["id"])
        self.status_var.set("Idle — 0 events")
        self._refresh_slot_bar()
