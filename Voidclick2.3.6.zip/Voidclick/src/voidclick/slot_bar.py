"""The slot picker used by the Macro and Script pages.

A dropdown listing every slot, an entry that renames the open one, and add and
delete buttons. The collapsed dropdown shows the slot's hotkey next to its name,
so the page can be glanced at to see what runs what without opening anything.

The list is rebuilt each time it opens rather than at construction, because
names and hotkeys change while the app is running.
"""

import tkinter as tk
from tkinter import ttk

from . import gradient, theme
from .rounded_button import RoundedButton
from .rounded_entry import RoundedEntry


class SlotDropdown(tk.Frame):
    """RoundedSelect's look, but over a list that changes at runtime."""

    def __init__(self, master, on_select, width=150, parent_bg=theme.BG_PANEL,
                 height=28, radius=8):
        super().__init__(master, bg=parent_bg)
        self.on_select = on_select
        self.parent_bg = parent_bg
        self.radius = radius
        self.height = height
        self._labels = []
        self._index = 0
        self._hover = False

        self.canvas = tk.Canvas(self, width=width, height=height, highlightthickness=0,
                                 bd=0, bg=parent_bg, cursor="hand2")
        self.canvas.pack()
        self.canvas.bind("<Button-1>", self._open)
        self.canvas.bind("<Enter>", self._on_enter)
        self.canvas.bind("<Leave>", self._on_leave)
        self._draw()

    def set_slots(self, labels, index):
        self._labels = list(labels)
        self._index = max(0, min(index, len(self._labels) - 1)) if self._labels else 0
        self._draw()

    def _on_enter(self, _event):
        self._hover = True
        self._draw()

    def _on_leave(self, _event):
        self._hover = False
        self._draw()

    def _open(self, _event):
        menu = tk.Menu(self, tearoff=0, bg=theme.BG_FIELD, fg=theme.FG,
                       activebackground=theme.GREEN, activeforeground=theme.TEXT_ON_ACCENT,
                       bd=0, activeborderwidth=0, font=("Segoe UI", 9))
        for i, label in enumerate(self._labels):
            menu.add_command(label=label, command=lambda n=i: self._choose(n))
        try:
            menu.tk_popup(self.canvas.winfo_rootx(),
                          self.canvas.winfo_rooty() + self.height)
        finally:
            menu.grab_release()

    def _choose(self, index):
        self._index = index
        self._draw()
        self.on_select(index)

    def _draw(self):
        c = self.canvas
        c.delete("all")
        w = max(c.winfo_width(), int(c["width"]))
        h = max(c.winfo_height(), self.height)
        r = min(self.radius, h // 2)

        base = theme.BORDER if self._hover else theme.BG_FIELD
        gradient.rounded(c, 0, 0, w, h, r, base, base, bg=self.parent_bg)

        text = self._labels[self._index] if self._labels else ""
        # The hotkey half is dimmed so the name stays the thing you read first.
        name, _, key = text.partition("·")
        x = c.create_text(r + 6, h / 2, text=name.strip(), anchor="w", fill=theme.FG,
                          font=("Segoe UI", 9))
        if key.strip():
            end = c.bbox(x)[2]
            c.create_text(end + 8, h / 2, text=key.strip(), anchor="w",
                          fill=theme.GREEN, font=("Segoe UI", 8))

        cx, cy, size = w - r - 6, h / 2, 3.5
        c.create_polygon(cx - size, cy - size / 2, cx + size, cy - size / 2, cx, cy + size,
                          fill=theme.FG_MUTED, outline=theme.FG_MUTED)


class SlotBar(ttk.Frame):
    """Dropdown + rename entry + add/delete, driven entirely by its callbacks."""

    def __init__(self, master, on_select, on_add, on_delete, on_rename):
        super().__init__(master)
        self.on_rename = on_rename

        self.dropdown = SlotDropdown(self, on_select)
        self.dropdown.grid(row=0, column=0, sticky="w")

        self.name_var = tk.StringVar()
        self.name_entry = RoundedEntry(self, self.name_var, width=9)
        self.name_entry.grid(row=0, column=1, sticky="w", padx=(6, 0))
        self.name_entry.bind_commit(self._commit_name)

        self.add_btn = RoundedButton(
            self, "+", command=on_add, bg=theme.BG_FIELD, hover_bg=theme.GREEN,
            fg=theme.FG, parent_bg=theme.BG_PANEL, height=28, width=30,
            font=("Segoe UI", 11, "bold"), radius=8)
        self.add_btn.grid(row=0, column=2, padx=(6, 0))

        self.delete_btn = RoundedButton(
            self, "✕", command=on_delete, bg=theme.BG_FIELD,
            hover_bg=theme.ORANGE, fg=theme.FG, parent_bg=theme.BG_PANEL,
            height=28, width=30, font=("Segoe UI", 9), radius=8)
        self.delete_btn.grid(row=0, column=3, padx=(4, 0))

    def _commit_name(self):
        self.on_rename(self.name_var.get())

    def refresh(self, labels, index, name, can_add=True, can_delete=True):
        self.dropdown.set_slots(labels, index)
        # Don't fight the user while they're mid-edit in the name box. focus_get
        # raises rather than returning None when focus has left the app, which a
        # global hotkey firing mid-edit makes entirely normal here.
        try:
            editing = self.focus_get() is self.name_entry.entry
        except (tk.TclError, KeyError):
            editing = False
        if not editing:
            self.name_var.set(name)
        self.add_btn.set_enabled(can_add)
        self.delete_btn.set_enabled(can_delete)
