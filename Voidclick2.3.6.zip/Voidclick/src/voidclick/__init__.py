"""Void Click — autoclicker, macro recorder and step-script tool."""

__version__ = "1.3.6"

from .run import main

__all__ = ["main", "__version__"]
