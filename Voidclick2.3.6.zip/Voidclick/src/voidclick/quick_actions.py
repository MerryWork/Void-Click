"""Runtime adjustments driven by hotkeys: swapping bindings and stepping speed."""

# The actions whose start hotkey can be swapped.
SWAPPABLE = {
    "autoclicker": "autoclicker",
    "macro": "macro play",
    "script": "script run",
}

PAIRS = ["autoclicker|macro", "autoclicker|script", "macro|script"]


def pair_label(pair):
    left, right = split_pair(pair)
    return f"{SWAPPABLE[left]} <-> {SWAPPABLE[right]}"


def split_pair(pair):
    left, _, right = pair.partition("|")
    if left not in SWAPPABLE or right not in SWAPPABLE:
        left, right = PAIRS[0].split("|")
    return left, right


def _target(cfg, which, script_index, macro_index):
    """Where one side of a swap actually lives: (holder dict, key, display name).

    Scripts and macros are slots now, so "the script hotkey" means the one on
    the slot currently open on that page -- swapping should act on what the user
    is looking at, not always on the first slot.
    """
    if which == "autoclicker":
        return cfg["autoclicker"], "hotkey", "autoclicker"
    if which == "script":
        chosen = cfg["scripts"][min(max(script_index, 0), len(cfg["scripts"]) - 1)]
        return chosen, "hotkey", f"script “{chosen['name']}”"
    chosen = cfg["macros"][min(max(macro_index, 0), len(cfg["macros"]) - 1)]
    return chosen, "play_hotkey", f"macro “{chosen['name']}”"


def swap_hotkeys(cfg, pair, script_index=0, macro_index=0):
    """Trade the two actions' start hotkeys. Returns their display names.

    Swapping can't create a conflict: the two keys were already distinct and
    they only change places.
    """
    left, right = split_pair(pair)
    left_holder, left_key, left_name = _target(cfg, left, script_index, macro_index)
    right_holder, right_key, right_name = _target(cfg, right, script_index, macro_index)

    left_holder[left_key], right_holder[right_key] = (
        right_holder[right_key], left_holder[left_key])
    return left_name, right_name


# Speeds the up/down hotkeys step through.
SPEED_STEPS = [0.25, 0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 3.0, 4.0]


def step_speed(current, direction):
    """Next speed up (+1) or down (-1) the ladder, clamped at both ends."""
    try:
        current = float(current)
    except (TypeError, ValueError):
        current = 1.0

    # Land on the nearest rung first, so a hand-typed speed still steps sanely.
    nearest = min(range(len(SPEED_STEPS)), key=lambda i: abs(SPEED_STEPS[i] - current))
    index = min(max(nearest + direction, 0), len(SPEED_STEPS) - 1)
    return SPEED_STEPS[index]
