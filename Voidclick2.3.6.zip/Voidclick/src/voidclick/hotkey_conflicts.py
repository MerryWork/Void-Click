"""Keeps the action hotkeys distinct from one another.

Two actions sharing a key is never what someone means: with subset matching both
would fire at once, so one of them is silently unusable.
"""

import time

from .slots import bindings, fixed_address, macro_address, script_address

# Re-exported so callers can name a binding without importing two modules.
__all__ = ["find_conflict", "Throttle", "fixed_address", "macro_address",
           "script_address", "managed"]


def managed(cfg):
    """Every hotkey that has to stay distinct, as (address, combo, label).

    Slots made this list variable: it grows with every script and macro added,
    so it's derived from the config rather than written out by hand.
    """
    return bindings(cfg)


def find_conflict(cfg, address, combo):
    """Name of another managed hotkey already using `combo`, or None.

    `address` identifies the binding being set, so it doesn't clash with itself
    — build one with fixed_address / script_address / macro_address.

    Empty bindings never conflict — clearing one is how a conflict is resolved,
    so two blank hotkeys must be allowed to coexist.
    """
    if not combo:
        return None
    for other_address, other_combo, label in managed(cfg):
        if other_address == address:
            continue
        if other_combo == combo:
            return label
    return None


class Throttle:
    """Lets an event through at most once per window.

    Spamming a conflicting key would otherwise stack a banner per attempt; while
    one is still showing, further requests are dropped rather than queued.
    """

    def __init__(self, seconds=1.0):
        self.seconds = seconds
        self._until = 0.0

    def allow(self):
        now = time.monotonic()
        if now < self._until:
            return False
        self._until = now + self.seconds
        return True

    def reset(self):
        self._until = 0.0
