"""Settings persistence.

Settings live in a per-user data directory rather than beside the code. An
installed package sits in site-packages and a frozen executable unpacks to a
temp folder — both are read-only or discarded, so writing next to the source
would silently lose every setting on a real installation.

Recorded macros go in a `macros` folder next to config.json, one file per slot;
see `macro_store`.
"""

import json
import os
import sys
from pathlib import Path

from . import slots

APP_DIR_NAME = "VoidClick"


def data_dir():
    """Per-user config location, following each platform's convention."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming"
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config"
    return Path(base) / APP_DIR_NAME


CONFIG_PATH = str(data_dir() / "config.json")
MACRO_DIR = str(data_dir() / "macros")

# Sections that hold a list of slots rather than a flat set of values.
LIST_SECTIONS = ("scripts", "macros")

DEFAULTS = {
    "autoclicker": {
        "interval_ms": 100.0,
        "duty_cycle": 50.0,
        "randomization": 0.0,
        "click_limit": 0,
        "position_jitter": 0,
        "button": "left",
        "hotkey": "f6",
        "hotkey_mode": "toggle",   # toggle | hold
        "rate_unit": "ms",         # ms | cps
    },
    "general": {
        "record_hotkey": "f7",     # records into whichever macro slot is selected
        "panic_hotkey": "f12",
        "panic_quits_app": False,
        "swap_hotkey": "",
        "swap_pair": "autoclicker|macro",
        "always_on_top": False,
        "record_mouse_moves": True,
    },
}


def defaults_copy():
    """A fresh config. Slots are built rather than copied, so their ids differ."""
    cfg = json.loads(json.dumps(DEFAULTS))
    cfg["scripts"] = [slots.new_script_slot(0, hotkey="f9")]
    cfg["macros"] = [slots.new_macro_slot(0, play_hotkey="f8")]
    return cfg


def _migrate_legacy(data):
    """Fold a pre-slots config into the new shape.

    Versions before 1.3 had one "script" section and one "macro" section. Their
    settings become the first slot of each list, so an existing setup keeps its
    hotkeys instead of silently reverting to defaults.
    """
    if not isinstance(data, dict):
        return data
    data = dict(data)

    old_script = data.get("script")
    if isinstance(old_script, dict) and not isinstance(data.get("scripts"), list):
        data["scripts"] = [slots.new_script_slot(
            0,
            hotkey=old_script.get("hotkey", "f9"),
            hotkey_mode=old_script.get("hotkey_mode", "toggle"),
            loop=old_script.get("loop", True),
            speed=old_script.get("speed", 1.0),
        )]

    old_macro = data.get("macro")
    if isinstance(old_macro, dict):
        if not isinstance(data.get("macros"), list):
            data["macros"] = [slots.new_macro_slot(
                0,
                play_hotkey=old_macro.get("play_hotkey", "f8"),
                play_hotkey_mode=old_macro.get("play_hotkey_mode", "toggle"),
                loop_count=old_macro.get("loop_count", 1),
                continuous_loop=old_macro.get("continuous_loop", False),
                playback_speed=old_macro.get("playback_speed", 1.0),
            )]
        # Recording became a single global action once macros had slots.
        general = dict(data.get("general") or {})
        general.setdefault("record_hotkey", old_macro.get("record_hotkey", "f7"))
        data["general"] = general

    return data


def _merge(cfg, data):
    data = _migrate_legacy(data)
    for section in LIST_SECTIONS:
        incoming = data.get(section)
        if isinstance(incoming, list) and incoming:
            cfg[section] = incoming
    for section, values in cfg.items():
        if section in LIST_SECTIONS:
            continue
        saved = data.get(section, {})
        if not isinstance(saved, dict):
            continue
        # Known keys only, so a setting removed in a later version doesn't
        # linger in the file forever.
        values.update({k: v for k, v in saved.items() if k in values})
    slots.normalize(cfg)
    return cfg


def load_config():
    cfg = defaults_copy()
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r") as f:
                data = json.load(f)
            _merge(cfg, data)
        except (json.JSONDecodeError, OSError):
            pass
    return cfg


def apply_data(cfg, data):
    """Replace cfg's contents with `data`, falling back to defaults per key.

    Used when importing a settings file, which may come from a different version
    and be missing sections or carry keys we no longer use.
    """
    if not isinstance(data, dict):
        raise ValueError("settings file is not a JSON object")
    for section, incoming in data.items():
        if section in LIST_SECTIONS:
            if not isinstance(incoming, list):
                raise ValueError(f"section '{section}' is not a JSON list")
        elif section in DEFAULTS and not isinstance(incoming, dict):
            raise ValueError(f"section '{section}' is not a JSON object")

    fresh = _merge(defaults_copy(), data)
    cfg.clear()
    cfg.update(fresh)


def save_config(cfg):
    try:
        os.makedirs(os.path.dirname(CONFIG_PATH), exist_ok=True)
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass
