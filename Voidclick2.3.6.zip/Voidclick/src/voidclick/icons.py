﻿"""Tab icons and the app logo.

Tk's canvas has no anti-aliasing, so polygons and circles drawn with
create_polygon/create_oval come out visibly stair-stepped. Each icon is instead
described as a "is this point inside the shape?" predicate, supersampled into a
per-pixel coverage value, and composited into a PhotoImage. Results are cached,
so the cost is paid once per icon/size/colour.
"""

import math
import tkinter as tk

from . import gradient

SAMPLES = 3          # 3x3 subpixels; enough to kill the stepping at icon sizes
_CACHE = {}


# --------------------------------------------------------------------- shapes

def _in_disc(px, py, cx, cy, radius):
    return (px - cx) ** 2 + (py - cy) ** 2 <= radius * radius


def _in_ring(px, py, cx, cy, outer, inner):
    return _in_disc(px, py, cx, cy, outer) and not _in_disc(px, py, cx, cy, inner)


def _in_rounded(px, py, x1, y1, x2, y2, r):
    cx = min(max(px, x1 + r), x2 - r)
    cy = min(max(py, y1 + r), y2 - r)
    if x1 <= px <= x2 and y1 <= py <= y2:
        return (px - cx) ** 2 + (py - cy) ** 2 <= r * r or (
            x1 + r <= px <= x2 - r or y1 + r <= py <= y2 - r)
    return False


def _near_segment(px, py, x1, y1, x2, y2, width):
    dx, dy = x2 - x1, y2 - y1
    length_sq = dx * dx + dy * dy
    if length_sq == 0:
        return _in_disc(px, py, x1, y1, width / 2)
    t = max(0.0, min(1.0, ((px - x1) * dx + (py - y1) * dy) / length_sq))
    return _in_disc(px, py, x1 + t * dx, y1 + t * dy, width / 2)


def _in_polygon(px, py, points):
    inside = False
    j = len(points) - 1
    for i, (xi, yi) in enumerate(points):
        xj, yj = points[j]
        if (yi > py) != (yj > py) and px < (xj - xi) * (py - yi) / (yj - yi) + xi:
            inside = not inside
        j = i
    return inside


# ------------------------------------------------------------------ rasteriser

def _rasterize(master, size, predicate, fg, bg_at):
    """Supersample `predicate` into an anti-aliased square PhotoImage.

    `bg_at(y)` gives the backdrop colour for a row, so a shape can sit on a
    gradient without banding against a single flat colour.
    """
    size = int(size)
    image = tk.PhotoImage(master=master, width=size, height=size)
    step = 1.0 / SAMPLES
    total = SAMPLES * SAMPLES

    rows = []
    for y in range(size):
        backdrop = bg_at(y)
        row = []
        for x in range(size):
            hits = 0
            for sy in range(SAMPLES):
                for sx in range(SAMPLES):
                    if predicate(x + (sx + 0.5) * step, y + (sy + 0.5) * step):
                        hits += 1
            if hits == 0:
                row.append(backdrop)
            elif hits == total:
                row.append(fg)
            else:
                row.append(gradient.lerp(backdrop, fg, hits / total))
        rows.append("{" + " ".join(row) + "}")

    image.put(" ".join(rows))
    return image


def _icon(canvas, name, builder, cx, cy, size, color, bg):
    """Draw a cached, anti-aliased icon centred on (cx, cy)."""
    size = int(size)
    # A PhotoImage belongs to the interpreter that made it, so the cache is
    # keyed per Tk instance, or a second root would reuse dead images.
    key = (id(canvas.tk), name, size, color, bg)
    if key not in _CACHE:
        _CACHE[key] = _rasterize(canvas, size, builder(size), color, lambda _y: bg)
    canvas.create_image(cx, cy, image=_CACHE[key])


# ---------------------------------------------------------------- tab icons

def _mouse_shape(size):
    w, h = size * 0.60, size * 0.96
    x1, y1 = (size - w) / 2, (size - h) / 2
    x2, y2 = x1 + w, y1 + h
    stroke = max(size * 0.09, 1.4)
    radius = w / 2

    def inside(px, py):
        outer = _in_rounded(px, py, x1, y1, x2, y2, radius)
        inner = _in_rounded(px, py, x1 + stroke, y1 + stroke, x2 - stroke, y2 - stroke,
                             max(radius - stroke, 0.5))
        if outer and not inner:
            return True
        return _near_segment(px, py, size / 2, y1 + h * 0.16, size / 2, y1 + h * 0.36, stroke)
    return inside


def _record_shape(size):
    centre = size / 2
    outer = size * 0.46
    stroke = max(size * 0.09, 1.4)

    def inside(px, py):
        if _in_ring(px, py, centre, centre, outer, outer - stroke):
            return True
        return _in_disc(px, py, centre, centre, size * 0.19)
    return inside


def _gear_shape(size):
    centre = size / 2
    r_out, r_in = size * 0.50, size * 0.36
    steps = 32
    points = []
    for i in range(steps):
        angle = 2 * math.pi * i / steps
        r = r_out if (i % 4) in (1, 2) else r_in
        points.append((centre + r * math.cos(angle), centre + r * math.sin(angle)))

    def inside(px, py):
        return _in_polygon(px, py, points) and not _in_disc(px, py, centre, centre,
                                                             size * 0.16)
    return inside


def _steps_shape(size):
    stroke = max(size * 0.09, 1.4)
    dot = size * 0.07
    gap = size * 0.32
    left = size * 0.10
    centre = size / 2

    def inside(px, py):
        for i in range(3):
            y = centre - gap + i * gap
            if _in_disc(px, py, left, y, dot):
                return True
            end = size * (0.86 if i != 1 else 0.62)
            if _near_segment(px, py, left + size * 0.14, y, end, y, stroke):
                return True
        return False
    return inside


def _heart_shape(size):
    """Two lobes over a point. Drawn solid — it reads at small sizes, an
    outline doesn't."""
    left = (size * 0.30, size * 0.34)
    right = (size * 0.70, size * 0.34)
    radius = size * 0.215
    point = [(size * 0.075, size * 0.40), (size * 0.925, size * 0.40),
             (size * 0.50, size * 0.94)]

    def inside(px, py):
        if _in_disc(px, py, left[0], left[1], radius):
            return True
        if _in_disc(px, py, right[0], right[1], radius):
            return True
        return _in_polygon(px, py, point)
    return inside


def heart(canvas, cx, cy, size, color, bg=None):
    _icon(canvas, "heart", _heart_shape, cx, cy, size, color, bg or "#000000")


def mouse(canvas, cx, cy, size, color, bg=None):
    _icon(canvas, "mouse", _mouse_shape, cx, cy, size, color, bg or "#000000")


def record(canvas, cx, cy, size, color, bg=None):
    _icon(canvas, "record", _record_shape, cx, cy, size, color, bg or "#000000")


def gear(canvas, cx, cy, size, color, bg="#000000"):
    _icon(canvas, "gear", _gear_shape, cx, cy, size, color, bg or "#000000")


def steps(canvas, cx, cy, size, color, bg=None):
    _icon(canvas, "steps", _steps_shape, cx, cy, size, color, bg or "#000000")


# --------------------------------------------------------------------- logo

_BOLT = [(0.60, 0.00), (0.25, 0.52), (0.47, 0.52), (0.38, 1.00), (0.75, 0.44), (0.52, 0.44)]


def _bolt_shape(size, scale=0.66):
    offset = (1 - scale) / 2
    points = [(x * scale + offset, y * scale + offset) for x, y in _BOLT]
    scaled = [(x * size, y * size) for x, y in points]

    def inside(px, py):
        return _in_polygon(px, py, scaled)
    return inside


def _render_logo(master, size, badge_color, bolt_color, backdrop):
    """Badge and bolt rasterised together.

    Drawing the badge on the canvas and stamping a bolt image over it doesn't
    work: the image is a full square and paints over the badge's rounded
    corners. Both layers are therefore resolved per pixel in one pass.
    """
    image = tk.PhotoImage(master=master, width=size, height=size)
    radius = size * 0.28
    bolt = _bolt_shape(size)
    step = 1.0 / SAMPLES
    total = SAMPLES * SAMPLES

    rows = []
    for y in range(size):
        badge_tone = gradient.glass_color_at(badge_color, (y + 0.5) / size)
        row = []
        for x in range(size):
            badge_hits = bolt_hits = 0
            for sy in range(SAMPLES):
                for sx in range(SAMPLES):
                    px, py = x + (sx + 0.5) * step, y + (sy + 0.5) * step
                    if _in_rounded(px, py, 0, 0, size, size, radius):
                        badge_hits += 1
                        if bolt(px, py):
                            bolt_hits += 1
            if badge_hits == 0:
                row.append(backdrop)
                continue
            tone = gradient.lerp(backdrop, badge_tone, badge_hits / total)
            row.append(gradient.lerp(tone, bolt_color, bolt_hits / total)
                       if bolt_hits else tone)
        rows.append("{" + " ".join(row) + "}")

    image.put(" ".join(rows))
    return image


def logo(canvas, cx, cy, size, badge_color, bolt_color, badge_color_end=None):
    """App mark: a rounded gradient badge with a bolt, fully anti-aliased."""
    size = int(size)
    backdrop = canvas.cget("bg")
    key = (id(canvas.tk), "logo", size, badge_color, bolt_color, backdrop)
    if key not in _CACHE:
        _CACHE[key] = _render_logo(canvas, size, badge_color, bolt_color, backdrop)
    canvas.create_image(cx, cy, image=_CACHE[key])


# --------------------------------------------------------------- window icon

def _in_rounded_square(px, py, size, r):
    return _in_rounded(px, py, 0, 0, size, size, r)


def make_window_icon(master, size=40, badge_color="#3ddc84", bolt_color="#0d0f14"):
    """Build the taskbar/title-bar icon, anti-aliased and transparent outside."""
    image = tk.PhotoImage(master=master, width=size, height=size)
    radius = size * 0.28
    bolt = _bolt_shape(size)
    step = 1.0 / SAMPLES
    total = SAMPLES * SAMPLES

    rows, clear = [], []
    for y in range(size):
        row = []
        for x in range(size):
            badge_hits = 0
            bolt_hits = 0
            for sy in range(SAMPLES):
                for sx in range(SAMPLES):
                    px, py = x + (sx + 0.5) * step, y + (sy + 0.5) * step
                    if _in_rounded_square(px, py, size, radius):
                        badge_hits += 1
                        if bolt(px, py):
                            bolt_hits += 1
            if badge_hits == 0:
                clear.append((x, y))
                row.append(badge_color)
                continue
            base = gradient.lerp("#000000", badge_color, badge_hits / total)
            row.append(gradient.lerp(base, bolt_color, bolt_hits / total))
        rows.append("{" + " ".join(row) + "}")

    image.put(" ".join(rows))
    for x, y in clear:
        image.transparency_set(x, y, True)
    return image
