"""AutoHotkey as the middle language between a recording and a script.

A recording is a stream of timestamped events. A Script is a short list of
position-free steps. Converting one to the other used to be a single pile of
guesswork, and anything that didn't fit the four script verbs was dropped with
a warning -- scroll wheels and Ctrl+C among them.

AutoHotkey already has a vocabulary for every one of these things, so it is used
here as the intermediate form:

    recorded events ---> statements ---+---> .ahk text   (keeps everything)
                             ^         |
                             |         +---> script steps (position-free)
                        .ahk text

Going through statements is what makes the two halves separable. Each statement
is one thing that happened, named the way AutoHotkey would name it, and both
back ends are then straightforward walks over that list. It also draws the line
between what a script can hold and what it can't: AHK expresses a chord as
Send "^c" and a wheel tick as Send "{WheelDown}", neither of which needs a mouse
position, so both belong in scripts. Click "532 410" does need one, so that is
the part only the .ahk file can carry.

The generated text targets AutoHotkey v2.
"""

import re
from dataclasses import dataclass, field

# pynput key names (with the "Key." prefix already stripped) -> AHK key names.
AHK_KEY_NAMES = {
    "alt": "Alt", "alt_l": "LAlt", "alt_r": "RAlt", "alt_gr": "RAlt",
    "backspace": "Backspace", "caps_lock": "CapsLock",
    "cmd": "LWin", "cmd_l": "LWin", "cmd_r": "RWin",
    "ctrl": "Control", "ctrl_l": "LControl", "ctrl_r": "RControl",
    "delete": "Delete", "down": "Down", "end": "End", "enter": "Enter",
    "esc": "Escape", "home": "Home", "insert": "Insert", "left": "Left",
    "menu": "AppsKey", "num_lock": "NumLock", "page_down": "PgDn",
    "page_up": "PgUp", "pause": "Pause", "print_screen": "PrintScreen",
    "right": "Right", "scroll_lock": "ScrollLock", "shift": "Shift",
    "shift_l": "LShift", "shift_r": "RShift", "space": "Space",
    "tab": "Tab", "up": "Up",
    "media_play_pause": "Media_Play_Pause", "media_next": "Media_Next",
    "media_previous": "Media_Prev", "media_volume_up": "Volume_Up",
    "media_volume_down": "Volume_Down", "media_volume_mute": "Volume_Mute",
}
AHK_TO_KEY_NAME = {v.lower(): k for k, v in AHK_KEY_NAMES.items()}

# Keys that qualify a following key rather than standing on their own. Left and
# right variants collapse to one name, because a script step says "ctrl", not
# "the left control key".
MODIFIER_CANON = {
    "ctrl": "ctrl", "ctrl_l": "ctrl", "ctrl_r": "ctrl",
    "shift": "shift", "shift_l": "shift", "shift_r": "shift",
    "alt": "alt", "alt_l": "alt", "alt_r": "alt", "alt_gr": "alt",
    "cmd": "cmd", "cmd_l": "cmd", "cmd_r": "cmd",
}
# The prefix characters AHK's Send uses for modifiers, in a fixed order so the
# same chord always renders the same way.
MOD_PREFIX = {"ctrl": "^", "alt": "!", "shift": "+", "cmd": "#"}
MOD_ORDER = ("ctrl", "alt", "shift", "cmd")

BUTTON_NAMES = {"left": "Left", "right": "Right", "middle": "Middle"}
AHK_TO_BUTTON = {v.lower(): k for k, v in BUTTON_NAMES.items()}

# Characters Send reads as syntax rather than text; a key named with one of
# these can't go inside {...}, so it is typed literally instead.
SEND_SPECIAL = set("^!+#{}")

_FUNCTION_KEY = re.compile(r"^f([1-9]|1\d|2[0-4])$")


def is_modifier(key_name):
    return key_name in MODIFIER_CANON


def canon_modifier(key_name):
    """'ctrl_l' and 'ctrl_r' are both just 'ctrl' as far as a script cares."""
    return MODIFIER_CANON.get(key_name, key_name)


def to_ahk_key(key_name):
    """Script-style key name ('a', 'space', 'ctrl_l') -> AHK name."""
    key_name = (key_name or "").strip()
    if key_name in AHK_KEY_NAMES:
        return AHK_KEY_NAMES[key_name]
    if _FUNCTION_KEY.match(key_name.lower()):
        return key_name.upper()
    return key_name


def from_ahk_key(ahk_name):
    """AHK name -> script-style key name. The inverse of to_ahk_key."""
    ahk_name = (ahk_name or "").strip()
    lowered = ahk_name.lower()
    if lowered in AHK_TO_KEY_NAME:
        return AHK_TO_KEY_NAME[lowered]
    if _FUNCTION_KEY.match(lowered):
        return lowered
    return ahk_name


# ----------------------------------------------------------------- statements

@dataclass
class Statement:
    """One thing that happened, at the granularity AutoHotkey names it.

    `t` is seconds from the start of the recording. Waiting is not a statement:
    the gaps between timestamps are what produce Sleep on the way out, which
    keeps a single source of truth for timing.
    """

    op: str                                  # move | click | key | scroll
    args: dict = field(default_factory=dict)
    t: float = 0.0

    def describe(self):
        a = self.args
        if self.op == "move":
            return f"move to {a['x']},{a['y']}"
        if self.op == "click":
            return f"{a['button']} button {a['state']} at {a['x']},{a['y']}"
        if self.op == "key":
            return f"{a['name']} {a['state']}"
        if self.op == "scroll":
            return f"scroll {a['direction']} x{a['count']}"
        return self.op


def macro_key_to_script_key(stored):
    """Macros store repr(key) -- "'a'" or "Key.space"; we want 'a'/'space'."""
    stored = (stored or "").strip()
    if stored.startswith("Key."):
        return stored[4:]
    return stored.strip("'")


def _scroll_direction(dx, dy):
    """pynput reports wheel deltas; AHK names the direction instead."""
    if dy:
        return ("up" if dy > 0 else "down"), abs(int(dy)) or 1
    if dx:
        return ("right" if dx > 0 else "left"), abs(int(dx)) or 1
    return "down", 1


def build(events, include_moves=True):
    """Recorded macro events -> statements, in order and losing nothing.

    Mouse movement is optional because a recording holds ~50 samples a second of
    it, which is worth keeping in an .ahk file and never worth looking at in a
    script.
    """
    statements = []
    for event in events:
        if event.type == "move":
            if include_moves:
                statements.append(Statement("move", {
                    "x": event.data.get("x", 0), "y": event.data.get("y", 0)}, event.t))
        elif event.type == "click":
            statements.append(Statement("click", {
                "button": event.data.get("button", "left"),
                "state": "down" if event.data.get("pressed") else "up",
                "x": event.data.get("x", 0), "y": event.data.get("y", 0),
            }, event.t))
        elif event.type == "scroll":
            direction, count = _scroll_direction(
                event.data.get("dx", 0), event.data.get("dy", 0))
            statements.append(Statement("scroll", {
                "direction": direction, "count": count,
                "x": event.data.get("x", 0), "y": event.data.get("y", 0),
            }, event.t))
        elif event.type in ("key_press", "key_release"):
            statements.append(Statement("key", {
                "name": macro_key_to_script_key(event.data.get("key")),
                "state": "down" if event.type == "key_press" else "up",
            }, event.t))
    statements.sort(key=lambda s: s.t)
    return statements


# -------------------------------------------------------------------- writing

HEADER = """; {title}
; {detail}
;
; Generated from a recorded macro. Every click carries the screen position it
; was recorded at, so this only replays correctly at the same screen resolution
; and with the same windows in the same places.
;
; Sleep is accurate to roughly 10-15ms, so very fast bursts replay a little
; slower here than they were recorded.

#Requires AutoHotkey v2.0
#SingleInstance Force

CoordMode "Mouse", "Screen"
SendMode "Input"
SetKeyDelay -1, -1
SetMouseDelay -1
"""

# The stop key has to be defined below the body, not above it: AutoHotkey runs
# the script from the top and stops at the first hotkey definition, so a hotkey
# placed first would leave the body unreachable. Hotkeys are registered when the
# file loads either way, so the key is live while the body is still running.
FOOTER = """ExitApp

; Press {key} at any time to stop.
{key}::ExitApp
"""


def _send_literal(text):
    """A Send call for a character that would otherwise be read as syntax."""
    return f'SendText "{text.replace(chr(34), chr(34) * 2)}"'


def _key_line(args):
    name = args["name"]
    ahk_name = to_ahk_key(name)
    state = args["state"]

    if len(ahk_name) == 1 and ahk_name in SEND_SPECIAL:
        # {^ down} is ambiguous to parse, so these are typed whole on the press
        # and the matching release does nothing.
        if state == "down":
            return _send_literal(ahk_name) + "   ; typed whole: can't be held"
        return None
    return f'Send "{{{ahk_name} {state}}}"'


def _statement_line(statement):
    a = statement.args
    if statement.op == "move":
        return f'MouseMove {a["x"]}, {a["y"]}'
    if statement.op == "click":
        button = BUTTON_NAMES.get(a["button"], "Left")
        state = "Down" if a["state"] == "down" else "Up"
        return f'Click "{a["x"]} {a["y"]} {button} {state}"'
    if statement.op == "scroll":
        wheel = {"up": "WheelUp", "down": "WheelDown",
                 "left": "WheelLeft", "right": "WheelRight"}[a["direction"]]
        return f'Send "{{{wheel} {a["count"]}}}"'
    if statement.op == "key":
        return _key_line(a)
    return None


def to_ahk(statements, title="Void Click macro", loop=1, indent="    ",
           stop_hotkey="F6"):
    """Render statements as a runnable AutoHotkey v2 script.

    `loop` of 0 means repeat forever, matching how the rest of the app reads a
    loop count. `stop_hotkey` of None leaves the panic key out, which is also
    what makes the file exit on its own instead of sitting resident.
    """
    statements = list(statements)
    span = max((s.t for s in statements), default=0.0)
    detail = f"{len(statements)} statement(s), {span:.1f}s"

    lines = [HEADER.format(title=title, detail=detail).rstrip(), ""]
    lines.append("Loop" if loop == 0 else f"Loop {max(int(loop), 1)}")
    lines.append("{")

    previous = 0.0
    for statement in statements:
        gap_ms = round((statement.t - previous) * 1000)
        if gap_ms > 0:
            lines.append(f"{indent}Sleep {gap_ms}")
            previous = statement.t
        line = _statement_line(statement)
        if line:
            lines.append(indent + line)

    lines.append("}")
    lines.append("")
    lines.append(FOOTER.format(key=stop_hotkey) if stop_hotkey else "ExitApp\n")
    return "\n".join(lines)


def export(events, path, title="Void Click macro", loop=1, include_moves=True,
           stop_hotkey="F6"):
    """Write a recording straight out as an .ahk file. Returns the statements."""
    statements = build(events, include_moves=include_moves)
    with open(path, "w", encoding="utf-8") as f:
        f.write(to_ahk(statements, title=title, loop=loop, stop_hotkey=stop_hotkey))
    return statements


# -------------------------------------------------------------------- reading

_SLEEP = re.compile(r"^Sleep\s+([\d.]+)", re.I)
_MOUSEMOVE = re.compile(r"^MouseMove\s+(-?\d+)\s*,\s*(-?\d+)", re.I)
_CLICK = re.compile(r'^Click\s+"([^"]*)"', re.I)
_SEND = re.compile(r'^Send\s+"([^"]*)"', re.I)
_SENDTEXT = re.compile(r'^SendText\s+"(.*)"\s*$', re.I)
_BRACED = re.compile(r"\{([^}]*)\}")
_WHEEL = re.compile(r"^wheel(up|down|left|right)(?:\s+(\d+))?$", re.I)


def _parse_click(options, t):
    """Click "532 410 Left Down" -- the fields may come in any order."""
    x = y = None
    button, state = "left", "tap"
    for token in options.split():
        lowered = token.lower()
        if lowered in AHK_TO_BUTTON:
            button = AHK_TO_BUTTON[lowered]
        elif lowered in ("down", "up"):
            state = lowered
        elif token.lstrip("-").isdigit():
            if x is None:
                x = int(token)
            elif y is None:
                y = int(token)
    args = {"button": button, "state": state, "x": x or 0, "y": y or 0}
    if state != "tap":
        return [Statement("click", args, t)]
    # A bare Click is a press and a release with nothing between them.
    return [Statement("click", dict(args, state="down"), t),
            Statement("click", dict(args, state="up"), t)]


def _parse_send(body, t):
    """Unpack a Send string into key and wheel statements.

    Handles the two forms this module writes ({a down}, {WheelDown 3}) plus the
    prefix form a person would type by hand, ^c for Ctrl+C.
    """
    statements = []
    position = 0
    pending_mods = []

    for match in _BRACED.finditer(body):
        for char in body[position:match.start()]:
            if char in MOD_PREFIX.values():
                pending_mods.append(
                    next(k for k, v in MOD_PREFIX.items() if v == char))
            else:
                statements.extend(_tap(char, pending_mods, t))
                pending_mods = []
        position = match.end()

        inner = match.group(1).strip()
        wheel = _WHEEL.match(inner)
        if wheel:
            statements.append(Statement("scroll", {
                "direction": wheel.group(1).lower(),
                "count": int(wheel.group(2) or 1), "x": 0, "y": 0}, t))
            continue

        parts = inner.split()
        name = from_ahk_key(parts[0]) if parts else ""
        if not name:
            continue
        state = parts[1].lower() if len(parts) > 1 else ""
        if state in ("down", "up"):
            statements.append(Statement("key", {"name": name, "state": state}, t))
        else:
            statements.extend(_tap(name, pending_mods, t))
            pending_mods = []

    for char in body[position:]:
        if char in MOD_PREFIX.values():
            pending_mods.append(next(k for k, v in MOD_PREFIX.items() if v == char))
        else:
            statements.extend(_tap(char, pending_mods, t))
            pending_mods = []
    return statements


def _tap(name, mods, t):
    """A key pressed and released, wrapped in any modifiers that qualified it."""
    statements = [Statement("key", {"name": mod, "state": "down"}, t) for mod in mods]
    statements.append(Statement("key", {"name": name, "state": "down"}, t))
    statements.append(Statement("key", {"name": name, "state": "up"}, t))
    statements.extend(
        Statement("key", {"name": mod, "state": "up"}, t) for mod in reversed(mods))
    return statements


def from_ahk(text):
    """Parse the subset of AutoHotkey this module writes back into statements.

    Enough to reopen an exported file, or to bring in a hand-written one. Lines
    it doesn't recognise are skipped rather than guessed at, and reported.
    """
    statements, skipped = [], []
    t = 0.0

    for raw in text.splitlines():
        line = raw.split(";", 1)[0].strip() if not raw.strip().startswith(";") else ""
        if not line:
            continue

        sleep = _SLEEP.match(line)
        if sleep:
            t += float(sleep.group(1)) / 1000.0
            continue

        move = _MOUSEMOVE.match(line)
        if move:
            statements.append(Statement(
                "move", {"x": int(move.group(1)), "y": int(move.group(2))}, t))
            continue

        click = _CLICK.match(line)
        if click:
            statements.extend(_parse_click(click.group(1), t))
            continue

        send = _SEND.match(line)
        if send:
            statements.extend(_parse_send(send.group(1), t))
            continue

        text_send = _SENDTEXT.match(line)
        if text_send:
            for char in text_send.group(1).replace('""', '"'):
                statements.extend(_tap(char, [], t))
            continue

        # Directives, the loop braces and the stop hotkey are all structure, not
        # actions; anything else is something this parser doesn't cover.
        if not re.match(r"^(#|\}|\{|Loop|CoordMode|SendMode|SetKeyDelay|"
                        r"SetMouseDelay|F6::)", line, re.I):
            skipped.append(line)

    return statements, skipped


# ------------------------------------------------------------------ discovery

def find_autohotkey():
    """Path to an installed AutoHotkey v2, or None.

    Only used to tell the user whether an exported file can be double-clicked;
    nothing here ever launches it.
    """
    import os
    import sys

    if sys.platform != "win32":
        return None

    candidates = []
    try:
        import winreg

        for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
            try:
                with winreg.OpenKey(root, r"SOFTWARE\AutoHotkey") as key:
                    install_dir = winreg.QueryValueEx(key, "InstallDir")[0]
                    candidates.append(os.path.join(install_dir, "v2", "AutoHotkey64.exe"))
                    candidates.append(os.path.join(install_dir, "v2", "AutoHotkey32.exe"))
                    candidates.append(os.path.join(install_dir, "AutoHotkey.exe"))
            except OSError:
                continue
    except ImportError:
        pass

    for base in (os.environ.get("ProgramFiles", r"C:\Program Files"),
                 os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")):
        candidates.append(os.path.join(base, "AutoHotkey", "v2", "AutoHotkey64.exe"))
        candidates.append(os.path.join(base, "AutoHotkey", "AutoHotkey.exe"))

    for path in candidates:
        if path and os.path.isfile(path):
            return path
    return None
