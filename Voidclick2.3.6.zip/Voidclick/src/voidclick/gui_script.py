import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import slots as slot_model
from . import theme
from .gui_widgets import HotkeyPicker, PageHeader
from .hotkey_conflicts import find_conflict, script_address
from .rounded_button import RoundedButton
from .rounded_entry import RoundedEntry
from .rounded_select import RoundedSelect
from .script import ScriptRunner, ScriptStep, load_script, save_script
from .slot_bar import SlotBar
from .speed_control import SpeedControl
from .toggle import ToggleSwitch

# Editable parameters per step kind: (key, label, default).
FIELDS = {
    "autoclick": [("cps", "Clicks/sec", 34.0), ("seconds", "For (seconds)", 3.0),
                   ("duty", "Duty cycle %", 50.0), ("randomization", "Random %", 0.0),
                   ("button", "Button", "left")],
    "click": [("count", "Times", 1), ("cps", "Clicks/sec", 10.0),
               ("duty", "Duty cycle %", 50.0), ("randomization", "Random %", 0.0),
               ("button", "Button", "left")],
    "key": [("key", "Key", "3"), ("hold_ms", "Hold (ms)", 0)],
    "combo": [("mods", "Modifiers", "ctrl"), ("key", "Key", "c"),
               ("hold_ms", "Hold (ms)", 0)],
    "scroll": [("direction", "Direction", "down"), ("count", "Times", 3)],
    "wait": [("seconds", "Seconds", 0.3)],
}

# Fields that hold text rather than a number.
TEXT_FIELDS = ("key", "button", "mods", "direction")

CHOICES = {
    "button": ["left", "right", "middle"],
    "direction": ["down", "up", "left", "right"],
}

ADD_BUTTONS = [("autoclick", "+ Autoclick"), ("key", "+ Key"), ("wait", "+ Wait"),
               ("click", "+ Clicks"), ("combo", "+ Combo"), ("scroll", "+ Scroll")]


def default_step(kind):
    return ScriptStep(kind, {key: default for key, _, default in FIELDS[kind]})


class ScriptPage(ttk.Frame):
    """Builds and runs position-independent step sequences.

    Several scripts live here at once, each a slot with its own hotkey, steps and
    speed, and each with its own runner so they can run at the same time.
    """

    def __init__(self, master, hotkey_manager, cfg, on_config_change, notify=None):
        super().__init__(master, padding=16)

        self.hotkey_manager = hotkey_manager
        self.cfg = cfg
        self.on_config_change = on_config_change
        self.notify = notify or (lambda message: None)

        self.index = 0
        self._field_vars = {}
        self._steps = {}      # slot id -> [ScriptStep]
        self.runners = {}     # slot id -> ScriptRunner
        self._registered = set()
        self._load_steps_from_config()

        self._loading = True
        self._build_ui()
        self._loading = False
        self._select_slot(0)

    # ------------------------------------------------------------------ slots

    @property
    def slots(self):
        return self.cfg["scripts"]

    @property
    def slot(self):
        self.index = max(0, min(self.index, len(self.slots) - 1))
        return self.slots[self.index]

    @property
    def steps(self):
        return self._steps.setdefault(self.slot["id"], [])

    @property
    def runner(self):
        return self._runner_for(self.slot["id"])

    def _load_steps_from_config(self):
        for slot in self.slots:
            self._steps[slot["id"]] = [
                ScriptStep(item.get("kind", "wait"), dict(item.get("params", {})))
                for item in slot.get("steps", [])
                if isinstance(item, dict) and item.get("kind") in FIELDS
            ]

    def _store_steps(self):
        self.slot["steps"] = [{"kind": s.kind, "params": dict(s.params)}
                              for s in self.steps]

    def _runner_for(self, slot_id):
        """One runner per slot, made on first use so slots can run together."""
        if slot_id not in self.runners:
            self.runners[slot_id] = ScriptRunner(
                on_state_change=lambda running, i=slot_id: self._on_state_change(i, running),
                on_step=lambda index, loop, i=slot_id: self._on_step(i, index, loop),
            )
        return self.runners[slot_id]

    def _slot_labels(self):
        labels = []
        for slot in self.slots:
            label = slot_model.slot_label(slot["name"], slot["hotkey"])
            runner = self.runners.get(slot["id"])
            if runner is not None and runner.running:
                label += "  ●"       # a dot marks a slot that's running now
            labels.append(label)
        return labels

    def _refresh_slot_bar(self):
        self.slot_bar.refresh(
            self._slot_labels(), self.index, self.slot["name"],
            can_add=len(self.slots) < slot_model.MAX_SLOTS,
            can_delete=len(self.slots) > 1,
        )

    def _select_slot(self, index):
        self.index = max(0, min(index, len(self.slots) - 1))
        self._loading = True
        try:
            slot = self.slot
            self.hotkey_picker.set_combo(slot["hotkey"])
            self.mode_var.set(slot["hotkey_mode"])
            self.loop_var.set(slot["loop"])
            self.loop_toggle.refresh()
            self.speed_control.set_speed(slot["speed"])
            self.runner.speed = float(slot["speed"])
        finally:
            self._loading = False
        self._refresh_slot_bar()
        self._refresh_tree(select=0 if self.steps else None)
        self._show_editor()
        self._sync_run_button()

    def _add_slot(self):
        if len(self.slots) >= slot_model.MAX_SLOTS:
            self.notify(f"{slot_model.MAX_SLOTS} scripts is the limit")
            return
        new = slot_model.new_script_slot(len(self.slots))
        new["name"] = slot_model.unique_name(self.slots, new["name"])
        self.slots.append(new)
        self._steps[new["id"]] = []
        self.on_config_change()
        self._select_slot(len(self.slots) - 1)
        self._register_hotkeys()

    def _delete_slot(self):
        if len(self.slots) <= 1:
            self.notify("the last script can't be deleted")
            return
        doomed = self.slot
        if self.steps and not messagebox.askyesno(
                "Delete script", f"Delete “{doomed['name']}” and its "
                f"{len(self.steps)} step(s)?"):
            return
        self._runner_for(doomed["id"]).stop()
        self.hotkey_manager.unregister(f"script_run_{doomed['id']}")
        self._registered.discard(doomed["id"])
        self.runners.pop(doomed["id"], None)
        self._steps.pop(doomed["id"], None)
        self.slots.remove(doomed)
        self.on_config_change()
        self._select_slot(min(self.index, len(self.slots) - 1))
        self._register_hotkeys()

    def _rename_slot(self, name):
        renamed = slot_model.unique_name(self.slots, name, ignore_index=self.index)
        self.slot["name"] = renamed
        self.on_config_change()
        self._refresh_slot_bar()

    # ------------------------------------------------------------------ layout

    def _build_ui(self):
        pad = {"padx": 8, "pady": 4}

        PageHeader(self, "Script").grid(row=0, column=0, columnspan=3, sticky="ew", pady=(0, 8))
        self.columnconfigure(1, weight=1)

        row = 1
        ttk.Label(self, text="Script:").grid(row=row, column=0, sticky="w", **pad)
        self.slot_bar = SlotBar(self, on_select=self._select_slot, on_add=self._add_slot,
                                 on_delete=self._delete_slot, on_rename=self._rename_slot)
        self.slot_bar.grid(row=row, column=1, columnspan=2, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Runs top to bottom, no mouse positions involved.",
                   style="Muted.TLabel").grid(row=row, column=0, columnspan=3, sticky="w", padx=8)
        row += 1

        add_frame = ttk.Frame(self)
        add_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        for i, (kind, label) in enumerate(ADD_BUTTONS):
            column, grid_row = i % 3, i // 3
            add_frame.columnconfigure(column, weight=1)
            RoundedButton(
                add_frame, label, command=lambda k=kind: self._add_step(k),
                bg=theme.BG_FIELD, hover_bg=theme.GREEN_HOVER, fg=theme.FG,
                parent_bg=theme.BG_PANEL, height=26, font=("Segoe UI", 9),
            ).grid(row=grid_row, column=column, sticky="ew", padx=2, pady=1)
        row += 1

        self.tree = ttk.Treeview(self, columns=("step",), show="tree", height=5,
                                  selectmode="browse")
        self.tree.column("#0", width=34, stretch=False)
        self.tree.column("step", width=340, anchor="w")
        self.tree.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        self.tree.bind("<<TreeviewSelect>>", lambda ev: self._show_editor())
        row += 1

        order_frame = ttk.Frame(self)
        order_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        for i, (label, command) in enumerate((("Up", lambda: self._move(-1)),
                                               ("Down", lambda: self._move(1)),
                                               ("Duplicate", self._duplicate),
                                               ("Remove", self._remove))):
            order_frame.columnconfigure(i, weight=1)
            RoundedButton(
                order_frame, label, command=command, bg=theme.BG_FIELD,
                hover_bg=theme.ORANGE if label == "Remove" else theme.BORDER,
                fg=theme.FG, parent_bg=theme.BG_PANEL, height=28, font=("Segoe UI", 9),
            ).grid(row=0, column=i, sticky="ew", padx=2)
        row += 1

        self.editor = ttk.Frame(self)
        self.editor.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        row += 1

        ttk.Label(self, text="Run hotkey:").grid(row=row, column=0, sticky="w", **pad)
        self.hotkey_picker = HotkeyPicker(self, self.hotkey_manager,
                                           self.slots[0]["hotkey"], self._on_hotkey_change)
        self.hotkey_picker.grid(row=row, column=1, sticky="w", **pad)
        self.mode_var = tk.StringVar(value=self.slots[0]["hotkey_mode"])
        RoundedSelect(self, self.mode_var, ["toggle", "hold"],
                       command=self._on_mode_change).grid(row=row, column=2, sticky="w", **pad)
        row += 1

        ttk.Label(self, text="Run speed:").grid(row=row, column=0, sticky="w", **pad)
        self.speed_control = SpeedControl(self, self.slots[0]["speed"], self._on_speed_change)
        self.speed_control.grid(row=row, column=1, sticky="w", **pad)
        row += 1

        self.loop_var = tk.BooleanVar(value=self.slots[0]["loop"])
        self.loop_toggle = ToggleSwitch(self, "Repeat until stopped", self.loop_var,
                                         self._on_loop_change)
        self.loop_toggle.grid(row=row, column=0, columnspan=3, sticky="w", **pad)
        row += 1

        self.run_btn = RoundedButton(
            self, "Run", command=self._toggle_run, bg=theme.GREEN, hover_bg=theme.GREEN_HOVER,
            fg=theme.TEXT_ON_ACCENT, parent_bg=theme.BG_PANEL,
        )
        self.run_btn.grid(row=row, column=0, columnspan=3, sticky="ew", padx=8, pady=(8, 4))
        row += 1

        file_frame = ttk.Frame(self)
        file_frame.grid(row=row, column=0, columnspan=3, sticky="ew", **pad)
        for i, (label, command) in enumerate((("Save...", self._save), ("Load...", self._load),
                                               ("Clear", self._clear))):
            file_frame.columnconfigure(i, weight=1)
            RoundedButton(
                file_frame, label, command=command, bg=theme.BG_FIELD, hover_bg=theme.BORDER,
                fg=theme.FG, parent_bg=theme.BG_PANEL, height=28, font=("Segoe UI", 9),
            ).grid(row=0, column=i, sticky="ew", padx=2)
        row += 1

        self.status_var = tk.StringVar(value="Idle — 0 steps")
        ttk.Label(self, textvariable=self.status_var, style="Value.TLabel").grid(
            row=row, column=0, columnspan=3, **pad)

    # ------------------------------------------------------------------ step list

    def _selected_index(self):
        selection = self.tree.selection()
        return int(selection[0]) if selection else None

    def _refresh_tree(self, select=None):
        """Redraw the list only. Never saves — switching slots redraws too, and
        building the page must not write to the config file."""
        self.tree.delete(*self.tree.get_children())
        for i, step in enumerate(self.steps):
            self.tree.insert("", "end", iid=str(i), text=str(i + 1), values=(step.describe(),))
        if select is not None and 0 <= select < len(self.steps):
            self.tree.selection_set(str(select))
            self.tree.see(str(select))
        self._update_status()

    def _steps_changed(self, select=None):
        """The steps themselves were edited: persist, then redraw."""
        self._store_steps()
        if not self._loading:
            self.on_config_change()
        self._refresh_tree(select)

    def _update_status(self):
        if not self.runner.running:
            running = sum(1 for r in self.runners.values() if r.running)
            extra = f" · {running} running" if running else ""
            self.status_var.set(f"Idle — {len(self.steps)} steps{extra}")

    def _add_step(self, kind):
        self.steps.append(default_step(kind))
        self._steps_changed(select=len(self.steps) - 1)

    def _remove(self):
        index = self._selected_index()
        if index is None:
            return
        del self.steps[index]
        self._steps_changed(select=min(index, len(self.steps) - 1))
        self._show_editor()

    def _duplicate(self):
        index = self._selected_index()
        if index is None:
            return
        original = self.steps[index]
        self.steps.insert(index + 1, ScriptStep(original.kind, dict(original.params)))
        self._steps_changed(select=index + 1)

    def _move(self, delta):
        index = self._selected_index()
        if index is None:
            return
        target = index + delta
        if not 0 <= target < len(self.steps):
            return
        self.steps[index], self.steps[target] = self.steps[target], self.steps[index]
        self._steps_changed(select=target)

    # ------------------------------------------------------------------ editor

    def _show_editor(self):
        for child in self.editor.winfo_children():
            child.destroy()
        self._field_vars = {}

        index = self._selected_index()
        if index is None:
            return
        step = self.steps[index]

        ttk.Label(self.editor, text=f"Step {index + 1}: {step.kind}",
                   style="Section.TLabel").grid(row=0, column=0, columnspan=4,
                                                 sticky="w", pady=(0, 4))

        for i, (key, label, default) in enumerate(FIELDS[step.kind]):
            column = (i % 2) * 2
            grid_row = 1 + i // 2
            ttk.Label(self.editor, text=f"{label}:").grid(
                row=grid_row, column=column, sticky="w", padx=(0, 6), pady=2)
            var = tk.StringVar(value=str(step.params.get(key, default)))
            self._field_vars[key] = var
            if key in CHOICES:
                widget = RoundedSelect(self.editor, var, CHOICES[key],
                                        command=self._commit_editor)
            else:
                widget = RoundedEntry(self.editor, var, width=8)
                widget.bind_commit(self._commit_editor)
            widget.grid(row=grid_row, column=column + 1, sticky="w", padx=(0, 14), pady=2)

    def _commit_editor(self):
        index = self._selected_index()
        if index is None:
            return
        step = self.steps[index]
        for key, _, default in FIELDS[step.kind]:
            raw = self._field_vars[key].get()
            if key in TEXT_FIELDS:
                step.params[key] = raw
                continue
            try:
                value = float(raw)
                if key == "count":
                    value = max(int(value), 1)
                elif key == "duty":
                    value = min(max(value, 1.0), 100.0)
                elif key == "randomization":
                    value = min(max(value, 0.0), 100.0)
                elif value < 0:
                    raise ValueError
            except ValueError:
                value = step.params.get(key, default)
                self._field_vars[key].set(str(value))
            step.params[key] = value
        self._steps_changed(select=index)

    # ------------------------------------------------------------------ running

    def _toggle_run(self):
        if self.runner.running:
            self.runner.stop()
        else:
            self._start_run()

    def _start_run(self, index=None):
        """Start one slot. Others keep running — that's the point of slots."""
        target = self.slots[index] if index is not None else self.slot
        runner = self._runner_for(target["id"])
        steps = self._steps.get(target["id"], [])
        if runner.running or not steps:
            return
        try:
            self._validate(steps)
        except ValueError as exc:
            messagebox.showerror("Script", str(exc))
            return
        runner.speed = float(target["speed"])
        runner.start(steps, loop=bool(target["loop"]))

    def _toggle_slot(self, index):
        """What a slot's own hotkey does, whichever slot is on screen."""
        if not 0 <= index < len(self.slots):
            return
        runner = self._runner_for(self.slots[index]["id"])
        if runner.running:
            runner.stop()
        else:
            self._start_run(index)

    def _stop_slot(self, index):
        if 0 <= index < len(self.slots):
            self._runner_for(self.slots[index]["id"]).stop()

    def _validate(self, steps):
        from .script import parse_key, parse_modifiers

        for i, step in enumerate(steps, start=1):
            try:
                if step.kind in ("key", "combo"):
                    parse_key(step.params.get("key", ""))
                if step.kind == "combo":
                    parse_modifiers(step.params.get("mods", ""))
            except ValueError as exc:
                raise ValueError(f"Step {i}: {exc}") from exc

    def _sync_run_button(self):
        running = self.runner.running
        self.run_btn.set_text("Stop" if running else "Run")
        self.run_btn.set_colors(
            theme.ORANGE if running else theme.GREEN,
            theme.ORANGE_HOVER if running else theme.GREEN_HOVER,
        )
        self._update_status()

    def _on_state_change(self, slot_id, running):
        def update():
            # Any slot changing state changes the dropdown's running markers.
            self._refresh_slot_bar()
            if self.slot["id"] == slot_id:
                self._sync_run_button()
            else:
                self._update_status()
        self.after(0, update)

    def _on_step(self, slot_id, index, loop_number):
        if self.slot["id"] != slot_id:
            return
        self.after(0, lambda: self.status_var.set(
            f"Running step {index + 1}/{len(self.steps)} · pass {loop_number}"))

    def stop_all(self):
        for runner in self.runners.values():
            runner.stop()

    def any_running(self):
        return any(runner.running for runner in self.runners.values())

    # ------------------------------------------------------------------ config

    def _on_hotkey_change(self, combo_string):
        clash = find_conflict(self.cfg, script_address(self.index), combo_string)
        if clash:
            combo_string = ""
            self.hotkey_picker.set_combo("")
            self.notify(f"Already used by {clash} — pick another key")
        self.slot["hotkey"] = combo_string
        self.on_config_change()
        self._refresh_slot_bar()
        self._register_hotkeys()

    def _on_mode_change(self):
        self.slot["hotkey_mode"] = self.mode_var.get()
        self.on_config_change()
        self._register_hotkeys()

    def _on_speed_change(self, speed):
        self.slot["speed"] = speed
        self.runner.speed = speed
        self.on_config_change()

    def _on_loop_change(self):
        self.slot["loop"] = self.loop_var.get()
        if not self._loading:
            self.on_config_change()

    def _register_hotkeys(self):
        """Rebind every slot, and drop bindings whose slot is gone."""
        live = set()
        for index, slot in enumerate(self.slots):
            name = f"script_run_{slot['id']}"
            live.add(slot["id"])
            if slot["hotkey_mode"] == "hold":
                self.hotkey_manager.register(
                    name, slot["hotkey"],
                    lambda i=index: self.after(0, self._start_run, i),
                    on_release=lambda i=index: self.after(0, self._stop_slot, i),
                )
            else:
                self.hotkey_manager.register(
                    name, slot["hotkey"],
                    lambda i=index: self.after(0, self._toggle_slot, i))
        for stale in self._registered - live:
            self.hotkey_manager.unregister(f"script_run_{stale}")
        self._registered = live

    def refresh_from_config(self):
        self._load_steps_from_config()
        self._select_slot(self.index)
        self._register_hotkeys()

    # ------------------------------------------------------------------ files

    def _save(self):
        if not self.steps:
            messagebox.showinfo("Save Script", "No steps to save.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                             filetypes=[("Script files", "*.json")])
        if path:
            save_script(path, self.steps)

    def _load(self):
        path = filedialog.askopenfilename(filetypes=[("Script files", "*.json")])
        if not path:
            return
        try:
            loaded = load_script(path)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror("Load Script", f"Failed to load script:\n{exc}")
            return
        self.load_steps(loaded)

    def load_steps(self, steps):
        """Replace the open slot's script wholesale — used when converting a macro."""
        self._steps[self.slot["id"]] = list(steps)
        self._steps_changed(select=0 if steps else None)
        self._show_editor()

    def _clear(self):
        self._steps[self.slot["id"]] = []
        self._steps_changed()
        self._show_editor()
