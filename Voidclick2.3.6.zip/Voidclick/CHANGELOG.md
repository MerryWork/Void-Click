# Changelog

## 1.3.6

### Added
- **Slots.** Scripts and macros are now lists of named slots, each with its own
  hotkey, speed, loop setting and saved content — up to 8 of each. A dropdown on
  each page shows the open slot's name and the key that runs it.
- **Slots run at the same time.** Every slot has its own engine, so several
  scripts and macros can run together. A running slot is marked with a dot in the
  dropdown, and the panic hotkey stops all of them, on screen or not.
- **Combo steps** — `Ctrl+C` and other shortcuts, as one script step.
- **Scroll steps** — wheel movement in any direction, N ticks at a time.
- A support link in the sidebar.

### Changed
- Recording is now a single global hotkey that records into whichever macro slot
  is open, rather than a hotkey per recording.
- Hotkey conflict checking is derived from the config instead of a fixed list, so
  it covers every slot as slots are added and removed.
- The swap hotkey acts on the slot each page currently has open.
- Playback and run speed belong to the slot rather than to the page.
- Recordings are stored in a `macros` folder beside `config.json`, one file per
  slot, keeping `config.json` readable.

### Fixed
- Macro-to-script conversion no longer discards shortcuts and wheel movement;
  both convert to real steps. Only mouse position genuinely can't cross over.
- Conversion splits click bursts by local rhythm rather than by one average for
  the whole recording, so a fast burst next to slow clicks is no longer merged
  into it.
- Conversion no longer invents a randomization percentage from a handful of
  unsteady clicks.
- Selecting a combo or scroll step in the script editor no longer raises.
- Pages no longer render wider than the window, which had been clipping the
  right-hand column of buttons.

### Upgrading
Existing settings migrate automatically: the old single script and macro become
the first slot of each list, keeping their hotkeys. Nothing needs to be redone.
